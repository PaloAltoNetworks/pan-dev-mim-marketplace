<#
Adaptable App Driver PowerShell Script for Akamai CPS

Copyright (c)2026 Venafi, Inc. All rights reserved. This integration module is licensed under the same terms and conditions as your CyberArk product, available here: https://www.cyberark.com/contract-terms/

-----BEGIN FIELD DEFINITIONS-----
Text1|Proxy URL|110
Text2|WebSDK Url|111
Text3|Enrollment Template JSON|110
Text4|API Integration Client ID (default: AkamaiAutomation)|110
Text5|Akamai EnrollmentID|100
Option1|Update using Enrollment Template JSON|110
Option2|Remove Root from Chain|110
Passwd|EdgeRC JSON|110
-----END FIELD DEFINITIONS-----
#>
#Requires -Version 5.1

$script:scriptName = 'AdaptableApp\AkamaiApplicationDriver'
# script version is in Venafi.Akamai.Common.ps1

$installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

$vComPath = Join-Path -Path $installPath -ChildPath 'Scripts\AdaptableApp\AkamaiApplicationDriver\Venafi.Akamai.Common.ps1'
if (Test-Path -Path $vComPath -PathType Leaf) {
    . $vComPath
}
else {
    throw 'Venafi.Akamai.Common not found at {0}' -f $vComPath
}

#Unused Functions (These functions must be present for the Adaptable framework to work, but they are unused by this driver)
function Get-TPPUnused {
    [Alias("Prepare-Keystore")]
    [Alias("Generate-KeyPair")]
    [Alias("Install-Chain")]
    [Alias("Install-PrivateKey")]
    [Alias("Extract-PrivateKey")]
    [Alias("Remove-Certificate")]
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $false, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $false, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )
    Write-VenafiDebug -Message "Function '$($MyInvocation.InvocationName)' is not needed by this Adaptable Application."
    return @{ Result = "NotUsed" }
}

function Generate-CSR {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "", Justification = "Venafi Specification")]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidUsingConvertToSecureStringWithPlainText", "", Justification = "going to cred")]
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo | Out-Null
    Initialize-Akamai -General $General | Out-Null

    $contractId = $General.HostAddress
    $enrollmentId = $General.VarText5
    $isNewEnrollment = [String]::IsNullOrEmpty($enrollmentId)

    if ($isNewEnrollment) {
        Write-VenafiDebug -Level 'Info' -Message "Mode set to NEW. A new enrollment will be created."

        try {
            Initialize-VenafiPS -General $General

            #This is a new asset, create enrollment template
            if ([String]::IsNullOrEmpty($General.VarText3)) {
                $meId = (Get-VdcIdentity -Me).ID
                #check if any are null?
                $orgattrname = Get-VdcIdentityAttribute -IdentityId $meId -Attribute 'company', 'streetAddress', 'l', 'st', 'c', 'postalCode', 'telephoneNumber'
                $contactattrname = Get-VdcIdentityAttribute -IdentityId $meId -Attribute 'givenName', 'sn', 'mail'
                $templparams = @{
                    CSRInfo   = $Specific.SubjectDn
                    Company   = $orgattrname.Attributes.company
                    Street    = $orgattrname.Attributes.streetAddress
                    City      = $orgattrname.Attributes.l
                    State     = $orgattrname.Attributes.st
                    Country   = $orgattrname.Attributes.c
                    ZipCode   = $orgattrname.Attributes.postalCode
                    FirstName = $contactattrname.Attributes.givenName
                    Surname   = $contactattrname.Attributes.sn
                    Email     = $contactattrname.Attributes.mail
                    Phone     = $orgattrname.Attributes.telephoneNumber
                }
                if ($Specific.SubjAltNames) {
                    $templparams.Add('CSRSANs', $Specific.SubjAltNames.DNS)
                }
                $enrollmentInfo = New-AkamaiTemplate @templparams
            }
            elseif (!([String]::IsNullOrEmpty($General.VarText3))) {
                $enrollmentTemplate = ConvertFrom-Json $General.VarText3
                $templparams = @{
                    NewTemplate = $enrollmentTemplate
                    CSRInfo     = $Specific.SubjectDn
                }
                if ($Specific.SubjAltNames) {
                    $templparams.Add('CSRSANs', $Specific.SubjAltNames.DNS)
                }
                $enrollmentInfo = Update-AkamaiTemplate @templparams
            }
            else {
                "Cannot create Enrollment Template JSON to create new enrollment." | Write-VenafiDebug -ThrowException
            }

            $params = @{
                ContractID         = $contractId
                EnrollmentTemplate = $enrollmentInfo
            }
            $enrollment = New-AkamaiEnrollment @params
            $enrollmentId = $enrollment.id
            $script:ChangeID = $enrollment.ChangeId

            #Update the Application object with the Akamai EnrollmentID
            Set-VdcAttribute -Path $General.AppObjectDN -Attribute @{'Text Field 5' = $enrollmentId } -ErrorAction Stop | Out-Null

            Write-VenafiDebug -Level 'Info' -Message "Enrollment updated. Change location is $($enrollment.changes[0])"
            Write-VenafiDebug -Level 'Info' -Message "Enrollment ID set to $($enrollmentId)."
            Write-VenafiDebug -Level 'Info' -Message "Change ID is $($script:ChangeID)"
        }

        catch {
            $_ | Write-VenafiDebug -Intro 'Failed to create a new enrollment' -ThrowException
        }
        finally {
            if ($VenafiSession) {
                Revoke-VdcToken -Force -ErrorAction SilentlyContinue
            }
        }
    }
    else {
        $isNewEnrollment = $false

        # ensure there isn't an existing change
        $script:ChangeID = Get-AkamaiPendingChangeId -EnrollmentId $enrollmentId

        if ( $script:changeId ) {
            # existing change, continue to wait for the proper status
            'There is an existing change, bypassing enrollment modification' | Write-VenafiDebug
        }
        else {

            Write-VenafiDebug -Level 'Info' -Message "Mode set to EDIT. Modifications will be made to enrollment $enrollmentId"

            # make sure the enrollment exists
            $enrollmentCheck = Get-CPSEnrollment -EnrollmentId $enrollmentId -ErrorAction SilentlyContinue
            if ( $null -eq $enrollmentCheck ) {
                "Enrollment ID $enrollmentId specified on the Application object was not found on Akamai" | Write-VenafiDebug -ThrowException
            }

            if ($null -ne $General.VarText3) {
                #Fetch the enrollment so we can update the fields
                $enrollmentUpdate = ConvertFrom-Json $General.VarText3
            }
            else {
                "Cannot get Enrollment Template JSON to update enrollment." | Write-VenafiDebug -ThrowException
            }

            $templparams = @{
                EnrollmentID     = $enrollmentId
                CSRInfo          = $Specific.SubjectDn
                CSRSANs          = $Specific.SubjAltNames.DNS
                EnrollmentUpdate = $enrollmentUpdate
                KeyAlgorithm     = $Specific.KeyAlg
                UpdateRemote     = ($General.VarBool1 -eq 'true')
            }

            try {
                $enrollResponse = Update-AkamaiEnrollment @templparams
                $script:ChangeID = $enrollResponse.ChangeId

                Write-VenafiDebug -Level 'Info' -Message "Enrollment updated. Change location is $($enrollResponse.changes[0])"
                Write-VenafiDebug -Level 'Info' -Message "Enrollment ID set to $($enrollmentId)."
                Write-VenafiDebug -Level 'Info' -Message "Change ID is $($script:ChangeID)"
            }
            catch {
                $_ | Write-VenafiDebug -Intro "Failed to update enrollment $enrollmentId" -ThrowException

            }
        }
    }

    try {
        if ($script:ChangeID -ne 0) {
            $allowedInput = Wait-CPSStatusChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID
        }
        else {
            "ChangeId was not set, cannot continue" | Write-VenafiDebug -ThrowException
        }

        if (($allowedInput.info -match 'pre-verification-warnings') -and ($allowedInput.requiredToProceed -eq $true)) {
            #if we get this, just log it and auto-approve, then wait for the CSR
            $preresponse = Approve-AkamaiPreVerificationWarnings -EnrollmentID $enrollmentId -ChangeID $script:ChangeID
            if ($preresponse -eq $true) {
                Write-VenafiDebug -Level 'Info' -Message "Approved pre-verification-warnings"
            }
            else {
                Write-VenafiDebug -Level 'Debug' -Message "Pre-verification acknowledgement unsuccessful. Rechecking status"
            }
            $allowedInput = Wait-CPSStatusChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID
        }

        if (($allowedInput.info -match 'third-party-csr') -and ($allowedInput.requiredToProceed -eq $true)) {
            Write-VenafiDebug -Level 'Info' -Message "Found third party CSR"
            $csrResponse = Get-AkamaiEnrollmentCSR -EnrollmentID $enrollmentId -ChangeId $script:ChangeID

            $csrResponse | Write-VenafiDebug

            foreach ($csr in $csrResponse.csrs) {
                if ($csr.keyAlgorithm -eq "RSA") {
                    $respCsrRsa = $csr.csr
                }
                elseif ($csr.keyAlgorithm -eq "ECDSA") {
                    $respCsrEcdsa = $csr.csr
                }
            }

            if ($Specific.KeyAlg -eq "RSA") {
                $result = @{
                    Result    = "Success"
                    Pkcs10    = $respCsrRsa
                    AssetName = "Akamai RSA:$($enrollmentid)"
                }
            }
            elseif ($Specific.KeyAlg -eq "ECC") {
                $result = @{
                    Result    = "Success"
                    Pkcs10    = $respCsrEcdsa
                    AssetName = "Akamai ECC:$($enrollmentid)"
                }
            }
            $result | Write-VenafiDebug -Level 'Debug' -Intro 'Generate-CSR response'
            return $result

        }
        elseif (($allowedInput.info -match 'pre-verification-warnings') -and ($allowedInput.requiredToProceed -eq $true)) {
            "Pre-verification acknowledgement unsuccessful. Cannot proceed" | Write-VenafiDebug -ThrowException
        }
        elseif ($allowedInput -eq "completed") {
            $msg = "The current status of $($allowedInput) is further on the lifecycle than the desired status of third-party-csr"
            Write-VenafiDebug -Level 'Warning' -Message "Change request $($script:ChangeID) was completed"
            throw [System.DataMisalignedException] $msg
        }
        else {
            $allowedInput | Write-VenafiDebug -Level 'Error' -Intro 'Unable to process allowedInput paths when generating CSR' -ThrowException
        }
    }
    catch [System.DataMisalignedException] {
        #This only happens when the status is further down the lifecycle and not waiting for a certificate
        "Generate-CSR did not enroll a new certificate as the enrollment lifecycle is beyond waiting for the CSR." | Write-VenafiDebug -ThrowException
    }
    catch {
        # If it fails above, remove the change
        if ($script:ChangeID -ne 0) {
            $remresp = Remove-CPSChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID
            Write-VenafiDebug -Level 'Info' -Message "Change id $($remresp) removed."
        }

        if ( $isNewEnrollment ) {
            # if this was a new enrollment, remove the enrollment id from the app object so it starts over next time
            Set-VdcAttribute -Path $General.AppObjectDN -Attribute @{'Text Field 5' = '' }
            'Removed enrollment id from {0}' -f $General.AppObjectDN | Write-VenafiDebug
        }

        $_ | Write-VenafiDebug -Intro 'Failed to get the CSR from the enrollment' -ThrowException
    }
}

function Install-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation
    Initialize-Akamai -General $General

    $enrollmentId = $General.VarText5
    if ( $General.AssetName -like "Akamai RSA*" ) {
        $pkAlgo = "RSA"
        $otherPkAlgo = "ECDSA"
        $venafiAlgo = "RSA"
    }
    else {
        $pkAlgo = "ECDSA"
        $otherPkAlgo = "RSA"
        $venafiAlgo = "ECC"
    }

    if ( -not $enrollmentId ) {
        "Enrollment ID not set, cannot continue.  Have you enabled remote CSR generation?" | Write-VenafiDebug -ThrowException
    }

    Write-VenafiDebug -Level 'Debug' -Message "Working with enrollment $enrollmentId"

    try {
        $script:changeId = Get-AkamaiPendingChangeId -EnrollmentId $enrollmentId
        if ( $null -eq $script:changeId ) {
            if ( Test-AkamaiDualStack -EnrollmentID $enrollmentId ) {
                Write-VenafiDebug -Message 'Multistacked certificate with no pending change, the other certificate has already processed.  Nothing to do here.'
                return (
                    @{
                        'Result'    = "Success"
                        'AssetName' = 'Akamai {0}:{1}' -f $venafiAlgo, $enrollmentid
                    }
                )
            }

            "ChangeId was not set, cannot continue" | Write-VenafiDebug -ThrowException
        }

        Write-VenafiDebug -Level 'Info' -Message "ChangeId $($script:changeId) found"
        $allowedInput = Wait-CPSStatusChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID

        if ($allowedInput -eq "completed") {
            $msg = "The current status of $($allowedInput) is further on the lifecycle than the desired status of third-party-csr"
            Write-VenafiDebug -Level 'Warning' -Message "Change request $($script:ChangeID) was completed"
            throw [System.DataMisalignedException] $msg
        }
        elseif (($allowedInput.update -match 'third-party-cert-and-trust-chain') -and ($allowedInput.requiredToProceed -eq $true)) {

            Write-VenafiDebug -Level 'Info' -Message "Found third party CSR"

            if ($General.VarBool2 -eq 'true') {
                # remove root from chain

                $chainWithoutRoot = foreach ($cert in (Split-ChainData -InputObject $Specific.ChainPem)) {

                    if ($null -ne $cert) {
                        $thisCert = ConvertTo-X509Certificate2 -CertificatePEM $cert

                        if ($thisCert.Subject -eq $thisCert.Issuer) {
                            "Root certificate found and discarded" | Write-VenafiDebug
                        }
                        else {
                            $thisCert.Subject | Write-VenafiDebug -Intro 'Added certificate to new chain'
                            $cert
                        }
                    }
                    else {
                        Write-VenafiDebug "Part of chain was blank and not added"
                    }
                }

                if ($null -ne $chainWithoutRoot) {
                    $ChainPem = ($chainWithoutRoot | Out-String).trim()
                    $ChainPem | Write-VenafiDebug -Intro 'Updated chain'
                }
                else {
                    Write-VenafiDebug "Blank chain after removing root, cannot continue" -ThrowException
                }
            }
            else {
                $ChainPem = $Specific.ChainPem
            }

            $Body = @{
                'certificatesAndTrustChains' = @(
                    @{
                        'certificate'  = $Specific.CertPem
                        'keyAlgorithm' = $pkAlgo
                        'trustChain'   = $ChainPem
                    }
                )
            }

            $isDualStack = Test-AkamaiDualStack -EnrollmentID $enrollmentId
            Write-VenafiDebug -Message "Is this a multi-stacked certificate? $isDualStack"

            if ( $isDualStack ) {

                try {
                    Initialize-VenafiPS -General $General

                    $certs = (Find-VdcObject -Attribute 'Text Field 5' -Pattern $enrollmentId -Class 'Adaptable App' | Get-VdcAttribute -Attribute 'Certificate').Certificate

                    $certs | Write-VenafiDebug -Intro "Certificates found on the adaptable apps with enrollment ID $enrollmentId"

                    $otherCertPath = if ( $pkAlgo -eq "RSA" ) {
                        $certs -match 'ECC$'
                    }
                    else {
                        $certs -match 'RSA$'
                    }

                    if ( -not $otherCertPath ) {
                        Write-VenafiDebug -Message "Associated certificates do not end with RSA or ECC.  Please see the documentation for more details." -ThrowException
                    }

                    Write-VenafiDebug -Message "Other cert path is $otherCertPath"

                    $otherCert = Export-VdcCertificate -Path $otherCertPath -IncludeChain

                    $otherCert | Write-VenafiDebug -Intro "Other certificate details"

                    $body.certificatesAndTrustChains += @{
                        'certificate'  = $otherCert.CertPem
                        'trustChain'   = $otherCert.ChainPem -join "`r`n"
                        'keyAlgorithm' = $otherPkAlgo
                    }
                }
                finally {
                    if ($VenafiSession) {
                        Revoke-VdcToken -Force -ErrorAction SilentlyContinue
                    }
                }
            }

            $sendCertParams = @{
                EnrollmentID = $enrollmentId
                ChangeId     = $script:ChangeID
                Body         = $body
            }

            $sendCertParams | Write-VenafiDebug -Intro 'Parameters for Enrollment submission'

            $sendCertResponse = Add-CPSThirdPartyCert @sendCertParams
            $sendCertResponse | Write-VenafiDebug -Level 'Debug' -Intro 'Response from Enrollment submission'

            return (
                @{
                    'Result'    = "Success"
                    'AssetName' = 'Akamai {0}:{1}' -f $venafiAlgo, $enrollmentid
                }
            )
        }
        else {
            $allowedInput | Write-VenafiDebug -Level 'Error' -Intro 'Unable to process allowedInput paths when installing certificate' -ThrowException
        }
    }
    catch [System.DataMisalignedException] {
        #This only happens when the status is further down the lifecycle and not waiting for a certificate
        $_ | Write-VenafiDebug -Intro 'Install-Certificate did not upload a new certificate as the enrollment lifecycle is beyond certificate installation' -ThrowException
    }
    catch {
        # If it fails above, remove the change
        if ($script:ChangeID -ne 0) {
            $remresp = Remove-CPSChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID
            Write-VenafiDebug -Level 'Info' -Message "Change id $($remresp) removed."
        }

        $_ | Write-VenafiDebug -Intro 'Unable to upload the certificate to Akamai' -ThrowException
    }

}
function Update-Binding {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation
    Initialize-Akamai -General $General

    $enrollmentId = $General.VarText5
    Write-VenafiDebug -Level 'Debug' -Message "Working on verifications with EnrollmentID $enrollmentId"

    try {
        $script:changeId = Get-AkamaiPendingChangeId -EnrollmentId $enrollmentId
        if ( $null -eq $script:changeId ) {
            if ( Test-AkamaiDualStack -EnrollmentID $enrollmentId ) {
                Write-VenafiDebug -Message 'Multistacked certificate with no pending change, the other certificate has already processed.  Nothing to do here.'
                return (
                    @{
                        'Result' = "Success"
                    }
                )
            }

            "ChangeId was not set, cannot continue" | Write-VenafiDebug -ThrowException
        }

        Write-VenafiDebug -Level 'Info' -Message "ChangeId $($script:changeId) found"
        $allowedInput = Wait-CPSStatusChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID

        if ($allowedInput -eq "completed") {
            Write-VenafiDebug -Level 'Info' -Message "Change request $($script:ChangeID) was completed"
            return @{ Result = "Success"; }
        }
        elseif (($allowedInput.info -match 'change-management-info') -and ($allowedInput.requiredToProceed -eq $true)) {
            Write-VenafiDebug -Level 'Info' -Message "Change request $($script:ChangeID) has no post verification warnings"
            return @{ Result = "Success"; }
        }
        elseif (($allowedInput.info -match 'post-verification-warnings') -and ($allowedInput.requiredToProceed -eq $true)) {
            #if we get this, just log it and auto-approve, then continue
            $postresponse = Approve-AkamaiPostVerificationWarnings -EnrollmentID $enrollmentId -ChangeId $script:ChangeID
            Write-VenafiDebug -Level 'Info' -Message "Approved post-verification-warnings"
            $postResponse | Write-VenafiDebug -Level 'Debug'
            return @{ Result = "Success"; }
        }
        else {
            $allowedInput | Write-VenafiDebug -Level 'Error' -Intro 'Unable to process allowedInput paths when approving post-verification warnings' -ThrowException
        }
    }
    catch {
        $_ | Write-VenafiDebug -Level 'Error' -Intro "Unable to approve the post verification warnings for enrollment $enrollmentId" -ThrowException
    }

}
function Activate-Certificate {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "", Justification = "Venafi Specification")]
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation
    Initialize-Akamai -General $General

    $enrollmentId = $General.VarText5
    Write-VenafiDebug -Level 'Debug' -Message "Working on verifications with EnrollmentID $enrollmentId"

    $isDualStack = Test-AkamaiDualStack -EnrollmentID $enrollmentId

    try {
        $script:changeId = Get-AkamaiPendingChangeId -EnrollmentId $enrollmentId

        if ( $null -eq $script:changeId ) {
            if ( Test-AkamaiDualStack -EnrollmentID $enrollmentId ) {
                Write-VenafiDebug -Message 'Multistacked certificate with no pending change, the other certificate has already processed.  Nothing to do here.'
                return (
                    @{
                        'Result' = "Success"
                    }
                )
            }

            "ChangeId was not set, cannot continue" | Write-VenafiDebug -ThrowException
        }

        Write-VenafiDebug -Level 'Info' -Message "ChangeId $($script:changeId) found"
        $allowedInput = Wait-CPSStatusChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID

        if (($allowedInput.info -match 'change-management-info') -and ($allowedInput.requiredToProceed -eq $true)) {
            $changeresponse = Approve-AkamaiChangeManagement -EnrollmentID $enrollmentId -ChangeId $script:ChangeID
            Write-VenafiDebug -Level 'Info' -Message "Approved move to production for enrollment $($enrollmentId)"
            $changeResponse | Write-VenafiDebug
        }
        elseif ($allowedInput -eq "completed") {
            Write-VenafiDebug -Level 'Info' -Message "Change request $($script:ChangeID) was completed"

            if ( $isDualStack ) {
                Write-VenafiDebug -Message 'This is a multi-stacked certificate, we need the other certificate to continue.  Approving its workflow.'

                try {

                    Initialize-VenafiPS -General $General -RequireApprove

                    # get apps with this enrollment ID, ensure only 2
                    $apps = Find-VdcObject -Pattern $enrollmentId -Attribute 'Text Field 5' -Class 'Adaptable App'
                    if ( $apps.count -ne 2 ) {
                        $apps | Write-VenafiDebug -Intro "we should only have 2 adaptable apps with enrollment ID $enrollmentId" -ThrowException
                    }

                    $apps | Write-VenafiDebug -Intro "Found the following adaptable apps with enrollment ID $enrollmentId"

                    $otherApp = $apps | Where-Object { $_.Path -ne $General.AppObjectDN }

                    $ticket = $otherApp | Get-VdcWorkflowTicket

                    if ( $ticket ) {
                        $ticket | Write-VenafiDebug -Intro 'Approving existing workflow ticket'
                        $ticket | Set-VdcWorkflowTicketStatus -Status Approved -Explanation 'Both multistacked certificates have been renewed and installed, moving this through the rest of the stages'
                    }
                }
                catch {
                    $_ | Write-VenafiDebug -Intro 'Failed to approve existing workflow ticket' -ThrowException
                }
                finally {
                    if ($VenafiSession) {
                        Revoke-VdcToken -Force -ErrorAction SilentlyContinue
                    }
                }
            }

            return @{ Result = "Success" }
        }
        else {
            $allowedInput | Write-VenafiDebug -Level 'Error' -Intro 'Unable to process allowedInput paths when approving change management' -ThrowException
        }

        Write-VenafiDebug -Level 'Info' -Message "Wait for production deployment to complete for $($enrollmentId)"

        $allowedInput = Wait-CPSStatusChange -EnrollmentID $enrollmentId -ChangeID $script:ChangeID -Completed

        if ($allowedInput -eq "completed") {
            Write-VenafiDebug -Level 'Info' -Message "Change request $($script:ChangeID) was completed"

            if ( $isDualStack ) {
                Write-VenafiDebug -Message 'This is a multi-stacked certificate, we need the other certificate to continue.  Approving its workflow ticket.'

                try {

                    Initialize-VenafiPS -General $General -RequireApprove

                    # get apps with this enrollment ID, ensure only 2
                    $apps = Find-VdcObject -Pattern $enrollmentId -Attribute 'Text Field 5' -Class 'Adaptable App'
                    if ( $apps.count -ne 2 ) {
                        $apps | Write-VenafiDebug -Intro "we should only have 2 adaptable apps with enrollment ID $enrollmentId" -ThrowException
                    }

                    $apps | Write-VenafiDebug -Intro "Found the following adaptable apps with enrollment ID $enrollmentId"

                    $otherApp = $apps | Where-Object { $_.Path -ne $General.AppObjectDN }

                    $ticket = $otherApp | Get-VdcWorkflowTicket

                    if ( $ticket ) {
                        $ticket | Write-VenafiDebug -Intro 'Approving existing workflow ticket'
                        $ticket | Set-VdcWorkflowTicketStatus -Status Approved -Explanation 'Both multistacked certificates have been renewed and installed, moving this through the rest of the stages'
                    }
                }
                catch {
                    $_ | Write-VenafiDebug -Intro 'Failed to approve existing workflow ticket' -ThrowException
                }
                finally {
                    if ($VenafiSession) {
                        Revoke-VdcToken -Force -ErrorAction SilentlyContinue
                    }
                }
            }

            return @{ Result = "Success" }
        }
    }
    catch {
        $_ | Write-VenafiDebug -Level 'Error' -Intro "Unable to activate the certificate for enrollment $enrollmentId" -ThrowException
    }

}
function Extract-Certificate {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "", Justification = "Venafi Specification")]
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )
    Write-FunctionDetail $PSCmdlet.MyInvocation
    Initialize-Akamai -General $General

    $enrollmentId = $General.VarText5
    if ( -not $enrollmentId ) {
        "Enrollment ID not set, cannot continue." | Write-VenafiDebug -ThrowException
    }

    $pkAlgo = $General.AssetName.replace('Akamai ', '').split(':')[0]
    Write-VenafiDebug -Level 'Debug' -Message "Looking for $($pkAlgo) key algorithm"

    try {
        Write-VenafiDebug -Level 'Info' -Message "Fetching certificate from the production environment for enrollment $enrollmentId"
        $extractresponse = Invoke-WithRetry -ScriptBlock { Get-CPSProductionDeployment -EnrollmentID $enrollmentId }
        $extractResponse | Write-VenafiDebug

        if ($null -ne $extractresponse.multiStackedCertificates -and @($extractresponse.multiStackedCertificates).count -ne 0) {
            $mpem = $extractresponse.multiStackedCertificates.certificate
            $mkeyAlgorithm = $extractresponse.multiStackedCertificates.keyAlgorithm
            [System.Security.Cryptography.X509Certificates.X509Certificate2]$mcert = ConvertTo-X509Certificate2 -CertificatePEM $mpem
        }
        else {
            Write-VenafiDebug -Level 'Warning' -Message "No multistacked certificate found"
        }
        if ($null -ne $extractresponse.primaryCertificate -and @($extractresponse.primaryCertificates).count -ne 0) {
            $ppem = $extractresponse.primaryCertificate.certificate
            $pkeyAlgorithm = $extractresponse.primaryCertificate.keyAlgorithm
            [System.Security.Cryptography.X509Certificates.X509Certificate2]$pcert = ConvertTo-X509Certificate2 -CertificatePEM $ppem
        }
        else {
            Write-VenafiDebug -Level 'Warning' -Message "No primary certificate found"
        }

        if (($mkeyAlgorithm -eq "ECDSA") -and ($pkAlgo -eq "ECC")) {
            $pem = $mpem
            $cert = $mcert
        }
        elseif ($mkeyAlgorithm -eq $pkAlgo) {
            $pem = $mpem
            $cert = $mcert
        }
        elseif (($pkeyAlgorithm -eq "ECDSA") -and ($pkAlgo -eq "ECC")) {
            $pem = $ppem
            $cert = $pcert
        }
        elseif ($pkeyAlgorithm -eq $pkAlgo) {
            $pem = $ppem
            $cert = $pcert
        }
        else {
            'Failed to process certificate info!' | Write-VenafiDebug -Level 'Error' -ThrowException
        }

        Write-VenafiDebug -Level 'Debug' -Message "PEM certificate extracted"
        return @{
            Result     = "Success"
            CertPem    = $pem
            Serial     = $cert.SerialNumber
            Thumbprint = $cert.Thumbprint
        }
    }
    catch {
        $_ | Write-VenafiDebug -Level 'Error' -Intro "Unable to Extract certificate for Enrollment $enrollmentId" -ThrowException
    }
}
function Discover-Certificates {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSUseApprovedVerbs", "", Justification = "Venafi Specification")]
    Param(
        [Parameter(Mandatory = $true, HelpMessage = 'General Parameters')]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo | Out-Null
    Initialize-Akamai -General $General

    Write-VenafiDebug -Level 'Info' -Message "Looking for enrollments"
    $enrollments = @()
    $enrollments = Get-CPSEnrollment -ContractID $General.HostAddress
    $apps = @()

    $csr = @{
        cn = $null
        c  = $null
        st = $null
        l  = $null
        o  = $null
        ou = $null
    }

    foreach ($enr in $enrollments) {

        try {
            $Id = $enr.id
            Write-VenafiDebug -Level 'Info' -Message "Processing enrollment $Id"
            $deployment = Get-CPSProductionDeployment -EnrollmentID $Id
        }
        catch {
            $_ | Write-VenafiDebug -Level 'Error' -Intro "Unable to get production deployment info for enrollment $Id"
            continue
        }

        if ($null -ne $deployment.multiStackedCertificates -and @($deployment.multiStackedCertificates).count -ne 0) {
            $EnrollmentTemplate = $enr
            $EnrollmentTemplate.csr = $csr
            $EnrollmentTemplate.psobject.properties.Remove('id')
            $EnrollmentTemplate.psobject.properties.Remove('productionSlots')
            $EnrollmentTemplate.psobject.properties.Remove('stagingSlots')
            $EnrollmentTemplate.psobject.properties.Remove('assignedSlots')
            $EnrollmentTemplate.psobject.properties.Remove('orgId')
            $EnrollmentTemplate.psobject.properties.Remove('location')
            $EnrollmentTemplate.psobject.properties.Remove('pendingChanges')
            $EnrollmentTemplate.networkConfiguration.dnsNameSettings.psobject.properties.Remove('dnsNames')
            $EnrollmentTemplate.PSObject.properties.Remove('autoRenewalStartTime')
            $EnrollmentTemplate.csr.PSObject.properties.Remove('preferredTrustChain')
            $EnrollmentTemplate.signatureAlgorithm = 'SHA-256'
            $json = $EnrollmentTemplate | ConvertTo-Json -depth 10 -Compress
            $pem = $deployment.multiStackedCertificates.certificate
            $cert = ConvertTo-X509Certificate2 $pem
            $name = $($cert.GetNameInfo(0, $false))
            $pkAlgo = $cert.PublicKey.Oid.FriendlyName
            $appMS = @{
                Name              = "$name $pkAlgo"
                PEM               = $pem
                ValidationAddress = $name
                ValidationPort    = "443"
                Attributes        = @{
                    "Text Field 3"     = $json
                    "Text Field 5"     = $Id
                    "Certificate Name" = 'Akamai {0}:{1}' -f $pkAlgo, $Id
                }
            }

            Write-VenafiDebug -Level 'Info' -Message "Adding $($appMS.Name) multiStacked certificate enrollment"
            $apps += $appMS
        }
        else {
            Write-VenafiDebug -Level 'Warning' -Message "No multistacked certificates found"
        }

        if ( $deployment.primaryCertificate ) {
            $EnrollmentTemplate = $enr
            $EnrollmentTemplate.csr = $csr
            $EnrollmentTemplate.psobject.properties.Remove('id')
            $EnrollmentTemplate.psobject.properties.Remove('productionSlots')
            $EnrollmentTemplate.psobject.properties.Remove('stagingSlots')
            $EnrollmentTemplate.psobject.properties.Remove('assignedSlots')
            $EnrollmentTemplate.psobject.properties.Remove('orgId')
            $EnrollmentTemplate.psobject.properties.Remove('location')
            $EnrollmentTemplate.psobject.properties.Remove('pendingChanges')
            $EnrollmentTemplate.networkConfiguration.dnsNameSettings.psobject.properties.Remove('dnsNames')
            $EnrollmentTemplate.PSObject.properties.Remove('autoRenewalStartTime')
            $EnrollmentTemplate.csr.PSObject.properties.Remove('preferredTrustChain')
            $EnrollmentTemplate.signatureAlgorithm = 'SHA-256'
            $json = $EnrollmentTemplate | ConvertTo-Json -depth 10 -Compress
            $pem = $deployment.primaryCertificate.certificate
            $cert = ConvertTo-X509Certificate2 $pem
            $name = $($cert.GetNameInfo(0, $false))
            $pkAlgo = $cert.PublicKey.Oid.FriendlyName
            $app = @{
                Name              = "$name $pkAlgo"
                PEM               = $pem
                ValidationAddress = $name
                ValidationPort    = "443"
                Attributes        = @{
                    "Text Field 3"     = $json
                    "Text Field 5"     = $Id
                    "Certificate Name" = 'Akamai {0}:{1}' -f $pkAlgo, $Id
                }
            }

            Write-VenafiDebug -Level 'Info' -Message "Adding $($app.Name) primary certificate enrollment"
            $apps += $app
        }
        else {
            Write-VenafiDebug -Level 'Warning' -Message "No primary certificate found"
        }
    }

    # Certificates with the same common name across different enrollments (e.g. different
    # geographies/slots) would otherwise collide on Name and ping-pong between active/obsolete
    # on each discovery run. Append the enrollment ID to disambiguate only the colliding names.
    $duplicateNames = $apps | Group-Object -Property Name | Where-Object { $_.Count -gt 1 }
    foreach ($group in $duplicateNames) {
        foreach ($app in $group.Group) {
            $enrollmentId = $app.Attributes.'Text Field 5'
            $app.Name = "$($app.Name) ($enrollmentId)"
        }
    }

    Write-VenafiDebug -Level 'Info' -Message "Returning $($apps.Count) application objects"
    $japps = ConvertTo-Json -InputObject $apps -Depth 5

    $japps | Write-VenafiDebug -Level 'Debug' -Intro "Applications to return to CMSH"

    return @{
        Result       = "Success"
        Applications = $apps
    }
}
<###################### THE FUNCTIONS AND CODE BELOW THIS LINE ARE NOT CALLED DIRECTLY BY CMSH ######################>

function New-AkamaiEnrollment {

    [CmdletBinding()]

    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ContractID,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [PSCustomObject] $EnrollmentTemplate
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -NoBoundParams

    try {
        # Requires the depth argument so it will convert single element arrays to array instead of string
        $requestBody = ConvertTo-Json $enrollmentTemplate -Compress -Depth 10
        $enrollment = New-CPSEnrollment -Body $requestBody -ContractID $contractId -Verbose
        Write-VenafiDebug -Level 'Info' -Message "New Enrollment created: $($enrollment.enrollment)"

        if ($enrollment.changes.Count -ne 1) {
            Write-VenafiDebug -Level 'Error' -Message "Unexpected number of changes on the enrollment. Expected 1 change but found $($enrollment.changes.Count). Further processing has been aborted." -ThrowException
        }
        #Get the ID which is just the last numbers
        if ($enrollment.enrollment -match "enrollments\/(\d+)$") { $enrollmentId = $Matches[1] }
        $script:ChangeID = $enrollment.changes.split('/')[-1]

        $return = @{
            id         = $enrollmentId
            enrollment = $enrollment.enrollment
            ChangeId   = $script:ChangeID
            changes    = $enrollment.changes
        }
        $return | Write-VenafiDebug -Level 'Debug' -Intro 'response'
        return $return
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}
function Compare-JsonObjects {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [PSCustomObject]
        $Ref,
        [Parameter(Mandatory)]
        [PSCustomObject]
        $Diff,
        [Parameter()]
        [Switch]
        $AddNewJsonProperties,
        [Parameter()]
        [Switch]
        $RecursePsObjects,
        [Parameter()]
        [Switch]
        $CombineArrays
    )

    begin {

        Write-FunctionDetail $PSCmdlet.MyInvocation -NoBoundParams

        if ( $null -eq $Ref ) {
            return $null
        }
        if ( $null -eq $Diff ) {
            Write-VenafiDebug -Level 'Warning' -Message "Difference file is null!"
        }
    }

    process {
        $joined = [PSCustomObject]@{}
        if ( $Ref -is [PSCustomObject] ) {
            $RefProps = $Ref.PsObject.Properties.name
            $DiffProps = $Diff.PsObject.Properties.name
            #Do a compare of this level
            $compare = Compare-Object -ReferenceObject $RefProps -DifferenceObject $DiffProps -IncludeEqual
            #Add reference properties that are not present at this level
            $compare | Where-Object { $_.SideIndicator -eq "<=" } | ForEach-Object {
                $Refproperty = $_.InputObject
                $joined | Add-Member -MemberType NoteProperty -Name $Refproperty -Value $Ref.($Refproperty)
                Write-VenafiDebug -Level 'Debug' -Message "Add missing '$( $Refproperty )' from reference side"
            }
            #Add any missing difference properties that are not present at this level
            if ( $AddNewJsonProperties -eq $true ) {
                $compare | Where-Object { $_.SideIndicator -eq "=>" } | ForEach-Object {
                    $Diffproperties = $_.InputObject
                    $joined | Add-Member -MemberType NoteProperty -Name $Diffproperties -Value $Diff.($Diffproperties)
                    Write-VenafiDebug -Level 'Debug' -Message "Add missing '$( $Diffproperties )' from difference side"
                }
            }
            #Evaluate properties that are matched on both sides at this level
            $compare | Where-Object { $_.SideIndicator -eq "==" } | ForEach-Object {
                $MatchProperty = $_.InputObject
                if ( $RecursePsObjects -eq $true -and
                    $Ref.($MatchProperty) -is [PSCustomObject] -and
                    $Diff.($MatchProperty) -is [PSCustomObject] -and
                    @($Diff.($MatchProperty).psobject.properties).Count -gt 0 ) {
                    #RecursePsObjects - expand all PSCustomObjects, add to $joined
                    Write-VenafiDebug -Level 'Debug' -Message "Going recursively into '$( $MatchProperty )'"
                    $params = [Hashtable]@{
                        "Ref"                  = $Ref.($MatchProperty)
                        "Diff"                 = $Diff.($MatchProperty)
                        "AddNewJsonProperties" = $AddNewJsonProperties
                        "RecursePsObjects"     = $RecursePsObjects
                        "CombineArrays"        = $CombineArrays
                    }
                    $recursive = Compare-JsonObjects @params
                    $joined | Add-Member -MemberType NoteProperty -Name $MatchProperty -Value $recursive
                }
                elseif ( $CombineArrays -eq $true -and
                    $Ref.($MatchProperty) -is [Array] -and
                    $Diff.($MatchProperty) -is [Array] ) {
                    #Combine any array objects
                    Write-VenafiDebug -Level 'Debug' -Message "Combine arrays from '$( $MatchProperty )'"
                    $newArr = [Array]@( $Ref.($MatchProperty) + $Diff.($MatchProperty) ) | Sort-Object -unique
                    $joined | Add-Member -MemberType NoteProperty -Name $MatchProperty -Value $newArr
                }
                else {
                    #Finally just overwrite existing reference values with the difference value
                    $joined | Add-Member -MemberType NoteProperty -Name $MatchProperty -Value $Diff.($MatchProperty)
                }
            }
            Write-VenafiDebug -Level 'Debug' -Message "Using remaining values from difference side"
        }
        return $joined
    }
}
function Update-AkamaiEnrollment {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string] $EnrollmentID,
        [Parameter(Mandatory)]
        [object] $CSRInfo,
        [Parameter()]
        [string[]] $CSRSANs,
        [Parameter()]
        [PSCustomObject] $EnrollmentUpdate,
        [Parameter()]
        [string] $KeyAlgorithm,
        [Parameter()]
        [switch] $UpdateRemote
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        #Fetch the configuration of the current certificate
        $CPSObj = Get-CPSEnrollment -EnrollmentID $enrollmentId
        $enrollmentTemplate = $CPSObj
        $CPSObj | Write-VenafiDebug -Level 'Debug' -Intro 'Akamai current enrollment template'

        ##  Set to override the pendingchanges if there are any
        if ([string]::IsNullOrEmpty($enrollmentTemplate.pendingchanges[0])) {
            $cancelpendingchanges = $false
        }
        else {
            $cancelpendingchanges = $true
        }

        # Add CSR info and updates before submission
        $params = @{
            NewTemplate = $enrollmentTemplate
            CSRInfo     = $CSRInfo
        }
        if ($CSRSANs) {
            $params.Add('CSRSANs', $CSRSANs)
        }
        # Compare the JSON from Get-CPSEnrollment to what is supplied by the custom field
        if (($EnrollmentUpdate) -and ($UpdateRemote)) {
            $params.Add('EnrollmentUpdate', $EnrollmentUpdate)
            $params.Add('UpdateRemote', $UpdateRemote)
        }
        elseif ($EnrollmentUpdate) {
            $params.Add('EnrollmentUpdate', $EnrollmentUpdate)
        }
        $enrollmentInfo = Update-AkamaiTemplate @params

        # Update the record and force the reissue of the CSR
        $enrollmentbody = ConvertTo-Json $enrollmentInfo -Depth 10 -Compress
        $params = @{
            EnrollmentID = $EnrollmentID
            Body         = $enrollmentbody
            ForceRenewal = $true
        }
        if ($cancelpendingchanges) {
            $params.Add('AllowCancelPendingChanges', $true)
            $params.Add('RenewalDateCheckOverride', $false)
        }
        #Get deployment info if multistacked
        if ($enrollmentInfo.enableMultiStackedCertificates) {
            $deployedinfo = Get-CPSProductionDeployment -EnrollmentID $EnrollmentID
            if ($KeyAlgorithm -eq "ECC") {
                $keyAlgo = "ECDSA"
            }
            else {
                $keyAlgo = $KeyAlgorithm
            }
            if ((@($deployedinfo.multiStackedCertificates).count -eq 0) -and ($deployedinfo.primaryCertificate.keyAlgorithm -ne $keyAlgo)) {
                $params.Remove('ForceRenewal')
                $params.Add('AllowMissingCertificateAddition', $true)
            }
        }
        $params | Write-VenafiDebug -Intro 'Set-CpsEnrollment params'
        $enrollment = Set-CPSEnrollment @params
        Write-VenafiDebug -Level 'Info' -Message "Enrollment update created: $($enrollment.enrollment)"

        if ($enrollment.changes.Count -ne 1) {
            Write-VenafiDebug -Level 'Error' -Message "Unexpected number of changes on the enrollment. Expected 1 change but found $($enrollment.changes.Count). Further processing has been aborted." -ThrowException
        }

        #Get the ID which is just the last numbers
        if ($enrollment.enrollment -match "enrollments\/(\d+)$") { $enrollmentId = $Matches[1] }
        $script:ChangeID = $enrollment.changes.split('/')[-1]

        $return = @{
            id         = $enrollmentId
            enrollment = $enrollment.enrollment
            ChangeId   = $script:ChangeID
            changes    = $enrollment.changes
        }
        $return | Write-VenafiDebug -Level 'Debug' -Intro 'response'
        return $return
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}
function New-AkamaiTemplate {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable] $CSRInfo,
        [Parameter()]
        [Array] $CSRSANs,
        [Parameter()]
        [string] $Company,
        [Parameter()]
        [string] $Street,
        [Parameter()]
        [string] $City,
        [Parameter()]
        [string] $State,
        [Parameter()]
        [string] $Country,
        [Parameter()]
        [string] $ZipCode,
        [Parameter()]
        [string] $FirstName,
        [Parameter()]
        [string] $Surname,
        [Parameter()]
        [string] $Email,
        [Parameter()]
        [string] $Phone
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $MinTemplate = '{
        "ra": "third-party",
        "validationType": "third-party",
        "certificateType": "third-party",
        "certificateChainType":  "default",
        "networkConfiguration": {
            "geography": "core",
            "secureNetwork": "standard-tls",
            "mustHaveCiphers":  "ak-akamai-2020q1",
            "preferredCiphers":  "ak-akamai-2020q1",
            "disallowedTlsVersions":[
                                        "TLSv1",
                                        "TLSv1_1"
                                    ],
            "sniOnly": true,
            "quicEnabled": false,
            "dnsNameSettings": {
                                    "cloneDnsNames": true
                                },
            "ocspStapling": "on"
        },
        "signatureAlgorithm": "SHA-256",
        "changeManagement": false,
        "csr": {
            "cn": null,
            "o":null,
            "ou":null,
            "l":null,
            "st":null,
            "c":null
        },
        "org":{
            "name":null,
            "addressLineOne":null,
            "addressLineTwo":null,
            "city": null,
            "region":null,
            "postalCode":null,
            "country":null,
            "phone":null
            },
        "adminContact":{
            "firstName":null,
            "lastName":null,
            "phone":null,
            "email":null,
            "addressLineOne":  null,
            "addressLineTwo":  null,
            "city":  null,
            "country":  null,
            "organizationName":  null,
            "postalCode":  null,
            "region":  null,
            "title":  null
            },
        "techContact":{
            "firstName":null,
            "lastName":null,
            "phone":null,
            "email":null,
            "addressLineOne":  null,
            "addressLineTwo":  null,
            "city":  null,
            "country":  null,
            "organizationName":  null,
            "postalCode":  null,
            "region":  null,
            "title":  null
            },
        "thirdParty": {
                        "excludeSans": true
                    },
        "enableMultiStackedCertificates": true,
        "maxAllowedSanNames":  100,
        "maxAllowedWildcardSanNames":  100
    }'
    $OutTempl = ConvertFrom-Json $MinTemplate
    #Update the CSR info
    if ($CSRInfo.CN) {
        $OutTempl.csr.cn = $CSRInfo.CN
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing Common Name (CN) information. This is required by Akamai." -ThrowException
    }
    if ($CSRInfo.C) {
        $OutTempl.csr.c = $CSRInfo.C
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing Country Field. This is required by Akamai." -ThrowException
    }
    if ($CSRInfo.L) {
        $OutTempl.csr.l = $CSRInfo.L
    }
    else {
        $OutTempl.csr.psobject.properties.remove('l')
    }
    if ($CSRInfo.O) {
        $OutTempl.csr.o = $CSRInfo.O
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing Organization Field. This is required by Akamai." -ThrowException
    }
    if ($CSRInfo.OU) {
        $OutTempl.csr.ou = $CSRInfo.OU
    }
    else {
        $OutTempl.csr.psobject.properties.remove('ou')
    }
    if ($CSRInfo.ST) {
        $OutTempl.csr.st = $CSRInfo.ST
    }
    else {
        $OutTempl.csr.psobject.properties.remove('st')
    }
    if ($Company) {
        $OutTempl.org.name = $Company
    }
    elseif ($CSRInfo.O) {
        $OutTempl.org.name = $CSRInfo.O
    }
    else {
        $OutTempl.org.name = $null
    }
    if ($Street) {
        $OutTempl.org.addressLineOne = $Street
    }
    else {
        $OutTempl.org.addressLineOne = $null
    }
    if ($City) {
        $OutTempl.org.city = $City
    }
    elseif ($CSRInfo.L) {
        $OutTempl.org.city = $CSRInfo.L
    }
    else {
        $OutTempl.org.city = $null
    }
    if ($State) {
        $OutTempl.org.region = $State
    }
    elseif ($CSRInfo.ST) {
        $OutTempl.org.region = $CSRInfo.ST
    }
    else {
        $OutTempl.org.region = $null
    }
    if ($ZipCode) {
        $OutTempl.org.postalCode = $ZipCode
    }
    else {
        $OutTempl.org.postalCode = $null
    }
    if ($Country) {
        $OutTempl.org.country = $Country
    }
    elseif ($CSRInfo.C) {
        $OutTempl.org.country = $CSRInfo.C
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing Country information. This is required by Akamai." -ThrowException
    }
    if ($FirstName) {
        $OutTempl.adminContact.firstName = $FirstName
        $OutTempl.techContact.firstName = $FirstName
    }
    else {
        $OutTempl.adminContact.firstName = $null
        $OutTempl.techContact.firstName = $null
    }
    if ($Surname) {
        $OutTempl.adminContact.lastName = $Surname
        $OutTempl.techContact.lastName = $Surname
    }
    else {
        $OutTempl.adminContact.lastName = $null
        $OutTempl.techContact.lastName = $null
    }
    if ($Email -match "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$") {
        $OutTempl.adminContact.email = $Email
        $techEmail = $Email.split('@')[-2]
        $OutTempl.techContact.email = $techEmail + '@akamai.com'
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing or Bad Email Address. This is required by Akamai." -ThrowException
    }
    if ($Phone -match "\b?(\+\d{2})?(-| )?(\(?\d{3,4}\)?)?(-| )?\d{3,4}(-| )?\d{3,4}\b") {
        $OutTempl.org.phone = $Phone
        $OutTempl.adminContact.phone = $Phone
        $OutTempl.techContact.phone = $Phone
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing or Bad Phone Number. This is required by Akamai." -ThrowException
    }

    #The sans property may or may not be present, so add it if needed, and remove it if not
    if ($PSBoundParameters.ContainsKey('CSRSANs')) {
        $SANlist = New-Object -TypeName 'System.Collections.ArrayList'
        $SANlist = $CSRSANs
        if (-not $SANlist -contains $CSRInfo.CN) {
            $SANlist += $CSRInfo.CN
        }
        $templateparams = @{
            InputObject = $OutTempl.csr
            MemberType  = 'NoteProperty'
            Name        = 'sans'
            Value       = $SANlist
            Force       = $true
        }
        Add-Member @templateparams
    }
    else {
        $OutTempl.csr.psobject.properties.remove('sans')
    }

    ###   Update the signatureAlgorithm if it is blank
    if ([string]::IsNullOrEmpty($OutTempl.signatureAlgorithm)) {
        $OutTempl.signatureAlgorithm = 'SHA-256'
    }
    $OutTempl | Write-VenafiDebug -Level 'Debug' -Intro 'Completed enrollment template'

    return $OutTempl
}
function Update-AkamaiTemplate {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [PSCustomObject] $NewTemplate,
        [Parameter(Mandatory)] [hashtable] $CSRInfo,
        [Parameter()] [Array] $CSRSANs,
        [Parameter()] [PSCustomObject] $EnrollmentUpdate,
        [Parameter()] [switch] $UpdateRemote
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    # Compare $NewTemplate to $EnrollmentUpdate to make sure changes set in Venafi are pushed
    if ( $EnrollmentUpdate ) {
        if ( $UpdateRemote ) {
            $mergeTemplate = (Compare-JsonObjects -Ref $NewTemplate -Diff $EnrollmentUpdate -RecursePsObjects -AddNewJsonProperties)
        }
        else {
            $mergeTemplate = (Compare-JsonObjects -Ref $EnrollmentUpdate -Diff $NewTemplate -RecursePsObjects -AddNewJsonProperties)
        }
    }
    else {
        $mergeTemplate = $NewTemplate
    }

    #enableMultiStackedCertificates is a special case and must stay once set
    if ($NewTemplate.enableMultiStackedCertificates -eq $mergeTemplate.enableMultiStackedCertificates) {
        Write-VenafiDebug -Level 'Debug' -Message "enableMultiStackedCertificates parameter validated."
    }
    elseif ($NewTemplate.enableMultiStackedCertificates -ne $mergeTemplate.enableMultiStackedCertificates) {
        $mergeTemplate.enableMultiStackedCertificates = $NewTemplate.enableMultiStackedCertificates
        Write-VenafiDebug -Level 'Debug' -Message "enableMultiStackedCertificates parameter reset to remote."
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing enableMultiStackedCertificates information. This is required by Akamai." -ThrowException
    }

    #Update the CSR info
    if ($CSRInfo.CN -eq $mergeTemplate.csr.cn) {
        Write-VenafiDebug -Level 'Debug' -Message "CN validated."
    }
    elseif (($CSRInfo.CN) -and ($null -ne $mergeTemplate.csr.cn)) {
        Write-VenafiDebug -Level 'Debug' -Message "Cannot change CN to $($CSRInfo.CN)."
    }
    elseif ($null -eq $mergeTemplate.csr.cn) {
        $mergeTemplate.csr.cn = $CSRInfo.CN
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing Common Name (CN) information. This is required by Akamai." -ThrowException
    }

    if ($CSRInfo.C) {
        $mergeTemplate.csr.c = $CSRInfo.C
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing Country (C) information. This is required by Akamai." -ThrowException
    }

    if ($CSRInfo.L) {
        $mergeTemplate.csr.l = $CSRInfo.L
    }
    else {
        $mergeTemplate.csr.psobject.properties.remove('l')
    }

    if ($CSRInfo.O) {
        $mergeTemplate.csr.o = $CSRInfo.O
    }
    else {
        Write-VenafiDebug -Level 'Error' -Message "Missing Organization (O) information. This is required by Akamai." -ThrowException
    }

    if ($CSRInfo.OU) {
        $mergeTemplate.csr.ou = $CSRInfo.OU
    }
    else {
        $mergeTemplate.csr.psobject.properties.remove('ou')
    }

    if ($CSRInfo.ST) {
        $mergeTemplate.csr.st = $CSRInfo.ST
    }
    else {
        $mergeTemplate.csr.psobject.properties.remove('st')
    }

    #The sans property may or may not be present, so add it if needed, and remove it if not
    if ($PSBoundParameters.ContainsKey('CSRSANs')) {
        $SANlist = New-Object -TypeName 'System.Collections.ArrayList'
        $SANlist = $CSRSANs
        if (-not $SANlist -contains $CSRInfo.CN) {
            $SANlist += $CSRInfo.CN
        }
        $templateparams = @{
            InputObject = $mergeTemplate.csr
            MemberType  = 'NoteProperty'
            Name        = 'sans'
            Value       = $SANlist
            Force       = $true
        }
        Add-Member @templateparams
    }
    else {
        $mergeTemplate.csr.psobject.properties.Remove('sans')
    }

    "Current value for sniOnly '{0}' and cloneDnsNames '{1}'" -f $mergeTemplate.networkConfiguration.sniOnly, $mergeTemplate.networkConfiguration.dnsNameSettings.cloneDnsNames | Write-VenafiDebug

    ###   Update the signatureAlgorithm if it is blank
    if ([string]::IsNullOrEmpty($mergeTemplate.signatureAlgorithm)) {
        $mergeTemplate.signatureAlgorithm = 'SHA-256'
    }
    # Make sure the following is not in the template being used for enrollment
    $mergeTemplate.psobject.properties.Remove('orgId')
    $mergeTemplate.psobject.properties.Remove('location')
    $mergeTemplate.PSObject.properties.Remove('pendingChanges')
    if ( $mergeTemplate.networkConfiguration.dnsNameSettings ) {
        $mergeTemplate.networkConfiguration.dnsNameSettings.psobject.properties.Remove('dnsNames')
    }
    $mergeTemplate.PSObject.properties.Remove('autoRenewalStartTime')
    $mergeTemplate.csr.PSObject.properties.Remove('preferredTrustChain')

    $mergeTemplate | ConvertTo-Json | Write-VenafiDebug -Intro 'Completed Enrollment Template:'

    return $mergeTemplate
}
function Get-AkamaiEnrollmentCSR {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [string] $EnrollmentID,
        [Parameter(Mandatory)] [string] $ChangeId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        #Fetch the csr from the enrollment change
        Write-VenafiDebug -Level 'Debug' -Message "Getting third-party CSR from Akamai for enrollment $($EnrollmentID)"
        $csr = Get-CPSCSR -EnrollmentID $EnrollmentID -ChangeID $ChangeId

        return $csr
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}

function ConvertTo-X509Certificate2 {

    param (
        [Parameter(Mandatory)]
        [string] $CertificatePEM
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $b64 = $CertificatePEM -replace "`r|`n|-----BEGIN CERTIFICATE-----|-----END CERTIFICATE-----|\\n"
    return [System.Security.Cryptography.X509Certificates.X509Certificate2]::new([Convert]::FromBase64String($b64))
}

function Split-ChainData {

    param (
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('ChainData')]
        [String] $InputObject
    )

    process {
        $pemLines = $InputObject -split '\r\n'

        $certPem = @()

        for ($i = 0; $i -lt $pemLines.Count; $i++) {
            if ($pemLines[$i].Contains('-----BEGIN')) {
                $iStart = $i
                continue
            }
            if ($pemLines[$i].Contains('-----END')) {
                $thisPemLines = $pemLines[$iStart..$i]
                $certPem += ($thisPemLines -join "`n") -replace "`r"
                continue
            }
        }
    }

    end {
        $certPem
    }
}
function Submit-AkamaiEnrollmentCertificate {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [string] $EnrollmentId,
        [Parameter(Mandatory)] [string] $ChangeId,
        [Parameter(Mandatory)] [string] $CertificatePEM,
        [Parameter(Mandatory)] [string] $CertificateChainPEM,
        [Parameter(Mandatory)] [string] $KeyAlgorithm
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        Write-VenafiDebug -Level 'Debug' -Message "Sending third-party CSR to Akamai for enrollment $($EnrollmentID)"
        $Result = Add-CPSThirdPartyCert -EnrollmentID $EnrollmentId -ChangeID $ChangeId -Certificate $CertificatePEM -TrustChain $CertificateChainPEM -KeyAlgorithm $KeyAlgorithm
        return $Result
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}
function Approve-AkamaiPreVerificationWarnings {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [string] $EnrollmentId,
        [Parameter(Mandatory)] [string] $ChangeId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        Write-VenafiDebug -Level 'Info' -Message "Logging pre-verification warnings from the server for enrollment $($EnrollmentId) and change $($ChangeId)"
        $cWarnings = Get-CPSPreVerificationWarnings -EnrollmentID $EnrollmentId -ChangeID $ChangeId
        if ($null -eq $cWarnings.warnings) {
            Write-VenafiDebug -Level 'Debug' -Message "No pre-verification warnings from the server"
        }
        else {
            Write-VenafiDebug -Level 'Warning' -Message $cWarnings.warnings
        }
        Write-VenafiDebug -Level 'Info' -Message "Acknowledging pre-verification warnings from the server for enrollment $($EnrollmentId) and change $($ChangeId)"
        $cConfirm = Confirm-CPSPreVerificationWarnings -EnrollmentID $EnrollmentId -ChangeID $ChangeId -Acknowledgement 'acknowledge'
        if ($null -eq $cConfirm) {
            Write-VenafiDebug -Level 'Error' -Message "There is no pre-verification acknowledgement for enrollment $EnrollmentId" -ThrowException
        }
        else {
            Write-VenafiDebug -Level 'Debug' -Message $cConfirm.change
            return $true
        }
    }
    catch {
        $_ | Write-VenafiDebug
        return $false
    }
}
function Approve-AkamaiPostVerificationWarnings {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [string] $EnrollmentId,
        [Parameter(Mandatory)] [string] $ChangeId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        $cWarnings = Get-CPSPostVerificationWarnings -EnrollmentID $EnrollmentId -ChangeID $ChangeId

        if ( -not $cWarnings.warnings ) {
            Write-VenafiDebug -Level 'Debug' -Message "No post-verification warnings from the server"
        }
        else {
            Write-VenafiDebug -Level 'Warning' -Message $cWarnings.warnings

            Write-VenafiDebug -Level 'Info' -Message "Acknowledging post-verification warnings from the server for enrollment $($EnrollmentId) and change $($ChangeId)"

            $cConfirm = Confirm-CPSPostVerificationWarnings -EnrollmentID $EnrollmentId -ChangeID $ChangeId -Acknowledgement 'acknowledge'

            if ( -not $cConfirm) {
                "There is no post-verification acknowledgement for enrollment $EnrollmentId" | Write-VenafiDebug -ThrowException
            }
            else {
                Write-VenafiDebug -Level 'Debug' -Message $cConfirm.change
                return $cConfirm.change
            }
        }
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}
function Approve-AkamaiChangeManagement {


    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [string] $EnrollmentId,
        [Parameter(Mandatory)] [string] $ChangeId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        Write-VenafiDebug -Message 'getting staging change status'
        $status = Get-CPSChangeStagingStatus -EnrollmentID $EnrollmentId -ChangeID $ChangeId

        if ( -not $status ) {
            return 'no current staging changes'
        }
        else {
            $status | Write-VenafiDebug -Intro 'current staging change'

            Write-VenafiDebug -Level 'Info' -Message "Acknowledging change management from the server for enrollment $($EnrollmentId) and change $($ChangeId)"

            $cConfirm = Complete-CPSChange -EnrollmentID $EnrollmentId -ChangeID $ChangeId -Acknowledgement 'acknowledge' -Hash $cValidation.validationResultHash

            if ($null -eq $cConfirm) {
                "There is no change management acknowledgement for enrollment $EnrollmentId" | Write-VenafiDebug -ThrowException
            }
            else {
                $cConfirm.change | Write-VenafiDebug -Intro 'change success'
                return $cConfirm.change
            }
        }
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}

# SIG # Begin signature block
# MIIh3AYJKoZIhvcNAQcCoIIhzTCCIckCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBEjlM8HveiVVtU
# dp8y+bGfA7sV60yuuEEhVqLHFjBP5qCCGtUwggeXMIIFf6ADAgECAhANR7WuDvkI
# 4vKmNjKy+esUMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBD
# b2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjYwODE3MDAw
# MDAwWhcNMjcwODE2MjM1OTU5WjCBnjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCkNh
# bGlmb3JuaWExFDASBgNVBAcTC1NhbnRhIENsYXJhMSEwHwYDVQQKExhQYWxvIEFs
# dG8gTmV0d29ya3MsIEluYy4xHjAcBgNVBAsTFVByb2Zlc3Npb25hbCBTZXJ2aWNl
# czEhMB8GA1UEAxMYUGFsbyBBbHRvIE5ldHdvcmtzLCBJbmMuMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAvVonIqLn25b0GSYEN1vhecayc0B8Gj8LQR4s
# RrVIKgMZBGUfcrZbcYj6KuNP18dS024QWYjsGVRmPGJrQbzss8+vaJA9we1C4LbS
# VwPiXoNqvNluLcioXIPrDpIys/kcrMC/caP/pMunxajiXYO+B+1Gv3hBtCX1efQe
# chcf4/x0hx44Kip2LtgzRG2w4q1/rz0VpZL1LmNOh1dMj5MDft9o4FfFAA1GOOOe
# Od060PSY+E0DixRaL48GIbCu+oQxRlo2GfpHXeXM2F2EEr3KAqfxEEGwv7qM6GqH
# xP5DI45lEcVcLtiv5CNPa4iH+LAPag1GDihgbzK+meryExQHH4/aaPXwu00dqDRZ
# L2iz8JegSSFZ7V2XYkhkov7B5em46cF06fOyrK76WyNYmr3Fp2X2kE45gyUhKPDl
# GDkpTvDQ+Di8KNw9XVc22k3YVJJlhSZb2smsD3PA7dyHHTOoNsd0vSngyOx3ba22
# PXCLROylgQ5QJKxHyw5tvVxxqjuLRT9T2SRoovQFhqhnn5WZBERdgrjvGWrgnaL7
# C9IXlnWza1oW6wHK3zRdZqNoop8+sueBVlDK+JzShCyqxHBzCb4/cEQg2EgXbBx7
# fQdOHU3nC5/SWAun442kxq47RdMUy2w/1/v+LVpk8H9koXpJXfUvKGwrkvjOInUh
# mXBRtCkCAwEAAaOCAgMwggH/MB8GA1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl
# 9E5CMB0GA1UdDgQWBBQvDoyn5zdE/9KvaLGaM/RICo8CyjA+BgNVHSAENzA1MDMG
# BmeBDAEEATApMCcGCCsGAQUFBwIBFhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9D
# UFMwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8E
# ga0wgaowU6BRoE+GTWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBP
# hk1odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2Rl
# U2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcw
# gYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEF
# BQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIw
# ADANBgkqhkiG9w0BAQsFAAOCAgEAW6iVWK4gZ7tLhvVXvPSN36R5iRjryaGP8b1U
# xOYRqN41lXJlyqKNfcM+EJTOKyZye447zCAx6AFpSx+Skl6Yuwaj9wq7MukCis1S
# g6djYp8008m4LL7J9+2OybssvTgRFcES73XsZWEfulUUXr0+OjAc3RjzNlaRaReM
# H7fpYMrSDouMWLW/YYBfIEm44beVicGDrfaxSGXc+u1Y7lhWZmVTKJOGVQ/V9Nol
# xhtvrlWTjeh5+Bh59MZnKKpzDCIubtBPxv6h1UkS0Iev08CeEgLIKw1l536OuB9o
# tnBVnxhSOFp+PgEx0n655EqSQPpHA2NB39rCCkCLMFJiWP1Q6gq0zwVndfsI61rc
# Lo49OBVNAD+OCrDYOUF/1zHALI0rWeT/FWcrgUWfioN7Ne2Q4baKvTSTb9I6b6Js
# v+nPsM9WT7siJRlOdTVUw7wGe9NIsysPZXPDaXP7QRnyB0XBNYKlOzwf7Z+d8sDZ
# iUcdskEibFFaPG03ld35lcV2c5dCIan/mmQn1L6leY7l6SqgctEqk5SV8r15zDy0
# 4Kn6heB/srzL7uZQjftVfn5A++RiWwv6Gi/f9OdVLzgjG5wIRhCdOYp6+DMNELRU
# oczQparY/vZaqTckOmZATLKlCKa3IwapPP3NFdRxdpag6X/EOIiGoVPS8oc9aLqb
# Cry73SQwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEB
# DAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNV
# BAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQg
# SUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJ
# BgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5k
# aWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPs
# wqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLk
# X9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4TmdDtt
# ceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hI
# qGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2
# scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm
# 2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaH
# iZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3r
# M9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJ
# B+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzTQRES
# W+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kxfgom
# mfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0G
# A1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLL
# gjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQG
# CCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKG
# N2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJv
# b3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQu
# Y29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYGBFUd
# IAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72arKGH
# LOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFIDyE7Q
# Kt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajw
# vy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQ
# Pfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFq
# I2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwgga0MIIEnKAD
# AgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yNTA1
# MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBU
# aW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwggIiMA0GCSqGSIb3
# DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphBcr48RsAcrHXbo0ZodLRRF51NrY0N
# lLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6pvF4uGjwjqNjfEvUi6wuim5bap+0l
# gloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHeHYNnQxqXmRinvuNgxVBdJkf77S2u
# PoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEdgkFiDNYiOTx4OtiFcMSkqTtF2hfQ
# z3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjUjsZvkgFkriK9tUKJm/s80FiocSk1
# VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bRVFLeGkuAhHiGPMvSGmhgaTzVyhYn
# 4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeSLsJygoLPp66bkDX1ZlAeSpQl92QO
# MeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIVNSaz7BX8VtYGqLt9MmeOreGPRdtB
# x3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL6s36czwzsucuoKs7Yk/ehb//Wx+5
# kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2ZdSoQbU2rMkpLiQ6bGRinZbI4OLu9B
# MIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFUeEY0qVjPKOWug/G6X5uAiynM7Bu2
# ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQU
# 729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6
# mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcGCCsG
# AQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29t
# MEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNl
# cnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3Js
# My5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNVHSAE
# GTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBABfO
# +xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/T8ObXAZz8OjuhUxjaaFdleMM0lBr
# yPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQE7jU/kXjjytJgnn0hvrV6hqWGd3r
# LAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9rEVKChHyfpzee5kH0F8HABBgr0Udq
# irZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y1IsA0QF8dTXqvcnTmpfeQh35k5zO
# CPmSNq1UH410ANVko43+Cdmu4y81hjajV/gxdEkMx1NKU4uHQcKfZxAvBAKqMVuq
# te69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3ty9qIijanrUR3anzEwlvzZiiyfTPj
# LbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcytL5TTLL4ZaoBdqbhOhZ3ZRDUphPv
# SRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEBYTptMSbhdhGQDpOXgpIUsWTjd6xp
# R6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud/v4+7RWsWCiKi9EOLLHfMR2ZyJ/+
# xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiSuEtQvLsNz3Qbp7wGWqbIiOWCnb5W
# qxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZPubdcMIIG7TCCBNWgAwIBAgIQCE/c
# M09+RU7bww+P+ZIYNTANBgkqhkiG9w0BAQsFADBpMQswCQYDVQQGEwJVUzEXMBUG
# A1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQg
# RzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExMB4XDTI2MDgw
# NTAwMDAwMFoXDTM3MTEwNDIzNTk1OVowYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoT
# DkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2VydCBTSEEyNTYgUlNBNDA5
# NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjYgMTCCAiIwDQYJKoZIhvcNAQEBBQAD
# ggIPADCCAgoCggIBALZ7pvLJ/s1K+NSbTGWz/TjGMPh8CQ6RucZCLv5anHzWJjF/
# NWJrFIhy24fcpKXlgRiky4WAawDfU3YP0BMxt9l3Dm5oCG5Z69AqEN1kgHg2epx+
# l+lZBcmJCcN0ASURML5uFIS80sZsDwO3BSkUxDjLJhBI+qiZP3aixAC/qEGLjsBN
# lLol9VZ7pfGEXiMlneJIC5/YKuizVzNFKZZEeoy/0B8Zm+nzKBgSWG52lCO1w+nC
# g6XpCtklTJXeIg283hw7TmmsZXR+SMbjbrEOvZ3fP2VxIgeR28Y90ZStd3F9VuA5
# RVynb/whITPAo9b75Zr4Ta6Mj3URm26QZYMn/FnbuTegcoRcFEZ9FOqM5T6MTdtr
# /n74lIT/ug0eeOzmZ6QTFg33otX+bFRsIolvykE1jive4PuESaT8zzVeFWDAMDto
# zNgLctkGD1ZjkEyZtJrLl5ya0m5doH/ScpaZCZVl6pNUOCybMc/kxC6EAmSJY24L
# 0yYKD1Nkddsnb/ItVKi/2nXpQNMu1PT5prW83vV8d67WowuUs0HdY4H8AMLGvdL/
# WHEj3ZnqMqAQQP9u3Ai9t+5eQ02GDwy0ODjdzi0xlp70W+ow63/0++YDEX1M0iwg
# UHwbrJvfpklkZQvw3+kv3vUPItdwroczk9icflf55W1zOEKAcJVAIXpcMCU9AgMB
# AAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBQUyWOKMC7USvtulPPm
# 40B+9ezN4jAfBgNVHSMEGDAWgBTvb1NK6eQGfHrK4pBW9i/USezLTjAOBgNVHQ8B
# Af8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwgZUGCCsGAQUFBwEBBIGI
# MIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXQYIKwYB
# BQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0
# ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNydDBfBgNVHR8E
# WDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5jcmwwIAYDVR0g
# BBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQCN
# xTphHp1SCt+ZrAmAfn0oQLFr0mLywSLaDXQIENoyKqxrFbJblzCVP/pkXmwXOdrO
# pWygLzlT12os5ipDCy35RBCg2UMeApEtrfGhz45F4Wt4WGdNdIbRWt3YTYJmpR+b
# 7lr4d7Uwn+H600u4D7RnOGf8Wj4UNgAdZkfHhHv1mx9EVh71SJelcEN/oORSjXzd
# jfw1iZH9d8Nh/thn6hH23d+VsPAr6GAYyzSA02nXD1nYLI7Ijmiv+xLCiYC41DSF
# YL3GhTiy0PxpawPtGRyaBVGzq+UiTfM8pD7KVyF5aQyWP4KhVGUUTnmm/RlYJoW3
# TiXA/+t0YcT2oRVBm3JETjajHug2AL+v5jhtKVnd3D0rbHXEu27o+Q8p4sEWPMqK
# DB+qbceb6T/6WcwTwXmQ9lOCLLYcsQeSWmvKqzpAec9etE14jOQAzLKWdE3w/TCa
# KtLRaRT7LCkRYVnhA2D73FLje1O5b3HR5eHs0NzU/+xX7NbEdcofy0W3Wdwd1XOq
# tlpg/JgwtKfZM5dqO94lbUveOiJBI+xZEbGRsMNbXmMREUTgu+Oca7Y73MPWcslI
# x2VhkSKSXjDbD6rgg39H5Mh7QfieAIjWagkJNt68Yfim6cjEzVSiLSeZfdkr5dtF
# PTW6jATlWJdYeeDRGCyatf8R1hSjzSvdN8yWQPT9gzGCBl0wggZZAgEBMH0waTEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhE
# aWdpQ2VydCBUcnVzdGVkIEc0IENvZGUgU2lnbmluZyBSU0E0MDk2IFNIQTM4NCAy
# MDIxIENBMQIQDUe1rg75COLypjYysvnrFDANBglghkgBZQMEAgEFAKCBiDAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgkqhkiG9w0BCQUxDxcNMjYwOTI4MTQ1
# MjE1WjAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQx
# IgQgyuIzzdZgy2tQFyW3CpoS+STinFNRVaZLxzSqpa/OiywwDQYJKoZIhvcNAQEB
# BQAEggIAN3hkHfqWZMelko6shUYwP6w/pcRUTJ0h3G4M2epEMd7YY87Cy8BRLiEB
# htDlr+gSwY+paJII77asO/Hoy0McBPwLORi52Ip4AekZftRxF9Q5EE38MMRhswHM
# r93UTI2HsC1lErVVQ1RyBy61HxTn5AytYHM692iGOJ34dXxSy054yq2+8MrZ2m89
# Vb5CLwz8m78/p9pjJbYnnbWnPxIn4m1q0Cah8KNCHBF/7nd5wz793BYTuuCMMjiV
# RGnk5kwne3ccZNgoBZ2zBw5spNEJv/WvMzKQhUAd+LikyXhbWcQuq2ce1m+/n5sd
# j0cymniIF89f7Rag3sE5KvDzVuPb5waxRcK0jIPnyvPSMwvK9/m5VP7vFnYrm5T3
# zMWOA5MXTkeB2DFBuRjixBRKqRasY/3SyOwrJh/4Y3VaOLEE3m+X8lkXEhZxlMbL
# nO/USOJV8UoIX8uyh9Nm4lLfURAdi4DYJ0ryCDoWTyoSZXa6izn8Z7ETgVEnSDZu
# JkknxVTrgJuisGLoy9/GZ1emK2KVk9vZMu0b42ea5Y17iQaAYrGvhLBIN1VgaFt1
# L55GwIz4aeMDepB0tpLxES+TY9XZs8R3fARNly40TWoNHpfmjas4wqd3ZGyunNax
# 1emar8iZIHOmxOLz4g+020ktPiJb15Kvox1NAm2z9oItsbyZYL2hggMmMIIDIgYJ
# KoZIhvcNAQkGMYIDEzCCAw8CAQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMO
# RGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGlt
# ZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExAhAIT9wzT35FTtvDD4/5
# khg1MA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAc
# BgkqhkiG9w0BCQUxDxcNMjYwOTI4MTQ1MjE2WjAvBgkqhkiG9w0BCQQxIgQglLiF
# z4DndFf+PqFGxFhxfpXwSyCUFQs8vh9tfxIC93owDQYJKoZIhvcNAQEBBQAEggIA
# M9qfgbBYEAuEohsO8XxmYO6sBazqTQv+2M9qoYo9xXO+Fs0Y8VCG+3+9Qh+V1/pM
# KqXB+99bBH0lwnsqTjVbP9IihB75HazSvL46m2L/K2DB6NF4T0HsKH/vTbho5dDv
# Up4TeuSV43Ihr6aRNoU4DXBX+uLgxxc45mej9AzRnjAm/s4G2yTCIqWlNBSGA1QR
# rXIh+MiW+Y80vAYaiZl8nlNi4W/f+i3dijRdg+he+8DsOrhEAuz0GdjVTQ37Jnjk
# Nj0077ttw1kuyIznTMzhg1pOMls1qQIdMXvIyEnWEZNnma+K7FQbiGchXQV1zj8h
# aTbiKSaGXLeVk2V8dGdmbqgjRwcWgyZEvMYj9nhMqVSaaH0nyMo1zZfevuUHjxGh
# qG643XLG3y/YBcX91YlMPsbE1d83GvgtMjUufnVpIArjO+UrPWptm7gI7JDmtbxl
# Ygz8LDOQ6Ft/L2mRJgif+F2FPtluWppWyeADlYaCid7CM35up/KBiLHzLKU1c/je
# 6xbX7ZemWfaSGXXAoTKmVlEP8qenNAQNO0McGC/fVJHlCrKV2DsF7QoKY8pm5e0W
# 9LcoAWlN0zlAuMubjfSwUqO713LqYtYltKoE98QvO/2td2mqcwg0bbKjwzcFBsOt
# BzhnGwFdG7ZZEEOphvQ5lY9OR242QG3u9G4L9Ddx+z4=
# SIG # End signature block

<#
Adaptable Workflow 803 PowerShell Script for Akamai CPS

Copyright (c)2026 Venafi, Inc. All rights reserved. This integration module is licensed under the same terms and conditions as your CyberArk product, available here: https://www.cyberark.com/contract-terms/

-----BEGIN FIELD DEFINITIONS-----
Text1|Proxy URL|10
Text2|Akamai EnrollmentID Macro|10
Text3|Always Approve|10
Text4|Text Field #4|00
Text5|Text Field #5|00
Text6|Text Field #6|00
Text7|Text Field #7|00
Text8|Text Field #8|00
Text9|Text Field #9|00
Text10|Text Field #10|00
Text11|Text Field #11|00
Text12|Text Field #12|00
-----END FIELD DEFINITIONS-----
#>
#Requires -Version 5.1

$installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

$vComPath = Join-Path -Path $installPath -ChildPath 'Scripts\AdaptableApp\AkamaiApplicationDriver\Venafi.Akamai.Common.ps1'
if (Test-Path -Path $vComPath -PathType Leaf) {
    . $vComPath
}
else {
    throw 'Venafi.Akamai.Common not found at {0}' -f $vComPath
}
<######################################################################################################################
.NAME
    Process
.DESCRIPTION
    Processes a workflow in Trust Protection Platform. It is the author's responsbility to write custom logic and create/skip ticket creation.

    .PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        ServiceAddress : a string identifying the service endpoint (URL, host, port, etc) of the calling Adaptable Workflow object
        UserName : a string containing the username portion of the credential assigned to the Adaptable Workflow object
        UserPass : a string containing the password portion of the credential assigned to the Adaptable Workflow object
        AuxUser : a string containing username portion of the secondary credential assigned to the Adaptable Workflow object.
        AuxPass : a string containing password portion of the secondary crecential assigned to the Adaptable Worklfow object.
        AuxPfxData: a string containing pfx data of the secondary credential assigned to the Adaptable Workflow object.
.PARAMETER Fields
    A hashtable containing the values specfic to conditions and actions related to Adaptable Workflow object.
        Workflow Reason Code : The reason code assigned to the Adaptable Workflow object.
        ObjectDN  : string representing the DN of the object being processed.
        Workflow DN : string representing the DN of the Adaptable Workflow object in TPP.
        Workflow Stage : The stage assigned to the Adaptable Workflow object.
        Workflow Approver Type : The type of approval assigned to the Adaptable Workflow object (Specified approver/ Approver assigned to object/  	Custom approval logic)
        Workflow Approvers : List of identities allowed to approve the ticket.
        Current Stage : The current stage being processed by TPP.
        Workflow Rule : The rule computed at the Adaptable Workflow object.
.PARAMETER CustomFields
    A hashtable containing all of the custom fields defined over Adaptable Workflow object. These fields are configured via the script.

.NOTES
    Returns...
    return @{ Result= "$TicketIssued" }
    Result : See Section 1 for possible values.
######################################################################################################################>

function Process {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Workflow Detail Parameters")]
        [System.Collections.Hashtable]$Fields,
        [Parameter(Mandatory = $true, HelpMessage = "Custom Field Parameters, if defined")]
        [System.Collections.Hashtable]$CustomFields
    )

    Set-Variable -Name Rejected -Value Rejected -Option Constant
    Set-Variable -Name Approved -Value Approved -Option Constant
    Set-Variable -Name Pause -Value Pause -Option Constant
    Set-Variable -Name TicketRequested  -Value TicketRequested  -Option Constant

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo | Out-Null

    Initialize-Akamai -General $General -IsWorkflow

    $enrollmentId = $CustomFields.Text2
    Write-VenafiDebug -Message "Working on verifications with EnrollmentID $enrollmentId"
    $AkamaiDN = $Fields.ObjectDn -replace '\\', '\\'
    $AlwaysApprove = $CustomFields.Text3

    try {
        if ($Fields.WorkflowStage -ne 803) {
            Write-VenafiDebug -Message "Workflow is not being run at Stage 803!" -ThrowException
        }
        $changeId = Get-AkamaiPendingChangeId -EnrollmentId $enrollmentId

        if ( -not $changeId ) {
            if ( Test-AkamaiDualStack -EnrollmentID $enrollmentId ) {
                $details = 'Multistacked certificate with no pending change, the other certificate has already processed.  Nothing to do here.'
                Write-VenafiDebug -Message $details
                return @{
                    Result  = "Approved"
                    Details = $details
                }
            }

            Write-VenafiDebug -Message 'No active change found, cannot continue' -ThrowException
        }

        Write-VenafiDebug -Message "ChangeId $($changeId) found"

        $enrollment = Get-CPSEnrollment -EnrollmentId $enrollmentId
        $enrollment | Write-VenafiDebug -Intro 'Enrollment details'
        $cmStatus = if ( $enrollment.changeManagement ) {
            $enrollment.changeManagement
        }
        else {
            $false
        }

        if ( $cmStatus ) {
            $allowedInput = Wait-CPSStatusChange -EnrollmentID $enrollmentId -ChangeID $changeId
        }
        else {
            $details = "Change Management not set, no approval required"
            Write-VenafiDebug -Message $details
            return @{
                Result  = "Approved"
                Details = $details
            }
        }

        $allowedInput | Write-VenafiDebug -Intro 'Allowed input from CPS after waiting for change management status change'

        if ($allowedInput -eq "completed") {
            $details = "Change request $changeId was completed"
            Write-VenafiDebug -Message $details
            return @{
                Result  = "Approved"
                Details = $details
            }
        }
        elseif (($allowedInput.info -match 'change-management-info') -and ($allowedInput.requiredToProceed -eq $true)) {
            $details = "The Akamai App in the $($AkamaiDN) folder has no post verification warnings for Stage 803."
            Write-Information $details
            return @{
                Result  = "Approved"
                Details = $details
            }
        }
        elseif (($allowedInput.info -match 'post-verification-warnings') -and ($allowedInput.requiredToProceed -eq $true)) {

            $pvw = Get-CPSPostVerificationWarnings -EnrollmentID $enrollmentId -ChangeId $changeId | Select-Object -ExpandProperty warnings
            $pvw | Write-VenafiDebug -Intro 'post verification warnings'

            if ($pvw) {
                $result = @{
                    Result  = "TicketRequested"
                    Details = "The Akamai App in the $AkamaiDN folder requires approval. These Akamai warnings need review: $pvw"
                }
            }
            elseif ($AlwaysApprove -eq 'yes') {
                $result = @{
                    Result  = "TicketRequested"
                    Details = "The Akamai App in the $AkamaiDN folder requires approval."
                }
            }
            else {
                $result = @{
                    Result  = "Approved"
                    Details = "The Akamai App in the $($AkamaiDN) folder does not require approval."
                }
            }

            $result | Write-VenafiDebug -Intro 'workflow response'
            return $result
        }
        else {
            Write-VenafiDebug -Message 'Unable to process allowedInput' -ThrowException
        }
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}


# SIG # Begin signature block
# MIIh3AYJKoZIhvcNAQcCoIIhzTCCIckCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA+R7WYl0ZJmPsi
# M7E3KMW7CcpXzjl8I73XVGOvzysFwKCCGtUwggeXMIIFf6ADAgECAhANR7WuDvkI
# 4vKmNjKy+esUMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBD
# b2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjYwODE3MDAw
# MDAwWhcNMjcwODE2MjM1OTU5WjCBnjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCkNh
# bGlmb3JuaWExFDASBgNVBAcTC1NhbnRhIENsYXJhMSEwHwYDVQQKExhQYWxvIEFs
# dG8gTmV0d29ya3MsIEluYy4xHjAcBgNVBAsTFVByb2Zlc3Npb25hbCBTZXJ2aWNl
# czEhMB8GA1UEAxMYUGFsbyBBbHRvIE5ldHdvcmtzLCBJbmMuMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAvVonIqLn25b0GSYEN1vhecayc0B8Gj8LQR4s
# RrVIKgMZBGUfcrZbcYj6KuNP18dS024QWYjsGVRmPGJrQbzss8+vaJA9we1C4LbS
# VwPiXoNqvNluLcioXIPrDpIys/kcrMC/caP/pMunxajiXYO+B+1Gv3hBtCX1efQe
# chcf4/x0hx44Kip2LtgzRG2w4q1/rz0VpZL1LmNOh1dMj5MDft9o4FfFAA1GOOOe
# Od060PSY+E0DixRaL48GIbCu+oQxRlo2GfpHXeXM2F2EEr3KAqfxEEGwv7qM6GqH
# xP5DI45lEcVcLtiv5CNPa4iH+LAPag1GDihgbzK+meryExQHH4/aaPXwu00dqDRZ
# L2iz8JegSSFZ7V2XYkhkov7B5em46cF06fOyrK76WyNYmr3Fp2X2kE45gyUhKPDl
# GDkpTvDQ+Di8KNw9XVc22k3YVJJlhSZb2smsD3PA7dyHHTOoNsd0vSngyOx3ba22
# PXCLROylgQ5QJKxHyw5tvVxxqjuLRT9T2SRoovQFhqhnn5WZBERdgrjvGWrgnaL7
# C9IXlnWza1oW6wHK3zRdZqNoop8+sueBVlDK+JzShCyqxHBzCb4/cEQg2EgXbBx7
# fQdOHU3nC5/SWAun442kxq47RdMUy2w/1/v+LVpk8H9koXpJXfUvKGwrkvjOInUh
# mXBRtCkCAwEAAaOCAgMwggH/MB8GA1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl
# 9E5CMB0GA1UdDgQWBBQvDoyn5zdE/9KvaLGaM/RICo8CyjA+BgNVHSAENzA1MDMG
# BmeBDAEEATApMCcGCCsGAQUFBwIBFhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9D
# UFMwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8E
# ga0wgaowU6BRoE+GTWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBP
# hk1odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2Rl
# U2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcw
# gYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEF
# BQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIw
# ADANBgkqhkiG9w0BAQsFAAOCAgEAW6iVWK4gZ7tLhvVXvPSN36R5iRjryaGP8b1U
# xOYRqN41lXJlyqKNfcM+EJTOKyZye447zCAx6AFpSx+Skl6Yuwaj9wq7MukCis1S
# g6djYp8008m4LL7J9+2OybssvTgRFcES73XsZWEfulUUXr0+OjAc3RjzNlaRaReM
# H7fpYMrSDouMWLW/YYBfIEm44beVicGDrfaxSGXc+u1Y7lhWZmVTKJOGVQ/V9Nol
# xhtvrlWTjeh5+Bh59MZnKKpzDCIubtBPxv6h1UkS0Iev08CeEgLIKw1l536OuB9o
# tnBVnxhSOFp+PgEx0n655EqSQPpHA2NB39rCCkCLMFJiWP1Q6gq0zwVndfsI61rc
# Lo49OBVNAD+OCrDYOUF/1zHALI0rWeT/FWcrgUWfioN7Ne2Q4baKvTSTb9I6b6Js
# v+nPsM9WT7siJRlOdTVUw7wGe9NIsysPZXPDaXP7QRnyB0XBNYKlOzwf7Z+d8sDZ
# iUcdskEibFFaPG03ld35lcV2c5dCIan/mmQn1L6leY7l6SqgctEqk5SV8r15zDy0
# 4Kn6heB/srzL7uZQjftVfn5A++RiWwv6Gi/f9OdVLzgjG5wIRhCdOYp6+DMNELRU
# oczQparY/vZaqTckOmZATLKlCKa3IwapPP3NFdRxdpag6X/EOIiGoVPS8oc9aLqb
# Cry73SQwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEB
# DAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNV
# BAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQg
# SUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJ
# BgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5k
# aWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPs
# wqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLk
# X9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4TmdDtt
# ceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hI
# qGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2
# scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm
# 2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaH
# iZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3r
# M9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJ
# B+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzTQRES
# W+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kxfgom
# mfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0G
# A1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLL
# gjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQG
# CCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKG
# N2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJv
# b3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQu
# Y29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYGBFUd
# IAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72arKGH
# LOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFIDyE7Q
# Kt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajw
# vy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQ
# Pfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFq
# I2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwgga0MIIEnKAD
# AgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yNTA1
# MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBU
# aW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwggIiMA0GCSqGSIb3
# DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphBcr48RsAcrHXbo0ZodLRRF51NrY0N
# lLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6pvF4uGjwjqNjfEvUi6wuim5bap+0l
# gloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHeHYNnQxqXmRinvuNgxVBdJkf77S2u
# PoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEdgkFiDNYiOTx4OtiFcMSkqTtF2hfQ
# z3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjUjsZvkgFkriK9tUKJm/s80FiocSk1
# VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bRVFLeGkuAhHiGPMvSGmhgaTzVyhYn
# 4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeSLsJygoLPp66bkDX1ZlAeSpQl92QO
# MeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIVNSaz7BX8VtYGqLt9MmeOreGPRdtB
# x3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL6s36czwzsucuoKs7Yk/ehb//Wx+5
# kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2ZdSoQbU2rMkpLiQ6bGRinZbI4OLu9B
# MIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFUeEY0qVjPKOWug/G6X5uAiynM7Bu2
# ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQU
# 729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6
# mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcGCCsG
# AQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29t
# MEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNl
# cnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3Js
# My5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNVHSAE
# GTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBABfO
# +xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/T8ObXAZz8OjuhUxjaaFdleMM0lBr
# yPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQE7jU/kXjjytJgnn0hvrV6hqWGd3r
# LAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9rEVKChHyfpzee5kH0F8HABBgr0Udq
# irZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y1IsA0QF8dTXqvcnTmpfeQh35k5zO
# CPmSNq1UH410ANVko43+Cdmu4y81hjajV/gxdEkMx1NKU4uHQcKfZxAvBAKqMVuq
# te69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3ty9qIijanrUR3anzEwlvzZiiyfTPj
# LbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcytL5TTLL4ZaoBdqbhOhZ3ZRDUphPv
# SRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEBYTptMSbhdhGQDpOXgpIUsWTjd6xp
# R6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud/v4+7RWsWCiKi9EOLLHfMR2ZyJ/+
# xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiSuEtQvLsNz3Qbp7wGWqbIiOWCnb5W
# qxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZPubdcMIIG7TCCBNWgAwIBAgIQCE/c
# M09+RU7bww+P+ZIYNTANBgkqhkiG9w0BAQsFADBpMQswCQYDVQQGEwJVUzEXMBUG
# A1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQg
# RzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExMB4XDTI2MDgw
# NTAwMDAwMFoXDTM3MTEwNDIzNTk1OVowYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoT
# DkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2VydCBTSEEyNTYgUlNBNDA5
# NiBUaW1lc3RhbXAgUmVzcG9uZGVyIDIwMjYgMTCCAiIwDQYJKoZIhvcNAQEBBQAD
# ggIPADCCAgoCggIBALZ7pvLJ/s1K+NSbTGWz/TjGMPh8CQ6RucZCLv5anHzWJjF/
# NWJrFIhy24fcpKXlgRiky4WAawDfU3YP0BMxt9l3Dm5oCG5Z69AqEN1kgHg2epx+
# l+lZBcmJCcN0ASURML5uFIS80sZsDwO3BSkUxDjLJhBI+qiZP3aixAC/qEGLjsBN
# lLol9VZ7pfGEXiMlneJIC5/YKuizVzNFKZZEeoy/0B8Zm+nzKBgSWG52lCO1w+nC
# g6XpCtklTJXeIg283hw7TmmsZXR+SMbjbrEOvZ3fP2VxIgeR28Y90ZStd3F9VuA5
# RVynb/whITPAo9b75Zr4Ta6Mj3URm26QZYMn/FnbuTegcoRcFEZ9FOqM5T6MTdtr
# /n74lIT/ug0eeOzmZ6QTFg33otX+bFRsIolvykE1jive4PuESaT8zzVeFWDAMDto
# zNgLctkGD1ZjkEyZtJrLl5ya0m5doH/ScpaZCZVl6pNUOCybMc/kxC6EAmSJY24L
# 0yYKD1Nkddsnb/ItVKi/2nXpQNMu1PT5prW83vV8d67WowuUs0HdY4H8AMLGvdL/
# WHEj3ZnqMqAQQP9u3Ai9t+5eQ02GDwy0ODjdzi0xlp70W+ow63/0++YDEX1M0iwg
# UHwbrJvfpklkZQvw3+kv3vUPItdwroczk9icflf55W1zOEKAcJVAIXpcMCU9AgMB
# AAGjggGVMIIBkTAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBQUyWOKMC7USvtulPPm
# 40B+9ezN4jAfBgNVHSMEGDAWgBTvb1NK6eQGfHrK4pBW9i/USezLTjAOBgNVHQ8B
# Af8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwgZUGCCsGAQUFBwEBBIGI
# MIGFMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXQYIKwYB
# BQUHMAKGUWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0
# ZWRHNFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNydDBfBgNVHR8E
# WDBWMFSgUqBQhk5odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5jcmwwIAYDVR0g
# BBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQCN
# xTphHp1SCt+ZrAmAfn0oQLFr0mLywSLaDXQIENoyKqxrFbJblzCVP/pkXmwXOdrO
# pWygLzlT12os5ipDCy35RBCg2UMeApEtrfGhz45F4Wt4WGdNdIbRWt3YTYJmpR+b
# 7lr4d7Uwn+H600u4D7RnOGf8Wj4UNgAdZkfHhHv1mx9EVh71SJelcEN/oORSjXzd
# jfw1iZH9d8Nh/thn6hH23d+VsPAr6GAYyzSA02nXD1nYLI7Ijmiv+xLCiYC41DSF
# YL3GhTiy0PxpawPtGRyaBVGzq+UiTfM8pD7KVyF5aQyWP4KhVGUUTnmm/RlYJoW3
# TiXA/+t0YcT2oRVBm3JETjajHug2AL+v5jhtKVnd3D0rbHXEu27o+Q8p4sEWPMqK
# DB+qbceb6T/6WcwTwXmQ9lOCLLYcsQeSWmvKqzpAec9etE14jOQAzLKWdE3w/TCa
# KtLRaRT7LCkRYVnhA2D73FLje1O5b3HR5eHs0NzU/+xX7NbEdcofy0W3Wdwd1XOq
# tlpg/JgwtKfZM5dqO94lbUveOiJBI+xZEbGRsMNbXmMREUTgu+Oca7Y73MPWcslI
# x2VhkSKSXjDbD6rgg39H5Mh7QfieAIjWagkJNt68Yfim6cjEzVSiLSeZfdkr5dtF
# PTW6jATlWJdYeeDRGCyatf8R1hSjzSvdN8yWQPT9gzGCBl0wggZZAgEBMH0waTEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhE
# aWdpQ2VydCBUcnVzdGVkIEc0IENvZGUgU2lnbmluZyBSU0E0MDk2IFNIQTM4NCAy
# MDIxIENBMQIQDUe1rg75COLypjYysvnrFDANBglghkgBZQMEAgEFAKCBiDAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgkqhkiG9w0BCQUxDxcNMjYwOTI4MTQ1
# MjE2WjAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQx
# IgQgfZb06PlHG/jMfYJLGpsqhyfZzWkCYOTFMGlzpugyOUQwDQYJKoZIhvcNAQEB
# BQAEggIASAOLxbk8uMFv9xfaMAY85wJUIFk2qQhQz+OX+y4D+hBli/jUS9rmc+e9
# nVZy3w/nKaX0/4PksCRZ8spMfoTh8hL22JOLNh4uumASbXCeAlgvf7Dr8siyP/6C
# Us+vQ/LIzXky0z2jROufuci5To7UVRCH0Dxb3BFGbNb9ZaK1+ZZGiQbTxwR0jRHi
# TfT7yj5khjhA8OxJL+79zG6g49l5dO9jj7PQDkEp45tiOu0UjOaLcy/MKYeDOqeV
# /caoi0stZIWcuEqImlXAt37uHuEPN9AXjL9rFmD552AkdtSPWHR+7FoG6NfZyEOR
# vcZDqnFND8B82lXJkaOhZQFIXApLSQXAfVobmeJAY7FfOS8T6dxwHjfXDpPJSp1l
# JSD6l/qT3++Alb5OjN0hz36Dbd0+yjzPCt94mi2p1gW6K+D8SCaoKWFK0lNhbf8D
# nrXLxf3k9oPv8pgqL/BV+ZzqGDyKxq+2Aac+9G70SUIkcn+iWRzX8tMezLirc45f
# +qEhYTvX8qgbjoKZ2airV4yXnBQqp4citdhgwfwREcvhJUY0c6YQFb/IzTImBRYi
# eZttYCMFxI/xlZPSvnOa/+WXLaJP9irGb6PAL5XugE9tPMoNLal+RB/U3hDv/9iG
# /MFW+zIksuVaEP5kLo28zu8ub0E7Q2m3WMoIIaCZUdmQM/aSdGqhggMmMIIDIgYJ
# KoZIhvcNAQkGMYIDEzCCAw8CAQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMO
# RGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGlt
# ZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExAhAIT9wzT35FTtvDD4/5
# khg1MA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAc
# BgkqhkiG9w0BCQUxDxcNMjYwOTI4MTQ1MjE2WjAvBgkqhkiG9w0BCQQxIgQgh1pU
# tvYM13Y1bOun8bsS5OkczxxUToPapcp8aQVonn4wDQYJKoZIhvcNAQEBBQAEggIA
# LFR7If2LPPcI+KdV2tT6R6vwFWEerdulFbRiN/UOQqgoHOVrutQ8rAfLPmdGg4tk
# ecSf3EFUrY5TsjqCq65w2czTzmFk1t8XAbSs+q0vswwRu2VxZwUyOm31z4UFrvFP
# 4oPZim9RIZabTzlUCbAcp+KKjDVnAE49rQAuS//vqMPIv6fPneFbrl8xVxNpoQDK
# hins97rFiPa+G7tjpM2ZNQudNKg9ztPBKWcrK4qSXygGRpv+8kQZ71xyZrOrxnTT
# Ztgab944q51cL5QBlq6TIZ1aHcYuA22Be521lf+PsHCA63ODGqFd3SyHA0ityaCQ
# Y620QpLbDXz4SSVHD0REsi2XK2D0K2MshKYRbjo8u6eoNq6r8uwBSckrCWcCQsS4
# 2cUZe7gttkyjCk7qjVyxc3XzPlaL69rIJXvIqM8WrwwZU48geQqURXAScVw9VOxC
# i5xpUqKCSgqvsV5cOu0XhR/BqgpAF1qDPjdS2REQ/bqsTFo2j3aFRix44VYs3gi/
# VJQamHcbMiQXzu/gcnxYNfrID0KnMg2tTStqGCXJ+KWOwED0oZNWa3gZAc166/UM
# MYB5w0KAwTs+vmSa8CkpMDMFPx1XsDB1SRx9KemZHFFl5UD/en+KA7hv3sA3NN0E
# yRRycUOxXcnx8ezq/hViPTUhjKNJw+1JV94GBbyXn9M=
# SIG # End signature block

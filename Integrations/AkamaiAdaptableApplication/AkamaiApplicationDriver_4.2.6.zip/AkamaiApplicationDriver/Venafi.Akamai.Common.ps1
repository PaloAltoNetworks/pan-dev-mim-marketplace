$script:scriptVersion = '4.2.6'

$script:retryCount = 1
$script:retryWaitSec = 10
$script:retryMax = 200

# Force TLS 1.2 if currently set lower
if ([Net.ServicePointManager]::SecurityProtocol.value__ -lt 3072) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}

function Initialize-Akamai {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [hashtable] $General,
        [Parameter()] [switch] $IsWorkflow
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    if ( $IsWorkflow ) {
        $authJSONString = $General.UserPass
    }
    else {
        $authJSONString = $General.VarPass
    }

    $proxyUri = $General.VarText1
    if ( $General.VarText1 -and $General.AuxUser ) {
        $proxyCredential = New-Object System.Management.Automation.PSCredential($General.AuxUser, ($General.AuxPass | ConvertTo-SecureString -AsPlainText -Force))
    }

    $installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

    Write-VenafiDebug "Importing Akamai.Common"

    $AkaComFile = Join-Path -Path $installPath -ChildPath 'Scripts\AdaptableApp\AkamaiApplicationDriver\Akamai.Common\Akamai.Common.psd1'
    if (Test-Path -Path $AkaComFile -PathType Leaf) {
        try {
            Remove-Module -Name 'Akamai.Common' -Force -Confirm:$false -ErrorAction SilentlyContinue
            Import-Module $AkaComFile -Force -ErrorAction Stop
        }
        catch {
            $_ | Write-VenafiDebug -ThrowException
        }
    }
    else {
        'Akamai.Common module not found at {0}' -f $AkaComFile | Write-VenafiDebug -ThrowException
    }

    Write-VenafiDebug "Importing Akamai.CPS"

    $AkaCpsFile = Join-Path -Path $installPath -ChildPath 'Scripts\AdaptableApp\AkamaiApplicationDriver\Akamai.CPS\Akamai.CPS.psd1'
    if (Test-Path -Path $AkaCpsFile -PathType Leaf) {
        try {
            Remove-Module -Name 'Akamai.CPS' -Force -Confirm:$false -ErrorAction SilentlyContinue
            Import-Module $AkaCpsFile -Force -ErrorAction Stop
        }
        catch {
            $_ | Write-VenafiDebug -ThrowException
        }
    }
    else {
        'Akamai.CPS module not found at {0}' -f $AkaCpsFile | Write-VenafiDebug -ThrowException
    }

    if ( -not [string]::IsNullOrWhiteSpace($ProxyUri) ) {
        Function Test-Proxy {
            $wc = New-Object System.Net.WebClient
            $wc.Proxy.IsBypassed("http://www.microsoft.com")
        }
        if (-not (Test-Proxy)) {
            #Check registry for proxy setting if any & use that one by default
            $getproxy = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' | Select-Object ProxyServer, ProxyEnable
            if ($getproxy.ProxyEnable -eq 1) {
                $ProxyUri = $getproxy.ProxyServer
            }
            if ( $proxyCredential ) {
                $PSDefaultParameterValues.Add('Invoke-RestMethod:ProxyCredential', $proxyCredential)
                'Using proxy credential {0}' -f $proxyCredential.UserName | Write-VenafiDebug
            }
            if (( $ProxyUri -notlike 'https://*') -or ( $ProxyUri -notlike 'http://*')) {
                $pserver = $ProxyUri.split(':')[0]
                $pport = $ProxyUri.split(':')[1]
                if ((Test-NetConnection -ComputerName $pserver -Port $pport).TcpTestSucceeded) {
                    $ProxyUri = 'http://{0}' -f $ProxyUri
                }
            }

            # The https_proxy environment variable is used by the underlying Akamai powershell module
            # PSDefaultParameterValues is used by all other calls. 
            $PSDefaultParameterValues.Add('Invoke-RestMethod:Proxy', $ProxyUri)
            $ENV:https_proxy = $ProxyUri
            ('Using proxy {0}' -f $PSDefaultParameterValues.'Invoke-RestMethod:Proxy') | Write-VenafiDebug
        }
    }

    # Validate JSON
    try {
        $authObject = $authJSONString | ConvertFrom-Json | Select-Object -ExpandProperty default
    }
    catch {
        'Invalid JSON format in authentication string' | Write-VenafiDebug -ThrowException
    }

    Import-EdgegridCredentials -HostName $authObject.host -ClientToken $authObject.client_token -AccessToken $authObject.access_token -ClientSecret $authObject.client_secret

    # set these akamai options once at the start as they are global
    Set-AkamaiOptions -EnableRateLimitRetries $true -InitialErrorWait $script:retryWaitSec -EnableErrorRetries $true | Out-Null

}

function Get-AkamaiChangeInfo {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [string] $EnrollmentId,
        [Parameter(Mandatory)] [string] $ChangeId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        Write-Information "Getting change information from the server for enrollment $($EnrollmentId) and change $($ChangeId)"
        $cStatus = Invoke-WithRetry -ScriptBlock { Get-CPSChangeStatus -EnrollmentID $EnrollmentId -ChangeID $ChangeId }
        $cStatus | Write-VenafiDebug -Intro 'change status response'
        return $cStatus
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException
    }
}

function Wait-CPSStatusChange {


    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] [string] $enrollmentId,
        [Parameter(Mandatory)] [string] $ChangeId,
        [Parameter()] [switch] $Completed
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    #Get the changes, check state & status.
    do {
        Write-Information "Waiting for Akamai Enrollment 'awaiting-input'"
        $cStatus = Get-AkamaiChangeInfo -EnrollmentId $EnrollmentId -ChangeId $ChangeId

        $allowedInput = @()

        if (-not $cStatus) {
            Write-VenafiDebug "Change not found for enrollment id $EnrollmentId" -ThrowException
        }

        Write-VenafiDebug -Level 'Debug' -Message "Akamai Enrollment: Current status: $($cStatus.statusInfo.status), current state: $($cStatus.statusInfo.state)"

        if ($cStatus.statusInfo.state -eq "error") {
            #We have encountered an error and thus the states will not move forward until the error is removed.
            $cStatus.statusInfo | Write-VenafiDebug -Level 'Debug' -Intro 'Error state detected' -ThrowException
        }
        elseif (($cStatus.statusInfo.state -eq "suspended") -or ($cStatus.statusInfo.state -eq "cancelled")) {
            $cStatus.statusInfo | Write-VenafiDebug -Level 'Debug' -Intro 'Change request processing didn''t complete' -ThrowException
        }
        elseif ($cStatus.statusInfo.state -eq "completed") {
            $cStatus.statusInfo | Write-VenafiDebug -Level 'Debug' -Intro 'Change request processing is complete'
            $allowedInput = $cStatus.statusInfo.state
        }
        elseif ($cStatus.statusInfo.state -eq "awaiting-input") {
            Write-VenafiDebug -Level 'Debug' -Message "Akamai awaiting-input found, processing allowedInput information"
            if ( $cStatus.allowedInput.count -eq 0 ) {
                Write-VenafiDebug -Level 'Debug' -Message "Akamai Enrollment allowedInput is empty. Trying again. Try $script:retryCount of $script:retryMax"
                Write-VenafiDebug -Level 'Debug' -Message "Sleeping for $script:retryWaitSec seconds"
                Start-Sleep -Seconds $script:retryWaitSec
                $script:retryCount++
                $allowedInput = $null
            }
            else {

                foreach ($item in $cStatus.allowedInput) {
                    if ($item.requiredToProceed -eq $true) {
                        $item | Write-VenafiDebug -Intro 'Akamai allowedInput' -Level Debug
                        $allowedInput = $item
                    }
                }
            }

        }
        elseif ($script:retryCount -lt $script:retryMax) {
            Write-VenafiDebug -Level 'Debug' -Message "Akamai Enrollment awaiting-input not found. Trying again. Try $script:retryCount of $script:retryMax"
            Write-VenafiDebug -Level 'Debug' -Message "Sleeping for $script:retryWaitSec seconds"
            Start-Sleep -Seconds $script:retryWaitSec
            $script:retryCount++
        }
        else {
            throw [System.TimeoutException] "Timout waiting for Akamai Enrollment to reach 'awaiting-input' state"
        }
        if (($Completed) -and ($allowedInput -ne "completed")) {
            Write-VenafiDebug -Level 'Debug' -Message "Production deployment is not complete. Trying again. Try $script:retryCount of $script:retryMax"
            Write-VenafiDebug -Level 'Debug' -Message "Sleeping for $script:retryWaitSec seconds"
            Start-Sleep -Seconds $script:retryWaitSec
            $script:retryCount++
            $allowedInput = $null
        }
    } while ([String]::IsNullOrEmpty($allowedInput))
    return $allowedInput
}

function Test-AkamaiDualStack {

    param (
        [Parameter(Mandatory)]
        [string] $EnrollmentId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        $prodDeployment = Get-CPSProductionDeployment -EnrollmentID $EnrollmentId
        return ($prodDeployment.multiStackedCertificates -and @($prodDeployment.multiStackedCertificates).count -ne 0)
    }
    catch {
        if ( $_.Exception.Response.StatusCode.value__ -eq 404 ) {
            Write-VenafiDebug -Level 'Debug' -Message "No production deployment found for enrollment ID $EnrollmentId. First time processing this enrollment, assuming not multistack."
            return $false
        }
        else {
            $_ | Write-VenafiDebug -ThrowException
        }
    }
}

function Get-AkamaiEnrollment {

    param (
        [Parameter(Mandatory)] [string] $EnrollmentId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    try {
        Invoke-WithRetry -ScriptBlock { Get-CPSEnrollment -EnrollmentId $EnrollmentId }
    }
    catch {
        $_ | Write-VenafiDebug
        Write-VenafiDebug -Message "Enrollment id $EnrollmentId specified on the Application object doesn't exist or could not be retrieved" -ThrowException
    }
}

function Get-AkamaiPendingChangeId {

    param (
        [Parameter(Mandatory)] [string] $EnrollmentId
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $enrollment = Get-AkamaiEnrollment -EnrollmentId $EnrollmentId

    try {

        switch ($enrollment.pendingChanges.count) {
            0 {
                Write-VenafiDebug -Level 'Debug' -Message 'No pending changes found'
                return $null
            }
            Default {
                if ( $_ -gt 1 ) {
                    Write-VenafiDebug -Level Warning -Message "Enrollment $EnrollmentId has $($_) changes. Expected only 1. Defaulting to the first change."
                }
                $url = $Enrollment.pendingChanges[0].location
                $changeID = $url.split('/')[-1]
                Write-VenafiDebug -Level 'Debug' -Message "ChangeId $changeID is set"
                return $changeID
            }
        }
    }
    catch {
        # if we failed, the enrollment id most likely doesen't exist
        Write-VenafiDebug -Level 'Debug' -Message "No enrollment found in pendingChanges for $($EnrollmentId)"
        return $null
    }
}

function Initialize-VenafiPS {

    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,

        [Parameter()]
        [switch] $IsWorkflow,

        [Parameter()]
        [switch] $RequireApprove
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation | Out-Null

    $installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

    Write-VenafiDebug "Importing VenafiPS"

    $venafipsFile = Join-Path -Path $installPath -ChildPath 'Scripts\AdaptableApp\AkamaiApplicationDriver\VenafiPS\VenafiPS.psd1'
    if (Test-Path -Path $venafipsFile -PathType Leaf) {
        try {
            Remove-Module -Name 'VenafiPS' -Force -Confirm:$false -ErrorAction SilentlyContinue
            Import-Module $venafipsFile -Force -ErrorAction Stop
        }
        catch {
            $_ | Write-VenafiDebug -ThrowException
        }
    }
    else {
        'VenafiPS module not found at {0}' -f $venafipsFile | Write-VenafiDebug -ThrowException
    }

    if ( $IsWorkflow ) {
        New-VenafiSession -AccessToken $General.OAuthAccessToken
        Write-VenafiDebug -Level 'Debug' -Message "OAuth token provided for workflow session."
    }
    else {
        $vedadminUrl = $General.VarText2 -replace '/vedsdk', ''

        $clientId = if ( $General.VarText4 ) { $General.VarText4 } else { 'AkamaiAutomation' }

        $vCredential = New-Object System.Management.Automation.PSCredential($General.UserName, ($General.UserPass | ConvertTo-SecureString -AsPlainText -Force))
        $certificateScope = if ( $RequireApprove ) { 'manage,approve' } else { 'manage' }
        New-VenafiSession -Server $vedadminUrl -ClientId $clientId -Scope @{'configuration' = 'manage'; 'certificate' = $certificateScope } -Credential $vCredential | Out-Null
        Write-VenafiDebug -Level 'Debug' -Message "Obtained CMSH token."
    }

}

function Invoke-WithRetry {

    <#
    .SYNOPSIS
        Invoke a command with retry logic
    .DESCRIPTION
        Execute a scriptblock or cmdlet with configurable retry count, delay, and error handling.
        Supports exponential backoff and custom retry conditions.
    .PARAMETER ScriptBlock
        The scriptblock to execute. Use this for arbitrary code.
    .PARAMETER CmdletName
        The name of a cmdlet/function to invoke. Use with Parameters.
    .PARAMETER Parameters
        A hashtable of parameters to splat to the cmdlet specified by CmdletName.
    .PARAMETER MaxRetries
        Maximum number of retry attempts. Defaults to 3.
    .PARAMETER RetryDelaySec
        Seconds to wait between retries. Defaults to 10.
    .PARAMETER ExponentialBackoff
        If set, the delay doubles on each retry (capped at 300 seconds).
    .PARAMETER RetryCondition
        Optional scriptblock that receives the result. Return $true to retry, $false to accept the result.
        If not specified, retries only occur on exceptions.
    .PARAMETER RetryableExceptions
        Array of exception type names that should trigger a retry. If not specified, all exceptions trigger a retry.
    .PARAMETER NonRetryableStatusCodes
        Array of HTTP status codes that should NOT be retried. If the exception contains a matching status code,
        the exception is immediately re-thrown without retrying. Defaults to 400, 401, 403, 404.
    .EXAMPLE
        Invoke-WithRetry -ScriptBlock { Get-CPSChangeStatus -EnrollmentID $id -ChangeID $cid }
        Retry a simple command with default settings.
    .EXAMPLE
        Invoke-WithRetry -CmdletName 'Get-CPSChangeStatus' -Parameters @{ EnrollmentID = $id; ChangeID = $cid } -MaxRetries 10
        Retry a cmdlet with splatted parameters, up to 10 times.
    .EXAMPLE
        Invoke-WithRetry -ScriptBlock { Get-CPSEnrollment -EnrollmentId $id } -RetryCondition { param($result) $null -eq $result.pendingChanges }
        Retry until the result has pending changes.
    .EXAMPLE
        Invoke-WithRetry -ScriptBlock { Get-CPSProductionDeployment -EnrollmentID $id } -NonRetryableStatusCodes @(404, 409)
        Fail immediately on 404 or 409 without retrying.
    #>

    [CmdletBinding(DefaultParameterSetName = 'ScriptBlock')]
    param (
        [Parameter(Mandatory, ParameterSetName = 'ScriptBlock')]
        [scriptblock] $ScriptBlock,

        [Parameter(Mandatory, ParameterSetName = 'Cmdlet')]
        [string] $CmdletName,

        [Parameter(ParameterSetName = 'Cmdlet')]
        [hashtable] $Parameters = @{},

        [Parameter()]
        [int] $MaxRetries = 3,

        [Parameter()]
        [int] $RetryDelaySec = 10,

        [Parameter()]
        [bool] $ExponentialBackoff = $true,

        [Parameter()]
        [scriptblock] $RetryCondition,

        [Parameter()]
        [string[]] $RetryableExceptions,

        [Parameter()]
        [int[]] $NonRetryableStatusCodes = @(400, 401, 403, 404)
    )

    $attempt = 0
    $currentDelay = $RetryDelaySec

    while ($true) {
        $attempt++
        try {
            if ($PSCmdlet.ParameterSetName -eq 'Cmdlet') {
                $result = & $CmdletName @Parameters
            }
            else {
                $result = & $ScriptBlock
            }

            # If a retry condition is specified, check if we should retry
            if ($RetryCondition) {
                $shouldRetry = & $RetryCondition $result
                if ($shouldRetry -and $attempt -le $MaxRetries) {
                    Write-VenafiDebug -Level 'Debug' -Message "Retry condition met. Attempt $attempt of $MaxRetries. Waiting $currentDelay seconds."
                    Start-Sleep -Seconds $currentDelay
                    if ($ExponentialBackoff) {
                        $currentDelay = [Math]::Min($currentDelay * 2, 300)
                    }
                    continue
                }
            }

            return $result
        }
        catch {
            # Check for non-retryable HTTP status codes
            if ($NonRetryableStatusCodes -and $_.Exception) {
                $statusCode = $_.Exception.StatusCode.value__
                if ( $statusCode -and $statusCode -in $NonRetryableStatusCodes ) {
                    Write-VenafiDebug -Level 'Debug' -Message "Non-retryable HTTP status code: $statusCode"
                    throw
                }
            }

            # Check if this exception type is retryable
            if ($RetryableExceptions -and $_.Exception) {
                $exType = $_.Exception.GetType().FullName
                if ($exType -notin $RetryableExceptions) {
                    Write-VenafiDebug -Level 'Debug' -Message "Non-retryable exception type: $exType"
                    throw
                }
            }

            if ($attempt -gt $MaxRetries) {
                Write-VenafiDebug -Level 'Error' -Message "Max retries ($MaxRetries) exceeded. Last error: $($_.Exception.Message)"
                throw
            }

            Write-VenafiDebug -Level 'Debug' -Message "Attempt $attempt of $MaxRetries failed: $($_.Exception.Message). Waiting $currentDelay seconds."
            Start-Sleep -Seconds $currentDelay
            if ($ExponentialBackoff) {
                $currentDelay = [Math]::Min($currentDelay * 2, 300)
            }
        }
    }
}

Function Write-FunctionDetail {

    <#
    .SYNOPSIS
        Log function details
    .DESCRIPTION
        Log function details including the function name and any bound parameters
    .PARAMETER InvocationInfo
        Invocation detail from a function, typically sent via $PSCmdlet.MyInvocation
    .PARAMETER NoBoundParams
        By default, function parameters and values will be written.  Don't do this.
    .PARAMETER ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
    .NOTES
        Must be an advanced function otherwise $PSCmdlet.MyInvocation will not be available.
        Set $script:scriptVersion to include the script version in the log.
        Set $script:scriptName to validate signing.  Value should be similar to 'AdaptableCA\MyDriver', after Scripts dir and no .ps1.
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation
        Put this at the start of every function
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -NoBoundParams
        Do not output the bound parameters
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
        Helpful for the first log entry in a script to help with troubleshooting.
    #>

    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Management.Automation.InvocationInfo] $InvocationInfo,

        [Parameter()]
        [switch] $NoBoundParams,

        [Parameter()]
        [Alias('ValidateScript')]
        [switch] $ExtraInfo
    )

    $cs = Get-PSCallStack
    # get list of function names from stack, remove this function and the one which called it
    $functionBreadcrumb = ($cs.FunctionName | Select-Object -Skip 2) -join ' <- '

    $header = 'Function: {0}' -f $InvocationInfo.InvocationName
    if ( $functionBreadcrumb ) { $header += " (<- $functionBreadcrumb)" }
    if ($script:scriptVersion) { $header += ', script version: {0}' -f $script:scriptVersion }
    $header | Write-VenafiDebug

    if ( $ExtraInfo ) {

        $extraMessage = ''

        # registry only available on CMSH
        # if reusing this script with CMSaaS, this section will be skipped
        if ( $PSVersionTable.PSEdition -ne 'Core' ) {
            $installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

            if ( $script:scriptName ) {
                try {
                    $sig = Get-AuthenticodeSignature -FilePath ('{0}Scripts\{1}.ps1' -f $installPath, $script:scriptName)
                    $sigStatus = if ( $sig.Status -eq 'Valid' ) { 'Valid' } else { 'Not Valid' }
                }
                catch {
                    $sigStatus = $_.ToString()
                }
            }
            else {
                $sigStatus = 'script name not set'
            }

            $extraMessage += "signature: $sigStatus"

            # add CMSH version if available
            try {
                $f = Join-Path -Path $installPath -ChildPath 'Platform\Venafi.InstallKit.dll'
                $extraMessage += ', CMSH version: {0}' -f (Get-Item $f).VersionInfo.FileVersion
            }
            catch {
                # just for logging, don't fail
            }
        }

        # add powershell version
        $extraMessage += ', PowerShell version: {0}' -f $PSVersionTable.PSVersion.ToString()

        $extraMessage | Write-VenafiDebug
    }


    if ( $null -ne $InvocationInfo.BoundParameters -and -not $NoBoundParams ) {
        [hashtable]$InvocationInfo.BoundParameters | Write-VenafiDebug
    }
}

function Set-SecretsToHidden {

    <#
    .SYNOPSIS
        Blank out sensitive information
    .DESCRIPTION
        Blank out sensitive information in a message, typically in a hashtable.
        Meant for adaptable framework scripts.
        Will automatically clone hashtable to ensure original object isn't affected.
    #>


    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        $InputObject
    )

    process {

        $secrets = @('UserPass', 'AuxPass', 'PfxPass', 'Certificate', 'PfxData', 'Password', 'AuxPfxData', 'PrivKeyPem', 'Pkcs12', 'EncryptPass', 'ChainPkcs7', 'PrivKeyPemEncrypted', 'VarPass')

        # if needed, add additional secrets specific to this integration to be hidden
        $secrets += 'authJSONString'

        if ($InputObject -is [hashtable]) {
            $clone = @{}
            foreach ($key in $InputObject.keys) {
                if ( [string]::IsNullOrEmpty($InputObject[$key]) ) {
                    $clone[$key] = ''
                }
                else {
                    if ($key -in $secrets ) {
                        $clone[$key] = '***hidden***'
                    }
                    else {
                        $clone[$key] = Set-SecretsToHidden $InputObject[$key]
                    }
                }
            }
            return $clone
        }
        else {
            return $InputObject
        }
    }
}

function Write-VenafiDebug {

    <#
    .SYNOPSIS
    Write info to the adaptable debug log

    .DESCRIPTION
    Assuming the option has been selected, write info to the adaptable debug log.
    Hashtables are supported and secret info will not be logged, eg. $General.

    .PARAMETER Message
    The info to be logged

    .PARAMETER ThrowException
    After logging the message, throw an exception to terminate the script

    .EXAMPLE
    Write-VenafiDebug -Message 'connected to server'

    Write info to the log

    .EXAMPLE
    $General | Write-VenafiDebug

    Write input parameter values to the log

    .EXAMPLE
    Write-VenafiDebug -Message 'this was not good' -ThrowException

    Write to the log and throw an exception
    #>

    [CmdletBinding()]
    [Alias('Write-Debug')]
    [Alias('Write-Verbose')]
    [Alias('Write-Error')]
    [Alias('Write-Warning')]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [psobject] $Message,

        [Parameter()]
        [string] $Intro,

        [Parameter()]
        [ValidateSet('Info', 'Warning', 'Debug', 'Error')]
        [string] $Level = 'Info',

        [Parameter()]
        [switch] $ThrowException
    )

    begin {
        if ( -not $global:DEBUG_FILE ) {
            return
        }

        $allMessages = [System.Collections.Generic.List[string]]::new()
    }

    process {
        if ( -not $global:DEBUG_FILE ) {
            return
        }

        $newMessage = switch ($Message.GetType().FullName) {
            'System.Collections.Hashtable' {
                Set-SecretsToHidden $Message | ConvertTo-Json -Depth 5
            }

            'System.String' {
                $Message
            }

            'System.Management.Automation.ErrorRecord' {
                # powershell specific exception
                $err = $Message
                $ex = $err.Exception
                $inv = $err.InvocationInfo
                $logEntry = @{
                    Message          = $ex.Message
                    ErrorId          = $err.FullyQualifiedErrorId
                    Category         = $err.CategoryInfo.Category
                    TargetObject     = $err.TargetObject
                    ScriptName       = $inv.ScriptName
                    LineNumber       = $inv.ScriptLineNumber
                    Line             = $inv.Line
                    Position         = $inv.PositionMessage
                    StackTrace       = $ex.StackTrace
                    ScriptStackTrace = $err.ScriptStackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }
                $logEntry | ConvertTo-Json -Depth 3
            }

            'System.Exception' {
                #.net generic exception
                $ex = $Message
                $inv = $ex.InvocationInfo
                $logEntry = @{
                    Message       = $ex.Message
                    ExceptionType = $ex.GetType().FullName
                    ScriptName    = $inv.ScriptName
                    LineNumber    = $inv.ScriptLineNumber
                    Line          = $inv.Line
                    Position      = $inv.PositionMessage
                    StackTrace    = $ex.StackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }

                $logEntry | ConvertTo-Json -Depth 3
            }

            default {
                $Message | ConvertTo-Json -Depth 3
            }
        }

        $null = $allMessages.Add($newMessage)

    }

    end {
        if ( -not $global:DEBUG_FILE ) {
            return
        }

        if ( $Intro ) {
            $allMessages.Insert(0, $Intro)
        }

        try {
            # use a mutex to ensure multiple executions of this script don't cause 'file in use' errors
            $mutex = New-Object System.Threading.Mutex($false, [System.IO.Path]::GetFileNameWithoutExtension($global:DEBUG_FILE))
            if ( -not $mutex.WaitOne(0) ) {
                $mutex.WaitOne()
            }
            ('{0} : {1} : {2}' -f (Get-Date), $Level.ToUpper(), ($allMessages -join "`r`n")) | Out-File -FilePath $global:DEBUG_FILE -Encoding 'UTF8' -Append
        }
        catch {
            throw $_
        }
        finally {
            $null = $mutex.ReleaseMutex()
        }


        if ( $ThrowException ) {
            throw ($allMessages -join "`r`n")
        }
    }
}

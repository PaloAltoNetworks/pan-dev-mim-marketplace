<#
//-----------------------------------------------------------------------
// Fortinet FortiGate Adaptable Application
// supporting devices 6.4
//
// Copyright ©2025 Venafi, Inc. All rights reserved. This integration module is licensed under the same terms and conditions as your CyberArk product, available here: https://www.cyberark.com/contract-terms/
//
//-----------------------------------------------------------------------

<field name>|<label text>|<flags>

Bit 1 = Enabled
Bit 2 = Policyable
Bit 3 = Mandatory

-----BEGIN FIELD DEFINITIONS-----
Text1|Certificate Label|100
Text2|Virtual Domain|110
Text3|SSL Inspection Profile|110
Text4|Certificate Range|110
Text5|Text Field #5|000
Option1|Configure SSL Inspection|110
Option2|Not Used|000
Passwd|Not Used|000
-----END FIELD DEFINITIONS-----
#>

# DO NOT REMOVE
# Certificate validation must be disabled to allow
# provisioning and discovery processes to complete
# successfully.

$script:scriptVersion = "1.4.2"

if ( $PSVersionTable.PSEdition -eq 'Core' ) {
    # ps core, assume vaas
    $PSDefaultParameterValues['Invoke-WebRequest:SkipCertificateCheck'] = $true
    $PSDefaultParameterValues['Invoke-RestMethod:SkipCertificateCheck'] = $true
}
else {
    # need the following to interface with an untrusted certificate
    Add-Type -TypeDefinition @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@

    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# Unused Functions (These functions must be present for the Adaptable framework to work, but they are unused by this driver)
function Get-TPPUnused {
    [Alias("Prepare-Keystore")]
    [Alias("Generate-KeyPair")]
    [Alias("Generate-CSR")]
    [Alias("Update-Binding")]
    [Alias("Activate-Certificate")]
    [Alias("Install-Chain")]
    [Alias("Install-PrivateKey")]
    [Alias("Extract-PrivateKey")]
    [Alias("Remove-Certificate")]
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $false, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $false, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )
    Write-FunctionDetail $PSCmdlet.MyInvocation
    "Function '$($MyInvocation.InvocationName)' is not needed by this Adaptable Application" | Write-VenafiDebug
    return @{ Result = "NotUsed"; }
}

<#
.SYNOPSIS
Test-Connection is used by the TLS Protect Cloud Machine Connector framework to test authentication/access
to the remote machine.

.DESCRIPTION
Test-Connection receives the connection details from the TLPSC Machine Connector framework, which consists
of the HostAddress, Port, and UserPass values. These are the basic requirements for testing the
connection from a VSAT machine to the FortiGate device.

.PARAMETER General
HostAddress:   The fortigate URL/IP address.
Port:       The management interface port.
UserPass:   The access token that is generated from a username/password combination.

.EXAMPLE
Test-Connection -General <[System.Collections.Hashtable]>

.NOTES
The TLSPC Machine Connector manifest must match the parameters supplied above.
#>
function Test-Connection {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $server = $General.HostAddress
    $port = $General.TcpPort

    $Script:url = "https://$($server):$($port)/api/v2"

    $Script:header = @{
        "Content-Type" = "application/json"
        "Authorization" = "Bearer $($General.UserPass)"
    }

    if (!Get-FGSystemStatus) {
        return @{Result = "Failure" }
    }

    return @{Result = "Success" }
}

<######################################################################################################################
.NAME
    Install-Certificate
.DESCRIPTION
    Installs the certificate on the hosting platform.  May optionally be used to also install the private key and chain.
    Implementing logic for this function is REQUIRED.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        HostAddress : a string containing the hostname or IP address specified by the device object
        TcpPort : an integer value containing the TCP port specified by the application object
        UserName : a string containing the username portion of the credential assigned to the device or application object
        UserPass : a string containing the password portion of the credential assigned to the device or application object
        UserPrivKey : the non-encrypted PEM of the private key credential assigned to the device or application object
        AppObjectDN : a string containing the TPP distinguished name of the calling application object
        AssetName : a string containing a Venafi standard auto-generated name that can be used for provisioning
                    (<Common Name>-<ValidTo as YYMMDD>-<Last 4 of SerialNum>)
        VarText1 : a string value for the text custom field defined by the header at the top of this script
        VarText2 : a string value for the text custom field defined by the header at the top of this script
        VarText3 : a string value for the text custom field defined by the header at the top of this script
        VarText4 : a string value for the text custom field defined by the header at the top of this script
        VarText5 : a string value for the text custom field defined by the header at the top of this script
        VarBool1 : a boolean value for the yes/no custom field defined by the header at the top of this script (true|false)
        VarBool2 : a boolean value for the yes/no custom field defined by the header at the top of this script (true|false)
        VarPass : a string value for the password custom field defined by the header at the top of this script
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        CertPem : the X509 certificate to be provisioned in Base64 PEM format
        PrivKeyPem : the non-encrypted private key in RSA Base64 PEM format
        PrivKeyPemEncrypted : the password encrypted private key in RSA Base64 PEM format
        ChainPem : all chain certificates concatenated together one after the other
        ChainPkcs7 : byte array PKCS#7 collection that includes all chain certificates
        Pkcs12 : byte array PKCS#12 collection that includes certificate, private key, and chain
        EncryptPass : the string password that was used to encrypt the private key and PKCS#12 keystore
.NOTES
    Returns...
        Result : 'Success', 'AlreadyInstalled' or 'NotUsed' to indicate the non-error completion state
                 (may only be 'NotUsed' if Install-PrivateKey did not return 'NotUsed')
        AssetName : (optional) the base name used to reference the certificate as it was installed on the device;
                    if not supplied the auto-generated name is assumed
######################################################################################################################>
function Install-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $server = $General.HostAddress
    $port = $General.TcpPort
    $pem = $Specific.CertPem
    $p12 = $Specific.Pkcs12
    $encPass = $Specific.EncryptPass
    $vdom = $General.VarText2
    $sslProfile = $General.VarText3

    $assetName = if (($General.AssetName -eq $General.VarText1) -or ([String]::IsNullOrEmpty($General.VarText1))) {
        $General.AssetName
    }
    elseif ($General.VarText1) {
        $General.VarText1
    }
    else {
        "Unable to determine the AssetName value" | Write-VenafiDebug
    }

    $updateSslInspection = $General.VarBool1 -eq "true"


    # The certificate asset name cannot exceed 35 characters.
    $assetName = Set-CertificateLabel -InputObject $assetName
    if ($assetName.Length -gt 35) {
        $msg = "The certificate name contains more than 35 characters which is not supported by FortiGate"
        $msg | Write-VenafiDebug
        return @{Result = $msg }
    }

    $Script:url = "https://$($server):$($port)/api/v2"

    $Script:header = @{
        "Content-Type" = "application/json"
        "Authorization" = "Bearer $($General.UserPass)"
    }

    if ($updateSslInspection) {
        "Performing SSL Inspection Profile Update" | Write-VenafiDebug
        # Validate VDOM exists
        if ($vdom) {
            $vdomExists = Get-FGVdomDetail -Name $vdom
            if ($vdomExists.http_status -ne 200) {
                $msg = "Unable to locate the provided VDOM ""$($vdom)"". Check the spelling as VDOM names are case sensitive"
                $msg | Write-VenafiDebug
                return @{Result = $msg }
            }
        }

        # Validate SSL Inspection Profile Exists
        if (!$sslProfile) {
            $msg = "The ""SSL Inspection Profile"" configuration cannot be empty. Review the adaptable application object settings"
            $msg | Write-VenafiDebug
            return @{Result = $msg }
        }
        else {
            $pfExists = Get-FGSslProfile -VdomName $vdom -ProfileName $sslProfile
            if ($pfExists.http_status -ne 200) {
                $msg = "Unable to locate the provided SSL Inspection Profile: ""$($sslProfile)"""
                $msg | Write-VenafiDebug
                return @{Result = $msg }
            }
        }

        # Import new certificate into local store of VDOM
        $null = Add-FGLocalCertificate -CertName $assetName -CertData $p12 -EncPass $encPass -VdomName $vdom

        # Update SSL Inspection Profile with Certificate Label
        $updateSslInspectionCert = Set-SslProfileCert -CertName $assetName -VdomName $vdom -ProfileName $sslProfile
        if ($updateSslInspectionCert.http_status -ne 200) {
            $msg = "Unable to import the certificate ""$($assetName)"" into the local store of the VDOM ""$($vdom)"""
            $msg | Write-VenafiDebug
            return @{Result = $msg }
        }
    }
    else {
        "Performing Management Interface Update" | Write-VenafiDebug

        # Get management interface certificate name
        $adminCertName = Get-FGAdminSetting -Name "admin-server-cert"

        # Get management interface certificate PEM
        $mgmtCertPem = Get-FGCertificate -Name $adminCertName

        # Compare new cert to installed (AlreadyWorks?)
        "Accessing active certificate in TLSPDC" | Write-VenafiDebug
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$tppx509 = ConvertTo-X509Certificate2 -PEM $pem
        "Certificate currently in TLSPDC: $($tppx509 | ConvertTo-Json)" | Write-VenafiDebug
        "Accessing management interface certificate on FortiGate" | Write-VenafiDebug
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$fgmx509 = ConvertTo-X509Certificate2 -PEM $mgmtCertPem
        "Certificate currently in FortiGate: $($fgmx509 | ConvertTo-Json)" | Write-VenafiDebug
        if ($tppx509.SerialNumber -eq $fgmx509.SerialNumber) {
            $msg = "The certificate to be provisioned already exists and is configured on the FortiGate device"
            $msg | Write-VenafiDebug
            return @{Result = "AlreadyInstalled"; AssetName = $assetName }
        }

        # Install new cert (will drop connection)
        $null = Add-FGLocalCertificate -CertName $assetName -CertData $p12 -EncPass $encPass
        # Replacing certificate when admin-server-cert name
        # does not change will result in a "ConnectionClosed"
        # exception. So we ensure connection can be re-established.
        while ((Get-FGSystemStatus).status -ne "success") { "Waiting for session connection to be restored due to updating existing certificate configurations on the FortiGate device" | Write-VenafiDebug }


        # Update admin-server-cert value (still required if same name)
        $null = Set-FGAdminSetting -Name "admin-server-cert" -Value $assetName
        # Replacing certificate when admin-server-cert name
        # does not change will result in a "ConnectionClosed"
        # exception. So we ensure connection can be re-established.
        while ((Get-FGSystemStatus).status -ne "success") { "Waiting for session connection to be restored due to modifying the ""admin-server-cert"" configuration on the FortiGate device" | Write-VenafiDebug }

    }


    return @{Result = "Success"; AssetName = $assetName }
}

<######################################################################################################################
.NAME
    Extract-Certificate
.DESCRIPTION
    Extracts the active certificate from the hosting platform.  If the platform does not provide a method for exporting the
    raw certificate then it is sufficient to return only the Serial and Thumbprint.  This function is REQUIRED.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
        CertPem : the extracted X509 certificate referenced by AssetName in Base64 PEM format
        Serial : the serial number of the X509 certificate referenced by AssetName
        Thumbprint : the SHA1 thumbprint of the X509 certificate referenced by AssetName
######################################################################################################################>
function Extract-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $server = $General.HostAddress
    $port = $General.TcpPort
    $vdom = $General.VarText2

    $assetName = if (($General.AssetName -eq $General.VarText1) -or ([String]::IsNullOrEmpty($General.VarText1))) {
        "Using the AssetName ""$($General.AssetName)"" to retrieve the certificate from the FortiGate device" | Write-VenafiDebug
        $General.AssetName
    }
    elseif ($General.VarText1) {
        "Using the Certificate Label ""$($General.VarText1)"" to retrieve the certificate from the FortiGate device" | Write-VenafiDebug
        $General.VarText1
    }
    else {
        "Validation of the certificate cannot continue because the ""AssetName"" value is missing" | Write-VenafiDebug
    }

    $updateSslInspection = $General.VarBool1 -eq "true"

    $Script:url = "https://$($server):$($port)/api/v2"

    $Script:header = @{
        "Content-Type" = "application/json"
        "Authorization" = "Bearer $($General.UserPass)"
    }

    $certName = ""
    $certPem = ""
    if (!$updateSslInspection) {
        # Get management interface certificate name
        $certName = Get-FGAdminSetting -Name "admin-server-cert"
        "Using the value from the admin-server-cert key to retrieve the certificate from the FortiGate device" | Write-VenafiDebug

        # Retrieve certificate (download)
        $certPem = Get-FGCertificate -Name $certName
    }
    else {
        $certName = $assetName

        # Retrieve certificate (download)
        $certPem = Get-FGCertificate -Name $certName -VdomName $vdom
    }

    return @{ Result = "Success"; CertPem = $certPem.Trim() }
}

<######################################################################################################################
.NAME
    Discover-Certificates
.DESCRIPTION
    Discovers certificates and their instance metadata from a target device
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        HostAddress : a string containing the hostname or IP address specified by the device object
        TcpPort : an integer value containing the TCP port specified by the application object
        UserName : a string containing the username portion of the credential assigned to the device or application object
        UserPass : a string containing the password portion of the credential assigned to the device or application object
        UserPrivKey : the non-encrypted PEM of the private key credential assigned to the device or application object
.NOTES
    Returns...
        Result : 'Success' to indicate the non-error completion state
        Applications : an array of hashtables that include the following data for a certificate instance:
            Name - the name of the application object that represents this instance under the device object
            ApplicationClass - the schema class of the application object (defaults to 'Adaptable App')
            DriverName - the value of the Driver Name attribute (defaults to 'appadaptable')
            PEM - the raw X509 certificate in base64 encoded text format
            ValidationAddress - FQDN, hostname, or IP address where the server is presenting the certificate
            ValidationPort - TCP port on which the server is provisioning the certificate (integer between 1-65535, defaults to 443)
            Attributes - a hashtable that specifies zero or more Config attribute-value pairs to set on the application object
######################################################################################################################>
function Discover-Certificates {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = 'General Parameters')]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $server = $General.HostAddress
    $port = $General.TcpPort

    $Script:url = "https://$($server):$($port)/api/v2"

    $Script:header = @{
        "Content-Type" = "application/json"
        "Authorization" = "Bearer $($General.UserPass)"
    }

    # Get all VDOMs (if in VDOM mode)
    $vdomList = Get-FGAllVdom
    $fullCertList = Get-FGAllSslCertificates

    $apps = @()

    # Get all SSL Inspection Profiles from each VDOM
    if ($General.VarBool1 -eq "true") {
        $newCertHashWithPfs = @{}
        for ($i = 0; $i -lt $vdomList.Count; $i++) {
            $newCertList = $null
            foreach ($vdomCertList in $fullCertList) {
                if ($vdomCertList.vdom -ne $vdomList[$i]) {
                    Continue
                }
                else {
                    $newCertList = $vdomCertList.results
                }
            }

            $pfs = Get-FGAllSslProfile -VdomName $vdomList[$i]
            if (!$pfs) {
                Continue
            }

            foreach ($pf in $pfs) {

                $kv2 = $pf['server-cert']

                if ($newCertHashWithPfs.ContainsKey($kv2)) {
                    $newCertHashWithPfs[$kv2].Add($pf['profile'])
                }
                else {
                    $newCertHashWithPfs[$kv2] = [System.Collections.Generic.List[object]]@($pf['profile'])
                }
            }

            $keysCopy = $newCertHashWithPfs.Keys.Clone()

            foreach ($key in $keysCopy) {
                $newCertHashWithPfs[$key] = $newCertHashWithPfs[$key].ToArray()
            }

            # Read and download all certificates
            foreach ($certItem in $newCertHashWithPfs.Keys) {
                foreach ($fgCert in $newCertList) {
                    if ($fgCert.name -ne $certItem) {
                        Continue
                    }

                    if ($fgCert.range -eq "global") {
                        $certPem = Get-FGCertificate -Name $certItem
                        break
                    }
                    else {
                        $certPem = Get-FGCertificate -Name $certItem -VdomName $vdomList[$i]
                        break
                    }
                }

                # Create application objects
                foreach ($spf in $newCertHashWithPfs[$certItem]) {
                    $app = @{
                        Name       = $($vdomList[$i]) + "-" + $($spf -replace " ", "_")
                        PEM        = $certPem.Trim()
                        Attributes = @{
                            "Text Field 1" = $certItem
                            "Text Field 2" = $vdomList[$i]
                            "Text Field 3" = $spf
                            "Text Field 4" = $fgCert.range
                            "Option 1"     = $true
                        }
                    }
                    $apps += $app
                }
            }
        }
    }

    # Get management interface certificate name
    $globalSettings = Get-FGAdminSetting
    "Global Settings" | Write-VenafiDebug
    $globalSettings | Write-VenafiDebug
    $fghost = $globalSettings.results.hostname
    $adminCertName = $globalSettings.results."admin-server-cert"
    "The admin-server-cert value is ""$($adminCertName)""" | Write-VenafiDebug

    # Get management interface certificate (download)
    $mgmtCertPem = Get-FGCertificate -Name $adminCertName
    $app = @{
        Name       = "MGMT-$fghost"
        PEM        = $mgmtCertPem.Trim()
        Attributes = @{
            "Text Field 1" = $adminCertName
        }
    }

    $apps += $app

    "Importing the following certificate(s)" | Write-VenafiDebug
    $japps = $apps | ConvertTo-Json -Depth 10
    $japps | Write-VenafiDebug

    return @{ Result = "Success"; Applications = $apps }

}

#############################     Functions below are not Adaptable App functions     #################################
function Invoke-FGRestMethod {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateSet("get", "post", "put")]
        [string]
        $Method,
        [Parameter(Mandatory = $true)]
        [ValidatePattern("^\/.+")]
        [string]
        $Path,
        [Parameter(Mandatory = $false)]
        [string]
        $Payload,
        [Parameter(Mandatory = $false)]
        [Hashtable]
        $QueryParams
    )

    $uri = Join-FGUri -Path $Path -QueryParams $QueryParams

    try {
        if ($Method -ieq "get") {
            $result = Invoke-RestMethod -Method $Method -Headers $Script:header -Uri $uri
        }
        else {
            $payloadCopy = $Payload | ConvertFrom-Json
            if ($payloadCopy.password) {
                $payloadCopy.password = "******"
                "JSON Payload:" | Write-VenafiDebug
                $payloadCopy | ConvertTo-Json -Compress | Write-VenafiDebug

            }
            else {
                "JSON Payload:" | Write-VenafiDebug
                $Payload | Write-VenafiDebug
            }

            $result = Invoke-RestMethod -Method $Method -Headers $Script:header -Uri $uri -Body $Payload
        }
    }
    catch [System.Net.WebException] {
        if (($_.Exception.Status -imatch "ConnectionClosed|KeepAliveFailure") -and `
            (($Path -eq "/cmdb/system/global" -and $Method -ieq "Put") -or ($Path -eq "/monitor/vpn-certificate/local/import" -and $Method -ieq "Post"))) {
            # This is expected when updating the admin-server-cert value
            "Encountered the ""ConnectionClosed"" or ""KeepAliveFailure""exception, which is expected when activating the certificate" | Write-VenafiDebug
        }
        else {
            $msg = "WebException was encountered. Reason: $($_.Exception.Status) - $($_.Exception.Message)"
            $msg | Write-VenafiDebug
            throw $msg
        }
    }
    catch {
        $msg = "Unable to perform Invoke-RestMethod. Reason: $($_.Exception.Message)"
        $msg | Write-VenafiDebug
        throw $msg
    }

    if ($result.http_status -eq 404) {
        $msg = "The API account does not have the correct permission(s) to view/modify the resource ""$($Path)"""
        $msg | Write-VenafiDebug
        throw $msg
    }

    "FortiGate API Response:" | Write-VenafiDebug
    $result | Write-VenafiDebug
    return $result
}

function Get-FGSystemStatus {

    "Getting system status to verify further connections can be established" | Write-VenafiDebug
    $path = "/monitor/system/status"

    $result = Invoke-FGRestMethod -Method Get -Path $path
    return $result
}

function Get-FGAllSslCertificates {

    $path = "/monitor/system/available-certificates"
    $qp = @{
        vdom = "*"
    }

    $result = Invoke-FGRestMethod -Method Get -Path $path -QueryParams $qp
    return $result
}

function Set-CertificateLabel {
    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline = $true)]
        [string]
        $InputObject
    )

    "Evaluating the certificate name to ensure it does not exceed the 35 character limit" | Write-VenafiDebug

    $newCertName = $InputObject
    # Is the asset name in Venafi format
    if ($InputObject -match '^.+_.+_[A-Za-z0-9]{4}$') {

        if ( $InputObject.Length -gt 35 ) {
            # we can have at most 35 characters
            # trim the common name if needed, leave the rest intact

            $certCn, $expDate, $serialNum = $InputObject.Split('_')

            # calculate how many chars we have to work with
            $cnLengthAtMost = 35 - ($expDate.Length + $serialNum.Length + 2)

            if ($certCn.Length -ge $cnLengthAtMost) {
                $certCn = $certCn.Substring(0, $cnLengthAtMost)
            }

            $newCertName = ('{0}_{1}_{2}' -f $certCn, $expDate, $serialNum) -replace "\.", "-"

            'Asset name {0} exceeded the 35 character limit and was renamed to {1}' -f $InputObject, $newCertName | Write-Debug
        }
    }
    else {
        if ($InputObject.Length -gt 30) {
            $newCertName = $InputObject.Substring(30)
        }
    }

    return $newCertName
}

function Get-FGAllVdom {

    $path = "/cmdb/system/vdom"
    $qp = @{
        vdom = "*"
    }

    $result = Invoke-FGRestMethod -Method Get -Path $path -QueryParams $qp
    $vdoms = [System.Collections.ArrayList]::new()
    foreach ($vdom in $result.vdom) {
        [void]$vdoms.Add("$($vdom)")
    }

    $joinedVdoms = $vdoms -join ","
    "Retrieved the following VDOMs from the FortiGate device: $($joinedVdoms)" | Write-VenafiDebug

    return , $vdoms

}

function Get-FGVdomDetail {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Name
    )

    "Verifying that the Virtual Domain ""$($Name)"" exists" | Write-VenafiDebug

    $path = "/cmdb/system/vdom"
    $qp = @{
        vdom = "$($Name)"
    }

    $result = Invoke-FGRestMethod -Method Get -Path $path -QueryParams $qp
    return $result
}

function Get-FGAllSslProfile {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $VdomName
    )

    $path = "/cmdb/firewall/ssl-ssh-profile"
    $qp = @{
        vdom = $VdomName
    }

    $result = Invoke-FGRestMethod -Method Get -Path $path -QueryParams $qp
    $sslProfiles = [System.Collections.ArrayList]::new()
    foreach ($profile in $result.results) {
        if ($profile."server-cert-mode" -eq "replace") {
            [void]$sslProfiles.Add(@{
                    "profile"     = $profile.name
                    "server-cert" = $profile."server-cert"
                })
        }
    }

    return , $sslProfiles
}

function Get-FGSslProfile {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $VdomName,
        [Parameter()]
        [string]
        $ProfileName
    )

    "Verifying that the SSL Inspection Profile ""$($ProFileName)"" exists within ""$($VdomName)""" | Write-VenafiDebug

    $path = "/cmdb/firewall/ssl-ssh-profile/$($ProFileName)"
    $qp = @{
        vdom = $VdomName
    }

    $result = Invoke-FGRestMethod -Method Get -Path $path -QueryParams $qp
    return $result
}

function Set-SslProfileCert {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $CertName,
        [Parameter()]
        [string]
        $VdomName,
        [Parameter()]
        [string]
        $ProfileName
    )

    "Updating the SSL Inspection Profile using the certificate name ""$($CertName)""" | Write-VenafiDebug

    $path = "/cmdb/firewall/ssl-ssh-profile/$($ProfileName)"
    $qp = @{
        vdom = $VdomName
    }
    $jsonBody = @{
        "server-cert" = $CertName
    } | ConvertTo-Json -Compress

    $result = Invoke-FGRestMethod -Method Put -Path $path -QueryParams $qp -Payload $jsonBody
    return $result
}

Function ConvertTo-X509Certificate2 {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $PEM
    )

    "Converting PEM to X509 Object" | Write-VenafiDebug
    $certPEM = [regex]::Matches($PEM, "-+BEGIN CERTIFICATE-+(?<b64>[^-]*)-+END CERTIFICATE-+")
    $b64 = $certPEM[0].Groups['b64'].Value

    $bytes = [Convert]::FromBase64String($b64)
    $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($bytes)
    return $cert
}

function Get-FGCertificate {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $Name,
        [Parameter(Mandatory = $false)]
        [string]
        $VdomName
    )

    "Retrieving the certificate from the FortiGate device" | Write-VenafiDebug

    if ($VdomName) {
        $qp = [System.Collections.Hashtable]@{
            type = "local-cer"
            vdom = $VdomName
        }
    }
    else {
        $qp = [System.Collections.Hashtable]@{
            type  = "local-cer"
            scope = "vdom"
        }
    }

    $path = "/monitor/system/certificate/download/$($Name)/"

    $result = Invoke-FGRestMethod -Method Get -Path $path -QueryParams $qp
    return $result
}

function Set-FGAdminSetting {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $Name,
        [Parameter(Mandatory = $true)]
        [string]
        $Value
    )

    "Updating the admin-server-cert attribute to ""$($Value)""" | Write-VenafiDebug

    $path = "/cmdb/system/global"

    $jsonBody = @{
        "admin-server-cert" = $Value
    } | ConvertTo-Json -Compress

    $result = Invoke-FGRestMethod -Method Put -Path $path -Payload $jsonBody
    return $result
}

function Add-FGLocalCertificate {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $CertName,
        [Parameter(Mandatory = $true)]
        [System.Collections.ArrayList]
        $CertData,
        [Parameter(Mandatory = $true)]
        [string]
        $EncPass,
        [Parameter(Mandatory = $false)]
        [string]
        $VdomName
    )

    "Adding the certificate to the FortiGate device" | Write-VenafiDebug

    $base64 = ConvertTo-Base64 -Data $CertData

    $path = "/monitor/vpn-certificate/local/import"

    $scope = ""
    $qp = $null
    if ($VdomName) {
        $qp = @{
            vdom = $VdomName
        }

        $scope = $VdomName
    }
    else {
        $scope = "global"
    }

    $jsonBody = @{
        type         = "pkcs12"
        scope        = $scope
        certname     = $CertName
        password     = $EncPass
        file_content = $base64
    } | ConvertTo-Json -Compress

    if ($VdomName) {
        Invoke-FGRestMethod -Method Post -Path $path -Payload $jsonBody -QueryParams $qp
    }
    else {
        Invoke-FGRestMethod -Method Post -Path $path -Payload $jsonBody
    }
}

function ConvertTo-Base64 {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Collections.ArrayList]
        $Data
    )

    "Converting the Pkcs12 certificate representation byte array to Base64 encoded format" | Write-VenafiDebug
    $output = [System.Convert]::ToBase64String($Data)
    return $output
}

function Join-FGUri {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $Path,
        [Parameter(Mandatory = $false)]
        [System.Collections.Hashtable]
        $QueryParams
    )

    "Building complete URI" | Write-VenafiDebug
    "Path: $($Path)" | Write-VenafiDebug
    if ($null -eq $QueryParams) {
        $QueryParams = [System.Collections.Hashtable]::new()
    }

    $queryString = ""
    $counter = 0
    foreach ($key in $QueryParams.Keys) {
        $counter++
        if ($counter -gt 1) {
            $queryString += "&"
        }
        
        "Working on query parameter [$($key)] with the value of [$($QueryParams[$key])]" | Write-VenafiDebug
        $queryString += "$key=$($QueryParams[$key])"
    }

    $uri = "$($Script:url)$($Path)?$($queryString)"

    "Full URL is: $($uri)" | Write-VenafiDebug
    return $uri
}

function Get-FGAdminSetting {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [string]
        $Name
    )

    if ([string]::IsNullOrEmpty($Name)) {
        "Retrieving all global settings from the FortiGate device" | Write-VenafiDebug
    }
    else {
        "Retrieving the ""$($Name)"" global setting from the FortiGate device" | Write-VenafiDebug
    }

    $path = "/cmdb/system/global"

    $result = Invoke-FGRestMethod -Method Get -Path $path
    if ([string]::IsNullOrEmpty($Name)) {
        return $result
    }
    else {
        return $result.results.$Name
    }
}


#############################     Debug logging functions     #################################
Function Write-FunctionDetail {

    <#
    .SYNOPSIS
        Log function details
    .DESCRIPTION
        Log function details including the function name and any bound parameters
    .NOTES
        Must be an advanced function otherwise $PSCmdlet.MyInvocation will not be available.
        Set $script:scriptVersion to include the script version in the log.
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation

        Put this at the start of every function
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -NoBoundParams

        Do not output the bound parameters
    #>

    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Management.Automation.InvocationInfo] $InvocationInfo,

        [Parameter()]
        [switch] $NoBoundParams
    )

    $header = 'Function: {0}' -f $InvocationInfo.InvocationName
    $header += if ($script:scriptVersion) { ', script version: {0}' -f $script:scriptVersion } else { '' }
    $header | Write-VenafiDebug

    if ( $null -ne $InvocationInfo.BoundParameters -and -not $NoBoundParams ) {
        [hashtable]$InvocationInfo.BoundParameters | Write-VenafiDebug
    }
}

function Write-VenafiDebug {

    <#
    .SYNOPSIS
    Write info to the adaptable debug log

    .DESCRIPTION
    Assuming the option has been selected, write info to the adaptable debug log.
    Hashtables are supported and secret info will not be logged, eg. $General.

    .PARAMETER Message
    The info to be logged

    .PARAMETER ThrowException
    After logging the message, throw an exception to terminate the script

    .EXAMPLE
    Write-VenafiDebug -Message 'connected to server'

    Write info to the log

    .EXAMPLE
    $General | Write-VenafiDebug

    Write input parameter values to the log

    .EXAMPLE
    Write-VenafiDebug -Message 'this was not good' -ThrowException

    Write to the log and throw an exception
    #>

    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [psobject] $Message,

        [Parameter()]
        [string] $Intro,

        [Parameter()]
        [switch] $ThrowException
    )

    process {

        if ( -not $global:DEBUG_FILE ) {
            return
        }

        $newMessage = switch ($Message.GetType().FullName) {
            'System.Collections.Hashtable' {
                Set-SecretsToHidden $Message | ConvertTo-Json -Depth 5
            }

            'System.String' {
                $Message
            }

            'System.Management.Automation.ErrorRecord' {
                # powershell specific exception
                $err = $Message
                $ex = $err.Exception
                $inv = $err.InvocationInfo
                $logEntry = @{
                    Message          = $ex.Message
                    ErrorId          = $err.FullyQualifiedErrorId
                    Category         = $err.CategoryInfo.Category
                    TargetObject     = $err.TargetObject
                    ScriptName       = $inv.ScriptName
                    LineNumber       = $inv.ScriptLineNumber
                    Line             = $inv.Line
                    Position         = $inv.PositionMessage
                    StackTrace       = $ex.StackTrace
                    ScriptStackTrace = $err.ScriptStackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }
                $logEntry | ConvertTo-Json -Depth 3
            }

            'System.Exception' {
                #.net generic exception
                $ex = $Message
                $inv = $ex.InvocationInfo
                $logEntry = @{
                    Message       = $ex.Message
                    ExceptionType = $ex.GetType().FullName
                    ScriptName    = $inv.ScriptName
                    LineNumber    = $inv.ScriptLineNumber
                    Line          = $inv.Line
                    Position      = $inv.PositionMessage
                    StackTrace    = $ex.StackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }

                $logEntry | ConvertTo-Json -Depth 3
            }

            default {
                $Message | ConvertTo-Json -Depth 3
            }
        }

        if ( $Intro ) {
            $newMessage = "$Intro`r`n$newMessage"
        }

        try {
            # use a mutex to ensure multiple executions of this script don't cause 'file in use' errors
            $mutex = New-Object System.Threading.Mutex($false, [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.ScriptName))
            if ( -not $mutex.WaitOne(0) ) {
                $mutex.WaitOne()
            }
            ('{0} : {1}' -f (Get-Date), ($newMessage | Out-String)) | Out-File -FilePath $global:DEBUG_FILE -Encoding 'UTF8' -Append
        }
        catch {
            throw $_
        }
        finally {
            $null = $mutex.ReleaseMutex()
        }
    }

    end {
        if ( $ThrowException ) {
            # since we're in the end block this is only intended for a string, not array or anything that needs the pipeline
            throw $Message
        }
    }
}

function Set-SecretsToHidden {

    <#
    .SYNOPSIS
        Blank out sensitive information
    .DESCRIPTION
        Blank out sensitive information in a message, typically in a hashtable.
        Meant for adaptable framework scripts.
        Will automatically clone hashtable to ensure original object isn't affected.
    #>


    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [AllowNull()]
        [AllowEmptyString()]
        $InputObject
    )

    process {

        if ($null -eq $InputObject) {
            return $null
        }

        $secrets = @('UserPass', 'AuxPass', 'PfxPass', 'Certificate', 'PfxData', 'Password', 'AuxPfxData', 'PrivKeyPem', 'Pkcs12', 'EncryptPass', 'ChainPkcs7', 'PrivKeyPemEncrypted', 'VarPass', 'PKPass', 'PrivateKeyPem')

        if ($InputObject -is [hashtable]) {
            $clone = @{}
            foreach ($key in $InputObject.keys) {
                if ($key -in $secrets -and $null -ne $InputObject[$key] ) {
                    $clone[$key] = '***hidden***'
                }
                else {
                    $clone[$key] = Set-SecretsToHidden $InputObject[$key]
                }
            }
            return $clone
        }
        else {
            return $InputObject
        }
    }
}
# SIG # Begin signature block
# MIIh2AYJKoZIhvcNAQcCoIIhyTCCIcUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCOl1CswP+Lzi94
# a3WxjEdphIe4BGydefJKuXaMpG+DT6CCGtEwggeTMIIFe6ADAgECAhABUX9+ZWir
# r6OpYdH+HnHPMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBD
# b2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjUwOTExMDAw
# MDAwWhcNMjYwOTEwMjM1OTU5WjCBmjELMAkGA1UEBhMCVVMxFjAUBgNVBAgTDU1h
# c3NhY2h1c2V0dHMxDzANBgNVBAcTBk5FV1RPTjEgMB4GA1UEChMXQ3liZXJBcmsg
# U29mdHdhcmUsIEluYy4xHjAcBgNVBAsTFVByb2Zlc3Npb25hbCBTZXJ2aWNlczEg
# MB4GA1UEAxMXQ3liZXJBcmsgU29mdHdhcmUsIEluYy4wggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC4Rp6KSQ+kelbVZimPMfQQPYfI1sYfkuOCTvooMhol
# oVm6aKLtEzZB7s0VkLLaW3XPfyzmlereIyRsK7h/3kxiXeeNzMu2tycqoSVFxwsn
# j04ptiSZ0TeD+ciM/EHvhapRqN2e1v5VRrpvsTkp9NAwKtf1z09czOeZXo2McpQm
# 66CLXfWWu6WhxV2wtDdn998cyxbGdXAZEdQmszU3YM6G9YB/2sdONTwSWaZqri9p
# oNnbO0hEByaz13PVPwN4FNJEKyY2RT7SJjrh6jPmkZwhvn08vna96tKsrw5XxxwJ
# FsFe7W2Wxgo4hybaVA0tLlOqmp6BufGjoa7GjpdM+g/SRm7xPFcSEJkqYJzoCVWu
# 5VNydUdZttKzzi1JfGuxQAaITelrIvo0K3cHig7NwN7F2/riIvP6tv+8AGiyGuoU
# uIAdnSEIRZLzdbfELdRyf6yffNYbaIi4iCS2UMwzDKzDzL3YPMu66jkx+zkC3iH0
# jXeWJMQn+Zsry0Sqpll+9EFeFBbo+ko28SsWnWfbEpkHZz+OuwVUyYGs/YiSUWXk
# c+uGyPm8DcIeQGEfOztKydl3qE0tG0QOTqCJtl+TqPwaRZuacXTH/X/az4oSg1g5
# BSrawJ9eagUUD7jL0gOUCHakMz/4P4vkos8dDb8vitr7v9b6WOVIQ1+sEg03GvKy
# FQIDAQABo4ICAzCCAf8wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIw
# HQYDVR0OBBYEFNjJEce0IdNYQxp2y/vTz43mpVH1MD4GA1UdIAQ3MDUwMwYGZ4EM
# AQQBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSBrTCB
# qjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+GTWh0
# dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWdu
# aW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSBhzCBhDAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUFBzAC
# hlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRD
# b2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRMEAjAAMA0G
# CSqGSIb3DQEBCwUAA4ICAQCbf/9bZQmPuGFJZUHfbkHTeA/sgbbBbOMyVO/kKfX2
# 9BY6D4ChS/ZPPQKFvOvfjp9KcTC1l43oFHP7eL9tTopnVL7YQm+btRhu5aAlmjQF
# sREjc0ZSVrP0NTFOhXMP8WEp1TYCkrrtR63MNno557UYKNKwdDx9+I0MmJ4GnDVD
# ua4SyPJAUPj39x4SIBPYxqI/Ur4czUHCUFxMfhsqtNKby+u8ziTu9ec/ztcw3+VL
# V/OAW2Tk1I5GA1PfDV+mdcvVTbrt0WDhoZjrzHpvvcJ16n45e5b8wyMQMnEzcuCH
# cboEh3LPJmAptvp2B7aCkFstBXp0MOBdrgGjckvTOXLv297PEIZwQDyWZEmgBMqt
# 5rdUaKW76LzAUmLNm21ksBMozS5dRo1VUnIUHGw+lqvckqJ21oblI91baMwvnBrG
# WTqQ+ZwbLrC34Admxl2cLgg7OF8OG42ZOgiJukH4/HafX3ieqcYaZWv8Zm5U1pY2
# dWaCR16yf95MQnMmneOP+vG+awSF7Nb0/LhQTril7p/y9Gbyjz0WggmZOsTyKwY0
# IAhNpolZItrnG2+r4znOUkgc9uVXXMnU1J0CnTG1dDLTbcxyjvSngGh51oaS3RQm
# 160iipGj6pCs57DLp7Z7uNS9dHZkFOPoN0qJnTsl45Ja+FERtAE05mxtFsaUrhqO
# ETCCBY0wggR1oAMCAQICEA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcNAQEMBQAw
# ZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQ
# d3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBS
# b290IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2lj
# ZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv+aQc2jeu+RdSjwwIjBpM+zCpyUu
# ySE98orYWcLhKac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR0uRf1gU8
# Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlqczKU0RBEEC7fgvMHhOZ0O21x4i0M
# G+4g1ckgHWMpLc7sXk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53yEioZldX
# n1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17cjo+A2raRmECQecN4x7axxLVq
# GDgDEI3Y1DekLgV9iPWCPhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3VdeGbZOjFE
# mjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfBaYh2mHY9WV1CdoeJl2l6
# SPDgohIbZpp0yt5LHucOY67m1O+SkjqePdwA5EUlibaaRBkrfsCUtNJhbesz2cXf
# SwQAzH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaAsPvoZKYz0YkH4b23
# 5kOkGLimdwHhD5QMIR2yVCkliWzlDlJRR3S+Jqy2QXXeeqxfjT/JvNNBERJb5RBQ
# 6zHFynIWIgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCPorF+CiaZ9eRp
# L5gdLfXZqbId5RsCAwEAAaOCATowggE2MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0O
# BBYEFOzX44LScV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5BggrBgEFBQcBAQRtMGswJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNydDBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1UdIAQKMAgwBgYEVR0gADAN
# BgkqhkiG9w0BAQwFAAOCAQEAcKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqsoYcs7IVe
# qRq7IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy3iS8UgPITtAq3vot
# Vs/59PesMHqai7Je1M/RQ0SbQyHrlnKhSLSZy51PpwYDE3cnRNTnf+hZqPC/Lwum
# 6fI0POz3A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxUjG/voVA9/HYJ
# aISfb8rbII01YBwCA8sgsKxYoA5AY8WYIsGyWfVVa88nq2x2zm8jLfR+cWojayL/
# ErhULSd+2DrZ8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDCCBrQwggScoAMCAQIC
# EA3HrFcF/yGZLkBDIgw6SYYwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTI1MDUwNzAw
# MDAwMFoXDTM4MDExNDIzNTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
# Z2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVT
# dGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBALR4MdMKmEFyvjxGwBysddujRmh0tFEXnU2tjQ2UtZmW
# gyxU7UNqEY81FzJsQqr5G7A6c+Gh/qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzb
# NfiR+2fkHUiljNOqnIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0mR/vtLa4+gKPs
# YfwEu7EEbkC9+0F2w4QJLVSTEG8yAR2CQWIM1iI5PHg62IVwxKSpO0XaF9DPfNBK
# S7Zazch8NF5vp7eaZ2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhxKTVVgtmU
# PAW35xUUFREmDrMxSNlr/NsJyUXzdtFUUt4aS4CEeIY8y9IaaGBpPNXKFifinT7z
# L2gdFpBP9qh8SdLnEut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x5HHK
# S+rqBvKWxdCyQEEGcbLe1b8Aw4wJkhU1JrPsFfxW1gaou30yZ46t4Y9F20HHfIY4
# /6vHespYMQmUiote8ladjS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogx
# G9QEPHrPV6/7umw052AkyiLA6tQbZl1KhBtTasySkuJDpsZGKdlsjg4u70EwgWbV
# RSX1Wd4+zoFpp4Ra+MlKM2baoD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNT
# AgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBTvb1NK
# 6eQGfHrK4pBW9i/USezLTjAfBgNVHSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUH
# AQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYI
# KwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcw
# CAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAF877FoAc
# /gc9EXZxML2+C8i1NKZ/zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAz
# aoQk97frPBtIj+ZLzdp+yXdhOP4hCFATuNT+ReOPK0mCefSG+tXqGpYZ3essBS3q
# 8nL2UwM+NMvEuBd/2vmdYxDCvwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntu
# jB71WPYAgwPyWLKu6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOal95CHfmTnM4I+ZI2
# rVQfjXQA1WSjjf4J2a7jLzWGNqNX+DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z
# 0noDjs6+BFo+z7bKSBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/NmKLJ9M+MtucVG
# yOxiDf06VXxyKkOirv6o02OoXN4bFzK0vlNMsvhlqgF2puE6FndlENSmE+9JGYxO
# GLS/D284NHNboDGcmWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3rGlHqhpB
# /8MluDezooIs8CVnrpHMiD2wL40mm53+/j7tFaxYKIqL0Q4ssd8xHZnIn/7GELH3
# IdvG2XlM9q7WP/UwgOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlarEvf8
# EA+8hcpSM9LHJmyrxaFtoza2zNaQ9k+5t1wwggbtMIIE1aADAgECAhAKgO8YS43x
# BYLRxHanlXRoMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBU
# aW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAw
# MDAwWhcNMzYwOTAzMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGln
# aUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRp
# bWVzdGFtcCBSZXNwb25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEA0EasLRLGntDqrmBWsytXum9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7
# C8Dr0cVMF3BsfAFI54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAqlUPt281m
# HrBbZHqRK71Em3/hCGC5KyyneqiZ7syvFXJ9A72wzHpkBaMUNg7MOLxI6E9RaUue
# HTQKWXymOtRwJXcrcTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd2adw
# 44wDcKgH+JRJE5Qg0NP3yiSyi5MxgU6cehGHr7zou1znOM8odbkqoK+lJ25LCHBS
# ai25CFyD23DZgPfDrJJJK77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvh
# DU6lvJukx7jphx40DQt82yepyekl4i0r8OEps/FNO4ahfvAk12hE5FVs9HVVWcO5
# J4dVmVzix4A77p3awLbr89A90/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIU
# bWuhKuAeNIeWrzHKYueMJtItnj2Q+aTyLLKLM0MheP/9w6CtjuuVHJOVoIJ/DtpJ
# RE7Ce7vMRHoRon4CWIvuiNN1Lk9Y+xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CID
# BbTRofOsNyEhzZtCGmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7eacCAwEAAaOC
# AZUwggGRMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFOQ7/PIx7f391/ORcWMZUEPP
# YYzoMB8GA1UdIwQYMBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1UdDwEB/wQE
# AwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDCBlQYIKwYBBQUHAQEEgYgwgYUw
# JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEFBQcw
# AoZRaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0
# VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYw
# VKBSoFCGTmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRH
# NFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAX
# MAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBAGUqrfEc
# JwS5rmBB7NEIRJ5jQHIh+OT2Ik/bNYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz
# 9iZEN/FPsLSTwVQWo2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV+Kbz/3ImZlJ7
# YXwBD9R0oU62PtgxOao872bOySCILdBghQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8l
# D8QAGB9lctZTTOJM3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fxUFEp7W42
# fNBVN4ueLaceRf9Cq9ec1v5iQMWTFQa0xNqItH3CPFTG7aEQJmmrJTV3Qhtfparz
# +BW60OiMEgV5GWoBy4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu/CIJ
# nzkQTwtSSpGGhLdjnQ4eBpjtP+XB3pQCtv4E5UCSDag6+iX8MmB10nfldPF9SVD7
# weCC3yXZi/uuhqdwkgVxuiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH
# 3EmAp/jsJ3FVF3+d1SVDTmjFjLbNFZUWMXuZyvgLfgyPehwJVxwC+UpX2MSey2ue
# Iu9THFVkT+um1vshETaWyQo8gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6I
# Ls84ZPvmpovq90K8eWyG2N01c4IhSOxqt81nMYIGXTCCBlkCAQEwfTBpMQswCQYD
# VQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lD
# ZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEg
# Q0ExAhABUX9+ZWirr6OpYdH+HnHPMA0GCWCGSAFlAwQCAQUAoIGIMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCSqGSIb3DQEJBTEPFw0yNTEyMTcxNzUxNTNa
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCD+
# G6BUaNPz2aXrKEGlghWfh+sgiaUQ6q+XZxQc48Y96jANBgkqhkiG9w0BAQEFAASC
# AgBbAuqUeqtg7pi7TFisSN6xq9TYNSL1M1BO8EfXMvKCAtpAvcSHNrHfyfk3IbO8
# 5oCTptW9Sj8rD6V6y6DeiKOp3d63jV20m8OItjHWblMt+u7GNGol3OH/60069NjN
# 0sBAEnEwqVTscqsUdcydeymXX6/wDWs+jgcvU6MIXuzypZJ3NhNozc0Hh0VxyXrw
# h56ocM6nRn3O5W3LAwgM1bJlVsvAC8xWUsjV5bhPDIR0P95JeG96nPfMS4RbmsPL
# AxybQ2tXTa4gik+Qu0tUg4JhaAeiwc5RJKFp1O0563FUPsApGJA3ttGIo+WAvIBk
# Yryu3gRze5gyjBgTboATq8p0OgcNakJQMX+xbn5CX7VX+yVT+DEh30VFko57AvGZ
# XJ8JzHZZqHUDeX3qiT5lBj7Ln38V5wHC71gHYWISt5x4ORyl7izix75y1KDofufn
# GQ1f5PVdGsf/nVpzqKdQWpNUmvpwfbZ7395vMDGK2VT6YZClFNS7TSyMhdkC3dHj
# iSW3cvrhfS3ijWdjKj5DjUbBkBuB22nAZvSsyB0K/olT8P5UifINehkV2UKRPg7g
# aoWKHrSE/SaQ+oK6ELXUyi3vNJt3ROvIuQlEgFsEOj8A9p0GxObpWnROp70GuAPA
# iad8EyM5Y2d1vBYDhMwbFtl/3coCHJ/cbZiNu0vq7SH4XaGCAyYwggMiBgkqhkiG
# 9w0BCQYxggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdp
# Q2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3Rh
# bXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgw
# DQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
# SIb3DQEJBTEPFw0yNTEyMTcxNzUxNTRaMC8GCSqGSIb3DQEJBDEiBCDqudDi5GWv
# Cs1HDvpX5wd0DmyaErzGHKO3m/ui+lDdKTANBgkqhkiG9w0BAQEFAASCAgC6OcCU
# YAsbSl+d56ovQwBPxl1L0tBBPXxTF9R8Ij7UxUy8lytSEKgOmzZdTj+omP7PIa8r
# rzYqbgdby+6RaK+JSdu8qstMe9OYEWptRKOubchi8ZACdd8b8RVn7jLub8KD3FMc
# GC10BGd35iuthcpEpoPP1UwbuJGqJIgSX84SeWIV4Gf1LyrgifD5Jc2JPYs5Dm/i
# I3wov2NdRjW/dAuWsJomc6KfSnTtLy8te4E27KyIHpm4A8h/i0Ig69HjybivLCF3
# 2ycNpI4u4jvytRYz+/+JH4QtAOWKUnqsSeE9od1s9MHg+Oqvz259k+0ZbBH7k9q1
# 0vpgFKHl4FtvlbswofOE8p7BU+2ppnsIb0RQ7lJLiVyBvMpo0x8IrY2GAbdtHJCA
# FkpyQLUoBcTRBYJ75fUtc1KRSD1EVAEFnDt9AyCqOfH7yUcgU5K04RJF9PUeHoM9
# qzH6oquXz2xIlhDKOoQy7JfNhY6C9zjIB0qiSUrHQKnxNBLc+1XT5+0n7IS/A8gJ
# z4YKbReKkbXEdPWYqO3E8LBXcIp0nm+v/1KTImNodQPmVX5q+F2Vz2/sy/uweDaK
# fVxYWMvu7f9iAb931Z2+GbJhL5cvVSfwx1/zr9T+6lhul1EuuII/aoPCXrf+dtMM
# SuRqGmtAp1Yw8k33F4tAOcw+xRjAvKMeTefUhA==
# SIG # End signature block

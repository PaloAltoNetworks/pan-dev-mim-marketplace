module venafi.com/vcloud2tpp

require (
	github.com/spf13/cobra v1.1.1
	github.com/spf13/viper v1.7.0
)

go 1.13

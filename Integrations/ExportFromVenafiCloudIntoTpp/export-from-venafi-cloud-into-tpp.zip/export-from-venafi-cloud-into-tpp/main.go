package main

import (
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/spf13/cobra"
)

func main() {

	var apiAddrCloud string
	var apiKey string
	var apiAddrTPP string
	var accessToken string
	var policyFolderDN string
	var thenDays int
	var batchSize int
	var isInsecure bool
	var isDebug bool

	var rootCmd = &cobra.Command{
		Use:   "vcloud2tpp",
		Short: "Export certs from Venafi Cloud and import into TPP",
		Long:  "Export non-expired, non-retired certificates from Venafi Cloud and import them directly into TPP.",
		Args:  cobra.NoArgs,
		Run: func(cmd *cobra.Command, args []string) {
			doWork(apiAddrCloud, apiKey, apiAddrTPP, accessToken, policyFolderDN, thenDays, batchSize, isInsecure, isDebug)
		},
	}

	rootCmd.Flags().StringVarP(&apiAddrCloud, "cloud-addr", "", "api.venafi.cloud", "Network address of Venafi Cloud API")
	rootCmd.Flags().StringVarP(&apiKey, "api-key", "k", "", "API Key for Venafi Cloud (required)")
	rootCmd.Flags().IntVarP(&thenDays, "days", "", 0, "Export only certificates added within the specified number of days")
	rootCmd.Flags().IntVarP(&batchSize, "batch-size", "", 100, "Batch size for Venafi Cloud export pagination")
	rootCmd.Flags().StringVarP(&apiAddrTPP, "tpp-addr", "a", "", "Network address of Trust Protection Platform WebSDK API (required)")
	rootCmd.Flags().StringVarP(&accessToken, "access-token", "t", "", "Access Token for TPP that has 'certificate:discover' scope (required)")
	rootCmd.Flags().StringVarP(&policyFolderDN, "folder-dn", "f", "", "TPP policy folder DN to target for imported certificates (required)")
	rootCmd.Flags().BoolVarP(&isInsecure, "insecure", "", false, "Connect to network addresses without any TLS verification")
	rootCmd.Flags().BoolVarP(&isDebug, "debug", "", false, "Create files showing POST discovery/import JSON, skipped certificates, etc.")

	rootCmd.MarkFlagRequired("api-key")
	rootCmd.MarkFlagRequired("tpp-addr")
	rootCmd.MarkFlagRequired("access-token")
	rootCmd.MarkFlagRequired("folder-dn")

	rootCmd.Execute()
}

func doWork(apiAddrCloud string, apiKey string, apiAddrTPP string, accessToken string, zone string,
	thenDays int, batchSize int, isInsecure bool, isDebug bool) {

	if strings.HasPrefix(apiAddrCloud, "https://") {
		apiAddrCloud = apiAddrCloud[len("https://"):len(apiAddrCloud)]
	}

	if strings.HasPrefix(apiAddrTPP, "https://") {
		apiAddrTPP = apiAddrTPP[len("https://"):len(apiAddrTPP)]
	}

	if !strings.HasPrefix(zone, "\\VED\\Policy") {
		zone = fmt.Sprintf("\\VED\\Policy\\%v", zone)
	}

	log.Printf("Process initialized with batch size of %v for pagination.\n", batchSize)

	page := 0

	now := time.Now().UTC()
	nowString := now.Format("2006-01-02T15:04:05.000") + "+0000"
	filterNotExpired := searchOperand{Field: "validityEnd", Operator: "GTE", Value: nowString}

	filterStatusActive := searchOperand{Field: "certificateStatus", Operator: "EQ", Value: "ACTIVE"}
	filterStatusUnknown := searchOperand{Field: "certificateStatus", Operator: "EQ", Value: ""}
	filterNotRetired := searchOperand{Operator: "OR", Operands: []searchOperand{filterStatusActive, filterStatusUnknown}}

	var reqExport certificateSearchRequest
	reqExport.Ordering = searchOrdering{Orders: []searchOrder{searchOrder{Direction: "ASC", Field: "validityEnd"}}}

	if thenDays == 0 {
		reqExport.Expression = searchExpression{Operator: "AND",
			Operands: []searchOperand{filterNotRetired, filterNotExpired}}
	} else {
		then := now.AddDate(0, 0, -thenDays)
		thenString := then.Format("2006-01-02T15:04:05.000") + "+0000"
		filterLastModified := searchOperand{Field: "creationDate", Operator: "GTE", Value: thenString}

		reqExport.Expression = searchExpression{Operator: "AND",
			Operands: []searchOperand{filterNotRetired, filterNotExpired, filterLastModified}}
	}

	for {
		reqExport.Paging = searchPaging{PageNumber: page, PageSize: batchSize}

		respExport, err := postExportRequest(apiAddrCloud, apiKey, reqExport, isInsecure)
		if err != nil {
			log.Fatalln(err)
		}
		if respExport.Count == 0 {
			log.Printf("No certificates met the criteria to be exported from Venafi Cloud.")
			break
		}

		var reqImport discoveryImportRequest
		reqImport.ZoneName = zone

		for _, cert := range respExport.Certificates {

			b64, err := getRawCertificate(apiAddrCloud, apiKey, cert.ID, isInsecure)
			if err != nil {
				log.Fatalln(err)
			}

			// Until Venafi Cloud cert details distinguishes CA certs from EE, decode the raw cert and check
			isCA, err := isCertificateAuthority(b64)
			if err != nil {
				log.Printf("skipping %s (%v)\n", cert.Fingerprint, err)
			}
			if isCA {
				log.Printf("skipping %s (CA certificate)\n", cert.Fingerprint)
				continue
			}

			for _, instance := range cert.Instances {
				var endpoint discoveryEndpoint
				discoCert := discoveryCertificate{Certificate: b64, Fingerprint: cert.Fingerprint}
				endpoint.Certificates = []discoveryCertificate{discoCert}
				endpoint.Host = strings.TrimSpace(instance.Hostname)
				if instance.IPAddress != "" {
					endpoint.IP = instance.IPAddress
				} else {
					endpoint.IP = strings.TrimSpace(instance.Hostname)
				}
				if instance.Port >= 0 {
					endpoint.Port = instance.Port
				}
				discoProto := discoveryProtocol{Certificates: []string{cert.Fingerprint}, Protocol: ""}
				endpoint.Protocols = []discoveryProtocol{discoProto}

				reqImport.Endpoints = append(reqImport.Endpoints, endpoint)
			}
		}

		log.Printf("[Page %v] Exported %v certificates from Venafi Cloud.\n", page, respExport.Count)

		if isDebug {
			data, _ := json.Marshal(reqImport)
			filename := fmt.Sprintf("page_%v_request.json", page)
			f, _ := os.Create(filename)
			defer f.Close()
			f.Write(data)
		}

		respImport, err := postImportRequest(apiAddrTPP, accessToken, reqImport, isInsecure)
		if err != nil {
			log.Println(err)
		} else {
			if respImport.Error != "" {
				log.Fatalf("Error: %v\n", respImport.Error)
			} else {
				log.Printf("Certificates: %v added, %v updated; Instances: %v added, %v updated; %v Warnings.\n",
					respImport.CreatedCertificates, respImport.UpdatedCertificates,
					respImport.CreatedInstances, respImport.UpdatedInstances, len(respImport.Warnings))

				if isDebug && len(respImport.Warnings) > 0 {
					filename := fmt.Sprintf("page_%v_warnings.log", page)
					f, _ := os.Create(filename)
					defer f.Close()
					for _, warning := range respImport.Warnings {
						f.WriteString(fmt.Sprintf("%v\n", warning))
					}
				}
			}
		}

		if respExport.Count != batchSize {
			break
		}
		page = page + 1
	}
}

func isCertificateAuthority(b64 string) (bool, error) {
	pemCert := fmt.Sprintf("-----BEGIN CERTIFICATE-----\n%v\n-----END CERTIFICATE-----", b64)

	block, _ := pem.Decode([]byte(pemCert))
	if block == nil {
		return false, errors.New("failed to parse certificate PEM")
	}
	cert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		return false, errors.New("failed to parse certificate: " + err.Error())
	}

	return cert.IsCA, nil
}

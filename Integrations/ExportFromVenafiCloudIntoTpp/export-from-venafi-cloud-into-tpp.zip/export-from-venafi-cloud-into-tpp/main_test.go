package main

import (
	"os"
	"testing"
)

func TestDoWork(t *testing.T) {

	apiAddrCloud := os.Getenv("CLOUD_ADDR")
	apiKey := os.Getenv("CLOUD_APIKEY")
	apiAddrTPP := os.Getenv("TPP_ADDR")
	accessToken := os.Getenv("TPP_TOKEN")
	zone := os.Getenv("TPP_FOLDER")

	if apiAddrCloud == "" {
		apiAddrCloud = "api.venafi.cloud"
	}

	doWork(apiAddrCloud, apiKey, apiAddrTPP, accessToken, zone, 30, 20, true, true)
}

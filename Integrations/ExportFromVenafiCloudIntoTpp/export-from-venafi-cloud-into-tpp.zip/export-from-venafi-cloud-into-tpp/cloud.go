package main

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
)

type searchOperand struct {
	Field    string          `json:"field,omitempty"`
	Operator string          `json:"operator,omitempty"`
	Value    string          `json:"value,omitempty"`
	Operands []searchOperand `json:"operands,omitempty"`
}

type searchOrder struct {
	Direction string `json:"direction,omitempty"`
	Field     string `json:"field,omitempty"`
}

type searchExpression struct {
	Operator string          `json:"operator,omitempty"`
	Operands []searchOperand `json:"operands,omitempty"`
}

type searchOrdering struct {
	Orders []searchOrder `json:"orders,omitempty"`
}

type searchPaging struct {
	PageNumber int `json:"pageNumber,omitempty"`
	PageSize   int `json:"pageSize,omitempty"`
}

type certificateSearchRequest struct {
	Expression searchExpression `json:"expression,omitempty"`
	Ordering   searchOrdering   `json:"ordering,omitempty"`
	Paging     searchPaging     `json:"paging,omitempty"`
}

// datetime values returned by Venafi Cloud cannot be parsed into time.Time so use strings

type searchInstance struct {
	CertificateInstanceID string   `json:"certificateInstanceId,omitempty"`
	CertificateID         string   `json:"certificateId,omitempty"`
	CertificateSource     string   `json:"certificateSource,omitempty"`
	ModificationDate      string   `json:"modificationDate,omitempty"`
	IPAddress             string   `json:"ipAddress,omitempty"`
	Hostname              string   `json:"hostname,omitempty"`
	Port                  int      `json:"port,omitempty"`
	LastScanDate          string   `json:"lastScanDate,omitempty"`
	ApplicationIds        []string `json:"applicationIds,omitempty"`
	DeploymentStatus      string   `json:"deploymentStatus,omitempty"`
}

type searchCertificate struct {
	ID                        string           `json:"id,omitempty"`
	ManagedCertificateID      string           `json:"managedCertificateId,omitempty"`
	Fingerprint               string           `json:"fingerprint,omitempty"`
	CertificateStatus         string           `json:"certificateStatus,omitempty"`
	ModificationDate          string           `json:"modificationDate,omitempty"`
	ValidityStart             string           `json:"validityStart,omitempty"`
	ValidityEnd               string           `json:"validityEnd,omitempty"`
	SerialNumber              string           `json:"serialNumber,omitempty"`
	SubjectCN                 []string         `json:"subjectCN,omitempty"`
	SubjectOU                 []string         `json:"subjectOU,omitempty"`
	SubjectL                  string           `json:"subjectL,omitempty"`
	SubjectST                 string           `json:"subjectST,omitempty"`
	SubjectC                  string           `json:"subjectC,omitempty"`
	SubjectAlternativeNameDNS []string         `json:"subjectAlternativeNameDns,omitempty"`
	TotalInstanceCount        int              `json:"totalInstanceCount,omitempty"`
	TotalActiveInstanceCount  int              `json:"totalActiveInstanceCount,omitempty"`
	Instances                 []searchInstance `json:"instances,omitempty"`
}

type certificateSearchResponse struct {
	Count        int                 `json:"count,omitempty"`
	Certificates []searchCertificate `json:"certificates,omitempty"`
}

func postExportRequest(apiAddr string, apiKey string, data interface{}, isInsecure bool) (*certificateSearchResponse, error) {
	url := fmt.Sprintf("https://%s/outagedetection/v1/certificatesearch", apiAddr)
	body, err := json.Marshal(data)
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(body))
	req.Header.Add("tppl-api-key", apiKey)
	req.Header.Add("Accept", "application/json")
	req.Header.Add("Content-Type", "application/json")

	config := &tls.Config{
		InsecureSkipVerify: isInsecure,
	}
	tr := &http.Transport{TLSClientConfig: config}
	client := &http.Client{Transport: tr}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()
	bodyBytes, _ := ioutil.ReadAll(resp.Body)

	var respData certificateSearchResponse
	err = json.Unmarshal(bodyBytes, &respData)
	if err != nil {
		return nil, err
	}

	return &respData, nil
}

func getRawCertificate(apiAddr string, apiKey string, id string, isInsecure bool) (string, error) {
	url := fmt.Sprintf("https://%s/outagedetection/v1/certificates/%s/contents?chainOrder=EE_ONLY", apiAddr, id)
	req, err := http.NewRequest(http.MethodGet, url, nil)
	req.Header.Add("tppl-api-key", apiKey)
	req.Header.Add("Accept", "*/*")

	config := &tls.Config{
		InsecureSkipVerify: isInsecure,
	}
	tr := &http.Transport{TLSClientConfig: config}
	client := &http.Client{Transport: tr}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}

	defer resp.Body.Close()
	bodyBytes, _ := ioutil.ReadAll(resp.Body)
	pem := string(bodyBytes)

	pem = strings.ReplaceAll(pem, "-----BEGIN CERTIFICATE-----", "")
	pem = strings.ReplaceAll(pem, "-----END CERTIFICATE-----", "")
	pem = strings.ReplaceAll(pem, "\n", "")

	return pem, nil
}

package main

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

type discoveryCertificate struct {
	Certificate string `json:"certificate,omitempty"`
	Fingerprint string `json:"fingerprint,omitempty"`
}

type discoveryProtocol struct {
	Certificates []string `json:"certificates,omitempty"`
	Protocol     string   `json:"protocol,omitempty"`
}

type discoveryEndpoint struct {
	Certificates []discoveryCertificate `json:"certificates,omitempty"`
	Host         string                 `json:"host,omitempty"`
	IP           string                 `json:"ip,omitempty"`
	Port         int                    `json:"port,omitempty"`
	Protocols    []discoveryProtocol    `json:"protocols,omitempty"`
}

type discoveryImportRequest struct {
	ZoneName  string              `json:"zoneName,omitempty"`
	Endpoints []discoveryEndpoint `json:"endpoints,omitempty"`
}

type discoveryImportResponse struct {
	CreatedCertificates int      `json:"createdCertificates,omitempty"`
	CreatedInstances    int      `json:"createdInstances,omitempty"`
	UpdatedCertificates int      `json:"updatedCertificates,omitempty"`
	UpdatedInstances    int      `json:"updatedInstances,omitempty"`
	Warnings            []string `json:"warnings,omitempty"`
	Error               string   `json:"Error,omitempty"`
	ZoneName            string   `json:"zoneName,omitempty"`
}

func postImportRequest(apiAddr string, accessToken string, data interface{}, isInsecure bool) (*discoveryImportResponse, error) {
	url := fmt.Sprintf("https://%s/vedsdk/discovery/import", apiAddr)
	body, err := json.Marshal(data)
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(body))
	req.Header.Add("Authorization", fmt.Sprintf("Bearer %s", accessToken))
	req.Header.Add("Content-Type", "application/json")

	config := &tls.Config{
		InsecureSkipVerify: isInsecure,
	}
	tr := &http.Transport{TLSClientConfig: config}
	client := &http.Client{Transport: tr}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()
	bodyBytes, _ := ioutil.ReadAll(resp.Body)

	var respData discoveryImportResponse
	err = json.Unmarshal(bodyBytes, &respData)
	if err != nil {
		return nil, err
	}

	return &respData, nil
}

<#
//------------------------------------------------------------------------
// FortiWeb Adaptable Application Driver PowerShell Script V2.3
//
// Copyright ©2026 Venafi, Inc. All rights reserved. This integration module 
// is licensed under the same terms and conditions as your CyberArk product, 
// available here: https://www.cyberark.com/contract-terms/
//------------------------------------------------------------------------


<field name>|<label text>|<flags>

Bit 1 = Enabled
Bit 2 = Policyable
Bit 3 = Mandatory

-----BEGIN FIELD DEFINITIONS-----
Text1|FortiWeb Certificate Name|101
Text2|ADOM|110
Text3|CA Group|111
Text4|Intermediate CA Group|111
Text5|Text Field #5|000
Option1|Update Server and SNI Policies|111
Option2|Yes/No Option #2
Passwd|Password Field|000
-----END FIELD DEFINITIONS-----
#>

if ( $PSVersionTable.PSEdition -eq 'Core' ) {
    # ps core, assume vaas
    $PSDefaultParameterValues['Invoke-WebRequest:SkipCertificateCheck'] = $true
    $PSDefaultParameterValues['Invoke-RestMethod:SkipCertificateCheck'] = $true
}
else {
    # need the following to interface with an untrusted certificate
    Add-Type -TypeDefinition @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@

    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}
$script:scriptVersion = '2.3'
$script:scriptName = 'AdaptableApp\FortiWeb'



function Test-Connection {

    # TLSPC connection test

    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )
    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

    $UserName = $General.UserName
    $Password = $General.UserPass
    $ADOM = $General.VarText2

    Write-VenafiDebug  "Test-Connection"

    $uri = "https://$($General.HostAddress)/api/v2.0/system/status.adoms"
    $AuthToken = Create-FortiWeb-Auth-JSON -User $UserName -Pass $Password -ADOM $ADOM

    try {
        $response = Invoke-RestMethod -Uri $uri -Headers @{ Authorization = $AuthToken }
    }
    catch {
        # this api doesn't throw a 401 when invalid creds are used
        if ( $_.Exception.Message -match '^The format of value .* is invalid.$' ) {
            throw 'Invalid username or password'
        }
        else {
            throw $_
        }
    }

    return @{ 'Result' = 'Success' }
}

<######################################################################################################################
.NAME
    Prepare-KeyStore
.DESCRIPTION
    Remotely create and/or verify keystore on the hosting platform.  Remote generation is considered UNSUPPORTED if this
    function is ommitted or commented out.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        HostAddress : a string containing the hostname or IP address specified by the device object
        TcpPort : an integer value containing the TCP port specified by the application object
        UserName : a string containing the username portion of the credential assigned to the device or application object
        UserPass : a string containing the password portion of the credential assigned to the device or application object
        UserPrivKey : the non-encrypted PEM of the private key credential assigned to the device or application object
        AppObjectDN : a string containing the TPP distiguished name of the calling application object
        AssetName : a string containing a Venafi standard auto-generated name that can be used for provisioning
                    (<Common Name>-<ValidTo as YYMMDD>-<Last 4 of SerialNum>)
        VarText1 : a string value for the text custom field defined by the header at the top of this script
        VarText2 : a string value for the text custom field defined by the header at the top of this script
        VarText3 : a string value for the text custom field defined by the header at the top of this script
        VarText4 : a string value for the text custom field defined by the header at the top of this script
        VarText5 : a string value for the text custom field defined by the header at the top of this script
        VarBool1 : a boolean value for the yes/no custom field defined by the header at the top of this script (true|false)
        VarBool2 : a boolean value for the yes/no custom field defined by the header at the top of this script (true|false)
        VarPass : a string value for the password custom field defined by the header at the top of this script
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
######################################################################################################################>
function Prepare-KeyStore {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    return @{ Result = "NotUsed"; }
}


<######################################################################################################################
.NAME
    Generate-KeyPair
.DESCRIPTION
    Remotely generates a public-private key pair on the hosting platform.  Remote generation is
    considered UNSUPPORTED if this function is ommitted or commented out.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        KeySize : the integer key size to be used when creating a key pair
        EncryptPass : the password string to use if encrypting the remotely generated private key
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
        AssetName : (optional) the base name used to reference the certificate as it was installed on the device;
                    if not supplied the auto-generated name is assumed
######################################################################################################################>
function Generate-KeyPair {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    return @{ Result = "NotUsed" }
}


<######################################################################################################################
.NAME
    Generate-CSR
.DESCRIPTION
    Remotely generates a CSR on the hosting platform.  Remote generation is considered UNSUPPORTED
    if this function is ommitted or commented out.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        SubjectDN : the requested subject distiguished name as a hashtable; OU is a string array; all others are strings
        SubjAltNames : hashtable keyed by SAN type; values are string arrays of the individual SANs
        KeySize : the integer key size to be used when creating a key pair
        EncryptPass : the password string to use if encrypting the remotely generated private key
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
        Pkcs10 : a string representation of the CSR in PKCS#10 format
        AssetName : (optional) the base name used to reference the certificate as it was installed on the device;
                    if not supplied the auto-generated name is assumed
######################################################################################################################>
function Generate-CSR {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )
    return @{ Result = "NotUsed" }

}


<######################################################################################################################
.NAME
    Install-Chain
.DESCRIPTION
    Installs the certificate chain on the hosting platform.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        ChainPem : all chain certificates concatentated together one after the other
        ChainPkcs7 : byte array PKCS#7 collection that includes all chain certificates
.NOTES
    Returns...
        Result : 'Success', 'AlreadyInstalled' or 'NotUsed' to indicate the non-error completion state
######################################################################################################################>
function Install-Chain {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
    
    try {

        $UserName = $General.UserName
        $Password = $General.UserPass
        $CAGroup = $General.VarText3
        $InterGroup = $General.VarText4
        $ADOM = $General.VarText2

        $AuthToken = Create-FortiWeb-Auth-JSON -User $UserName -Pass $Password -ADOM $ADOM

        $HostDetails = @{
            HostAddress = $General.HostAddress
            Headers     = @{
                Authorization = $AuthToken
            }
        }
        # Log FortiWeb firmware version (for informational purposes only)
        Get-FortiWebVersion -HostAddress $HostDetails.HostAddress -AuthToken $HostDetails.Headers.Authorization

        # Retrieve certificates from ChainPem and add each to an array
        $beginIndex = "-----BEGIN CERTIFICATE-----"
        $endIndex = "-----END CERTIFICATE-----"
        $pattern = "((?s)$beginIndex.*?$endIndex(?-s))"
        $chainCerts = @{
            cas           = @()
            intermediates = @()
        }

        $match = Select-String $pattern -InputObject $Specific.ChainPem -AllMatches

        for ($i = 0; $i -lt $match.Matches.Length; $i++) {
            $enc = [System.Text.Encoding]::UTF8
            [byte[]]$data = $enc.GetBytes($match.Matches[$i].Value)
            [System.Security.Cryptography.X509Certificates.X509Certificate2]$cert = `
                [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($data)

            if ($cert.Subject.Trim() -eq $cert.Issuer.Trim()) {
                $chainCerts.cas += $cert
            }
            else {
                $chainCerts.intermediates += $cert
            }
        }

        #Process root certificates
        ProvisionCerts -Certificates $chainCerts -Type "ca" -Group $CAGroup -HostDetails $HostDetails
        #Process intermediate certificates
        ProvisionCerts -Certificates $chainCerts -Type "intermediateca" -Group $InterGroup -HostDetails $HostDetails
        return @{ 'Result' = 'Success' }

    }
    catch {
        throw "Chain installation failed. $_"
    }

    return @{ 'Result' = 'Success' }
}


<######################################################################################################################
.NAME
    Install-PrivateKey
.DESCRIPTION
    Installs the private key on the hosting platform.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        PrivKeyPem : the non-encrypted private key in RSA Base64 PEM format
        PrivKeyPemEncrypted : the password encrypted private key in RSA Base64 PEM format
        EncryptPass : the string password that was used to encrypt the private key and PKCS#12 keystore
.NOTES
    Returns...
        Result : 'Success', 'AlreadyInstalled' or 'NotUsed' to indicate the non-error completion state
        AssetName : (optional) the base name used to reference the private key as it was installed on the device;
                    if not supplied the auto-generated name is assumed
######################################################################################################################>
function Install-PrivateKey {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    return @{ Result = "Success" }
}


<######################################################################################################################
.NAME
    Install-Certificate
.DESCRIPTION
    Installs the certificate on the hosting platform.  May optionally be used to also install the private key and chain.
    Implementing logic for this function is REQUIRED.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        CertPem : the X509 certificate to be provisioned in Base64 PEM format
        PrivKeyPem : the non-encrypted private key in RSA Base64 PEM format
        PrivKeyPemEncrypted : the password encrypted private key in RSA Base64 PEM format
        ChainPem : all chain certificates concatentated together one after the other
        ChainPkcs7 : byte array PKCS#7 collection that includes all chain certificates
        Pkcs12 : byte array PKCS#12 collection that includes certificate, private key, and chain
        EncryptPass : the string password that was used to encrypt the private key and PKCS#12 keystore
.NOTES
    Returns...
        Result : 'Success', 'AlreadyInstalled' or 'NotUsed' to indicate the non-error completion state
                 (may only be 'NotUsed' if Install-PrivateKey did not return 'NotUsed')
        AssetName : (optional) the base name used to reference the certificate as it was installed on the device;
                    if not supplied the auto-generated name is assumed
######################################################################################################################>
function Install-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

    $UserName = $General.UserName
    $Password = $General.UserPass
    $CertificateName = $General.VarText1
    $ADOM = $General.VarText2

    $enc = [System.Text.Encoding]::UTF8
    [byte[]]$data = $enc.GetBytes($Specific.CertPem)
    [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate = `
        [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($data)
    $TimeSuffix = Get-Date $Certificate.NotBefore -Format FileDateTimeUniversal

    $APIBaseURL = "https://$($General.HostAddress)/api/v2.0"
    $AuthToken = Create-FortiWeb-Auth-JSON -User $UserName -Pass $Password -ADOM $ADOM

    # Check that we haven't already uploaded this certificate, and skip if we have
    $DownloadURI = "$($APIBaseURL)/system/certificate.local.download_json?name=$($CertificateName)-$($TimeSuffix)"
    $Output = Invoke-RestMethod -Uri $DownloadURI -Headers @{ Authorization = $AuthToken }
    if ($Output.cer) {
        Write-VenafiDebug  "Certificate has already been installed"
        # Returning Success here, rather than AlreadyInstalled, ensures that TPP updates the CertificateName in the certificate settings
        return @{ Result = "Success"; AssetName = "$($CertificateName)-$($TimeSuffix)" }
    }

    # Multipart MIME separator
    $Boundary = "------------------------" + ( -join ((48..57) + (97..102) | Get-Random -Count 16 | ForEach-Object { [char]$_ }))

    # Later versions of PowerShell have support for multipart submissions, but I can't
    # guarantee that said support is available, so I construct the the submission manually.
    # FortiWeb is rather fussy about the content of the submission -- the multipart
    # envelope lines MUST be terminated with CRLF and not just LF, as must the lines
    # containing the password and "certificate type" (which is always just "certificate").
    # Furthermore, the key and certificate parts MUST have a filename associated with them.
    # FortiWeb doesn't care about the key filename, but it takes the certificate filename
    # and removes the .pem extension to obtain the certificate "ID".

    # Note that the boundary lines consist of two dashes followed by the boundary separator,
    # with the final boundary line having two dashes right at the end.

    # Private key data
    $Content = "--$($Boundary)`r`n"
    $Content += "Content-Disposition: form-data; name=""keyFile""; filename=""key.pem""`r`n"
    $Content += "Content-Type: application/octet-stream`r`n"
    $Content += "`r`n"
    $Content += $Specific.PrivKeyPemEncrypted.Replace("`r", "")
    $Content += "`r`n"

    # Certificate data
    $Content += "--$($Boundary)`r`n"
    $Content += "Content-Disposition: form-data; name=""certificateFile""; filename=""$($CertificateName)-$($TimeSuffix).pem""`r`n"
    $Content += "Content-Type: application/octet-stream`r`n"
    $Content += "`r`n"
    $Content += $Specific.CertPem.Replace("`r", "")
    $Content += "`r`n"

    # Private key encryption password
    $Content += "--$($Boundary)`r`n"
    $Content += "Content-Disposition: form-data; name=""password""`r`n"
    $Content += "`r`n"
    $Content += $Specific.EncryptPass
    $Content += "`r`n"

    # Certificate type -- "certificate" means PEM private key and certificate
    $Content += "--$($Boundary)`r`n"
    $Content += "Content-Disposition: form-data; name=""type""`r`n"
    $Content += "`r`n"
    $Content += "certificate"
    $Content += "`r`n"

    $Content += "--$($Boundary)--`r`n"

    try {
        $UploadURI = "$($APIBaseURL)/system/certificate.local.import_certificate"
        $Output = Invoke-RestMethod -Uri $UploadURI -Method POST `
            -Headers @{
            Authorization  = $AuthToken;
            "Content-Type" = "multipart/form-data; boundary=$($Boundary)"
        } -Body $Content
        $ImportedCertificateName = $Output._id
        $ImportedCertificateName | Write-VenafiDebug -Intro "Stored key and certificate with id:"
    }
    catch {
        Write-VenafiDebug  "Caught Exception: $PSItem`n$($PSItem.InvocationInfo | ConvertTo-Json)"
        throw $PSItem
    }

    return @{ Result = "Success"; AssetName = $ImportedCertificateName }
}


<######################################################################################################################
.NAME
    Update-Binding
.DESCRIPTION
    Binds the installed certificate with the consuming application or service on the hosting platform
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
######################################################################################################################>
function Update-Binding {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

    $UserName = $General.UserName
    $Password = $General.UserPass
    $AssetName = $General.AssetName
    $CertificateName = $General.VarText1
    $ADOM = $General.VarText2
    $UpdatePolicies = $General.VarBool1

    $APIBaseURL = "https://$($General.HostAddress)/api/v2.0"
    $AuthToken = Create-FortiWeb-Auth-JSON -User $UserName -Pass $Password -ADOM $ADOM

    if ($UpdatePolicies) {
        
        # Enumerate server policies and update any that refer to this certificate
        $ServerPolicyDiscoverURI = "$($APIBaseURL)/cmdb/server-policy/policy"
        $Output = Invoke-RestMethod -Uri $ServerPolicyDiscoverURI -Headers @{ Authorization = $AuthToken }
        foreach ($ServerPolicy in $Output.results) {
            $PolicyName = $ServerPolicy.name
            $PolicyCertName = $ServerPolicy.certificate

            if ($PolicyCertName -eq "") {
                continue;
            }

            if (($PolicyCertName -eq $CertificateName) -or
                (($PolicyCertName -match '^(.+)-([0-9]{4}[0-9]{2}[0-9]{2}T[0-9]{2}[0-9]{2}[0-9]{2}[0-9]{4}Z)$') -and ($Matches.1 -eq $CertificateName))) {
                Write-VenafiDebug  "Server Policy $PolicyName references certificate $CertificateName (current cert is $PolicyCertName)"

                $UpdateData = @{ data = @{ certificate = $AssetName } } | ConvertTo-Json -Compress
                $UpdateURI = "$($APIBaseURL)/cmdb/server-policy/policy?mkey=$($PolicyName)"


                try {
                    $Output = Invoke-RestMethod -Uri $UpdateURI -Headers @{ Authorization = $AuthToken } -Method Put -ContentType "application/json" -Body $UpdateData
                }
                catch {
                    Write-VenafiDebug  "Caught Exception: $PSItem`n$($PSItem.InvocationInfo | ConvertTo-Json)"
                    throw $PSItem
                }
            }
        }

        # Enumerate SNI policies and update as required
        $SNIPolicyDiscoverURI = "$($APIBaseURL)/cmdb/system/certificate.sni"
        $SNIPolicyEntriesRetrieveURI = "$($APIBaseURL)/cmdb/system/certificate.sni/members"
        $Output = Invoke-RestMethod -Uri $SNIPolicyDiscoverURI -Headers @{ Authorization = $AuthToken }

        foreach ($SNIPolicy in $Output.results) {
            $PolicyName = $SNIPolicy.name
            $PolicyEntries = Invoke-RestMethod -Uri $SNIPolicyEntriesRetrieveURI -Headers @{ Authorization = $AuthToken } -Body @{ "mkey" = $PolicyName }

            foreach ($PolicyEntry in $PolicyEntries.results) {
                $PolicyCertName = $PolicyEntry."local-cert"
                if ($PolicyCertName -eq "") {
                    continue;
                }

                if (($PolicyCertName -eq $CertificateName) -or
                    (($PolicyCertName -match '^(.+)-([0-9]{4}[0-9]{2}[0-9]{2}T[0-9]{2}[0-9]{2}[0-9]{2}[0-9]{4}Z)$') -and ($Matches.1 -eq $CertificateName))) {
                    $EntryID = $PolicyEntry._id
                    Write-VenafiDebug  "SNI Policy Entry $PolicyName.$EntryID references certificate $CertificateName (current cert is $PolicyCertName)"

                    $UpdateData = @{ data = @{ "local-cert" = $AssetName } } | ConvertTo-Json -Compress
                    $UpdateURI = "$($APIBaseURL)/cmdb/system/certificate.sni/members?mkey=$($PolicyName)&sub_mkey=$EntryID"

                    try {
                        $Output = Invoke-RestMethod -Uri $UpdateURI -Headers @{ Authorization = $AuthToken } -Method Put -ContentType "application/json" -Body $UpdateData
                    }
                    catch {
                        Write-VenafiDebug  "Caught Exception: $PSItem`n$($PSItem.InvocationInfo | ConvertTo-Json)"
                        throw $PSItem
                    }
                }
            }
        }
    }

    return @{ Result = "Success" }
}


<######################################################################################################################
.NAME
    Activate-Certificate
.DESCRIPTION
    Performs any post-installation operations necessary to make the certificate active (such as restarting a service)
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
######################################################################################################################>
function Activate-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    return @{ Result = "Success" }
}


<######################################################################################################################
.NAME
    Extract-Certificate
.DESCRIPTION
    Extracts the active certificate from the hosting platform.  If the platform does not provide a method for exporting the
    raw certificate then it is sufficient to return only the Serial and Thumprint.  This function is REQUIRED.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
        CertPem : the extracted X509 certificate referenced by AssetName in Base64 PEM format
        Serial : the serial number of the X509 certificate refernced by AssetName
        Thumbprint : the SHA1 thumprint of the X509 certificate referenced by AssetName
######################################################################################################################>
function Extract-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

    $UserName = $General.UserName
    $Password = $General.UserPass
    $AssetName = $General.AssetName
    $CertificateName = $General.VarText1
    $ADOM = $General.VarText2

    Write-VenafiDebug  "Extracting certificate with name $CertificateName -- asset name $AssetName"

    $APIBaseURL = "https://$($General.HostAddress)/api/v2.0"
    $AuthToken = Create-FortiWeb-Auth-JSON -User $UserName -Pass $Password -ADOM $ADOM

    $DownloadURI = "$($APIBaseURL)/system/certificate.local.download_json?name=$($AssetName)"
    $Output = Invoke-RestMethod -Uri $DownloadURI -Headers @{ Authorization = $AuthToken }
    if ($Output.cer) {
        $CertificatePEM = $Output.cer

        $enc = [System.Text.Encoding]::UTF8
        [byte[]]$data = $enc.GetBytes($CertificatePem)
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate = `
            [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($data)

        if ($Certificate) {
            $CertificateSerial = $Certificate.SerialNumber
            $CertificateThumbprint = $Certificate.Thumbprint

            $CertificateSerial | Write-VenafiDebug -Intro "Certificate Serial:"
            $CertificateThumbprint | Write-VenafiDebug -Intro "Certificate Thumbprint:"
            Write-VenafiDebug  "--------"

            return @{
                Result     = "Success";
                CertPem    = $CertificatePEM;
                Serial     = $CertificateSerial;
                Thumbprint = $CertificateThumbprint
            }
        }
        else {
            Write-VenafiDebug  "Unable to decode certificate"
            Write-VenafiDebug  "--------"
        }
    }
    else {
        Write-VenafiDebug  "Unable to retrieve certificate"
        Write-VenafiDebug  "--------"
    }

    return @{ Result = "NotUsed" }
}


<######################################################################################################################
.NAME
    Extract-PrivateKey
.DESCRIPTION
    Extracts the private key associated with the certificate from the hosting platform
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        EncryptPass : the string password to use when encrypting the private key
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
        PrivKeyPem : the extracted private key in RSA Base64 PEM format (encrypted or not)
######################################################################################################################>
function Extract-PrivateKey {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    return @{ Result = "NotUsed" }
}


<######################################################################################################################
.NAME
    Remove-Certificate
.DESCRIPTION
    Removes an existing certificate (or private key) from the device.  Only implement the body of
    this function if TPP can/should remove old generations of the same asset.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        AssetNameOld : the name of a asset that was previously replaced and should be deleted
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
######################################################################################################################>
function Remove-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    return @{ Result = "NotUsed" }
}


<######################################################################################################################
.NAME
    Discover-Certificates
.DESCRIPTION
    Discovers certificates and their instance metadata from a target device
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        HostAddress : a string containing the hostname or IP address specified by the device object
        TcpPort : an integer value containing the TCP port specified by the application object
        UserName : a string containing the username portion of the credential assigned to the device or application object
        UserPass : a string containing the password portion of the credential assigned to the device or application object
        UserPrivKey : the non-encrypted PEM of the private key credential assigned to the device or application object
.NOTES
    Returns...
        Result : 'Success' to indicate the non-error completion state
        Applications : an array of hashtables that include the following data for a certificate instance:
            Name - the name of the application object that represents this instance under the device object
            ApplicationClass - the schema class of the application object (defaults to 'Adaptable App')
            DriverName - the value of the Driver Name attribute (defaults to 'appadaptable')
            PEM - the raw X509 certificate in base64 encoded text format
            ValidationAddress - FQDN, hostname, or IP address where the server is presenting the certificate
            ValidationPort - TCP port on which the server is presending the certificate (integer between 1-65535, defaults to 443)
            Attributes - a hashtable that specifies zero or more Config attribute-value pairs to set on the application object
######################################################################################################################>
function Discover-Certificates {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = 'General Parameters')]
        [System.Collections.Hashtable]$General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

    $UserName = $General.UserName
    $Password = $General.UserPass
    $APIBaseURL = "https://$($General.HostAddress)/api/v2.0"
    $AuthToken = Create-FortiWeb-Auth-JSON -User $UserName -Pass $Password

    try {
        $ADOMDiscoverURI = "$($APIBaseURL)/system/status.adoms"
        Write-VenafiDebug  "Enumerating ADOMs"
        $Output = Invoke-RestMethod -Uri $ADOMDiscoverURI -Headers @{ Authorization = $AuthToken }

        $CertificateObjects = @()
        foreach ($Entry in $Output.results) {
            $ADOM = $Entry.name
            $AuthToken = Create-FortiWeb-Auth-JSON -User $UserName -Pass $Password -ADOM $ADOM

            $StoreADOM = $ADOM
            if ($ADOM -eq "root") {
                $StoreADOM = ""
            }

            $CertDiscoverURI = "$($APIBaseURL)/system/certificate.local"
            Write-VenafiDebug  "Enumerating certificates in ""$ADOM"" adom"
            $Output = Invoke-RestMethod -Uri $CertDiscoverURI -Headers @{ Authorization = $AuthToken }

            # Build up a hash of certificate name -> certificate PEM data
            $CertificatePEMs = @{}
            foreach ($Certificate in $Output.results) {
                $Name = $Certificate.name
                $Name | Write-VenafiDebug -Intro "Downloading certificate with name:"
                $DownloadURI = "$($APIBaseURL)/system/certificate.local.download_json?name=$($Name)"
                $Output = Invoke-RestMethod -Uri $DownloadURI -Headers @{ Authorization = $AuthToken }
                $CertificatePEMs.$Name = $Output.cer
            }
            Write-VenafiDebug  "--------"

            # Build up a hash of certificate base name -> latest certificate for names that
            # have suffixes, and a set (as a hash of name -> 1) of non-suffixed names
            $SuffixedNames = @{}
            $NonSuffixedNames = @{}
            foreach ($CertificateName in $CertificatePEMs.Keys) {
                if ($CertificateName -match '^(.+)-([0-9]{4}[0-9]{2}[0-9]{2}T[0-9]{2}[0-9]{2}[0-9]{2}[0-9]{4}Z)$') {
                    $BaseName = $Matches.1
                    $Suffix = $Matches.2
                    if ((-not $SuffixedNames.$BaseName) -or ($SuffixedNames.$BaseName -lt $Suffix)) {
                        $SuffixedNames.$BaseName = $Suffix
                    }
                }
                else {
                    $NonSuffixedNames.$CertificateName = 1
                }
            }
            Write-VenafiDebug  ("Latest versions of suffixed certificates:`n" + ($SuffixedNames | ConvertTo-Json))
            Write-VenafiDebug  ("Non-suffixed certificates:`n" + ($NonSuffixedNames.Keys | ConvertTo-Json))
            Write-VenafiDebug  "--------"

            # Add the names for the latest versions of suffixed certificates to the set. This gives us
            # a list of the certificates that we need to import. Any certificate whose name isn't in
            # this list shouldn't be imported, because it has been superceded.
            ForEach ($SuffixedName in $SuffixedNames.Keys) {
                $NonSuffixedNames.($SuffixedName + "-" + $SuffixedNames.$SuffixedName) = 1
            }

            $ServerPolicyDiscoverURI = "$($APIBaseURL)/cmdb/server-policy/policy"
            Write-VenafiDebug  "Enumerating server policies"
            $Output = Invoke-RestMethod -Uri $ServerPolicyDiscoverURI -Headers @{ Authorization = $AuthToken }

            # Build up a hash of certificate name -> array of referencing policies
            $ReferencingServerPolicies = @{}
            foreach ($ServerPolicy in $Output.results) {
                $PolicyName = $ServerPolicy.name
                $CertificateName = $ServerPolicy.certificate

                if ($CertificateName -ne "") {
                    Write-VenafiDebug  "Server Policy $PolicyName references certificate $CertificateName"

                    if ($NonSuffixedNames.$CertificateName) {
                        if (-not $ReferencingServerPolicies.$CertificateName) {
                            $ReferencingServerPolicies.$CertificateName = @()
                        }
                        $ReferencingServerPolicies.$CertificateName += $PolicyName
                    }
                    else {
                        Write-VenafiDebug  ("Certificate $CertificateName has been superceded")
                    }
                }
            }

            Write-VenafiDebug  ("Referencing Policies:`n" + ($ReferencingServerPolicies | ConvertTo-Json))
            Write-VenafiDebug  "--------"

            $SNIPolicyDiscoverURI = "$($APIBaseURL)/cmdb/system/certificate.sni"
            $SNIPolicyEntriesRetrieveURI = "$($APIBaseURL)/cmdb/system/certificate.sni/members"
            Write-VenafiDebug  "Enumerating SNI policies"
            $Output = Invoke-RestMethod -Uri $SNIPolicyDiscoverURI -Headers @{ Authorization = $AuthToken }

            # Build up a hash of certificate name -> array of referencing SNI policies
            $ReferencingSNIPolicies = @{}
            foreach ($SNIPolicy in $Output.results) {
                $PolicyName = $SNIPolicy.name

                $PolicyName | Write-VenafiDebug -Intro "Retrieving SNI policy entries for"
                $PolicyEntries = Invoke-RestMethod -Uri $SNIPolicyEntriesRetrieveURI -Headers @{ Authorization = $AuthToken } -Body @{ "mkey" = $PolicyName }

                foreach ($PolicyEntry in $PolicyEntries.results) {
                    $CertificateName = $PolicyEntry."local-cert"
                    if ($CertificateName -ne "") {
                        Write-VenafiDebug  "Entry $($PolicyEntry._id) refers to certificate $CertificateName"

                        if ($NonSuffixedNames.$CertificateName) {
                            if (-not $ReferencingSNIPolicies.$CertificateName) {
                                $ReferencingSNIPolicies.$CertificateName = @()
                            }
                            $ReferencingSNIPolicies.$CertificateName += $PolicyName
                        }
                        else {
                            Write-VenafiDebug  "Certificate $CertificateName has been superceded"
                        }
                    }
                }
            }

            Write-VenafiDebug  "Building list of certificate objects"

            foreach ($CertificateName in $NonSuffixedNames.Keys) {
                if ($CertificateName -match '^(.+)-([0-9]{4}[0-9]{2}[0-9]{2}T[0-9]{2}[0-9]{2}[0-9]{2}[0-9]{4}Z)$') {
                    $BaseName = $Matches.1
                }
                else {
                    $BaseName = $CertificateName
                }

                # If there are policies referencing the certificate name, then set the flag to update
                # policies when provisioning a new certificate.
                if ($ReferencingServerPolicies.$CertificateName -or $ReferencingSNIPolicies.$CertificateName) {
                    $UpdatePolicies = $true
                }
                else {
                    $UpdatePolicies = $false
                }

                Write-VenafiDebug  "Creating certificate object for $BaseName ($Suffix)"
                $CertificateEntry = @{
                    Name       = $BaseName
                    PEM        = $CertificatePEMs.$CertificateName
                    Attributes = @{
                        "Text Field 1" = $BaseName
                        "Option 1"     = $UpdatePolicies
                        "Text Field 2" = $StoreADOM
                    }
                }
                $CertificateObjects += $CertificateEntry
            }
        }

        ($CertificateObjects | ConvertTo-Json) | Write-VenafiDebug -Intro "Discovered Certificate Objects:"
        return @{ Result = "Success"; Applications = $CertificateObjects }

    }
    catch {
        Write-VenafiDebug  "Caught Exception: $PSItem`n$($PSItem.InvocationInfo | ConvertTo-Json)"
        throw $PSItem
    }
}

function Create-FortiWeb-Auth-JSON {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = 'User')]
        [string]$User,
        [Parameter(Mandatory = $true, HelpMessage = 'Pass')]
        [string]$Pass,
        [Parameter(Mandatory = $false, HelpMessage = 'ADOM')]
        [string]$ADOM
    )
    Write-FunctionDetail $PSCmdlet.MyInvocation
    if (-not $ADOM) {
        $ADOM = "root"
    }
    $AuthJSON = @{
        username = $User
        password = $Pass
        vdom     = $ADOM
    }
    $AuthJSON = $AuthJSON | ConvertTo-Json -Compress
    $AuthToken = [Convert]::ToBase64String(([System.Text.Encoding]::UTF8.GetBytes($AuthJSON)))

    return $AuthToken
}

function Get-FortiWebVersion {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = 'Host Address')]
        [string]$HostAddress,
        [Parameter(Mandatory = $true, HelpMessage = 'Auth Token')]
        [string]$AuthToken
    )

    try {
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        # Query the endpoint for version information (for logging purposes only)
        $uri = "https://$HostAddress/api/v2.0/system/status.systemstatus"
        $response = Invoke-RestMethod -Uri $uri -Headers @{ Authorization = $AuthToken } -ErrorAction Stop
        
        # Log firmware version
        if ($response.results -and $response.results.firmwareVersion) {
            $firmwareVersion = $response.results.firmwareVersion
            $firmwareVersion | Write-VenafiDebug -Intro "FortiWeb Firmware Version:"
        }
    }
    catch {
        $_ | Write-VenafiDebug -Intro 'Unable to query firmware version:'
    }
}

function Install-ChainCert {
    Param(
        [Parameter(Mandatory = $true)]
        [hashtable]$HostDetails,
        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,
        [Parameter(Mandatory = $true)]
        [string]$Type
    )

    try {
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        $options = @{}
        switch ($Type) {
            'ca' {
                $options.FileName = $($($($($Certificate.Subject -split (","))[0] -split ("="))[1]) -replace ("\s", "_"))
                $options.Name = "srcFile"
                $options.UriLeaf = "ca"
            }
            'intermediateca' {
                $options.FileName = $($($($Certificate.Subject -split (","))[0] -split ("="))[1]) -replace ("\s", "_")
                $options.Name = "uploadedFile"
                $options.UriLeaf = "intermediateca"
            }
        }

        # Convert the x509Certificate2 object to PEM format
        $base64 = [Convert]::ToBase64String($Certificate.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert))
        $formatted = $base64 -replace '.{64}', "`$&`n"
        [System.Text.StringBuilder]$sb = ""
        [void]$sb.AppendLine("-----BEGIN CERTIFICATE-----")
        [void]$sb.AppendLine($formatted)
        [void]$sb.AppendLine("-----END CERTIFICATE-----")

        $Boundary = "------------------------" + ( -join ((48..57) + (97..102) | Get-Random -Count 16 | ForEach-Object { [char]$_ }))

        $Content = "--$($Boundary)`r`n"
        $Content += "Content-Disposition: form-data; name=""type"";`r`n"
        $Content += "`r`n"
        $Content += "localPC"
        $Content += "`r`n"

        $Content += "--$($Boundary)`r`n"
        $Content += "Content-Disposition: form-data; name=""$($options.Name)""; filename=""$($options.FileName).crt""`r`n"
        $Content += "Content-Type: application/octet-stream`r`n"
        $Content += "`r`n"
        $Content += $sb.ToString()
        $Content += "`r`n"

        $Content += "--$($Boundary)--`r`n"

        $UploadURI = "https://$($HostDetails.HostAddress)/api/v2.0/system/certificate.$($options.UriLeaf)"
        $contentHeader = $HostDetails.Headers.Clone()
        $contentHeader.Add("Content-Type", "multipart/form-data; boundary=$($Boundary)")
        $response = Invoke-RestMethod -Uri $UploadURI -Method POST -Headers $contentHeader -Body $Content
        Remove-Variable -Name "contentHeader"
        if ($response.errcode) { throw "Unable to upload $($Type.ToUpper()) certificate to Fortiweb device." }
    }
    catch {
        throw "Failed to upload the certificate. $_"
    }
}

function ProvisionCerts {
    Param(
        [Parameter(Mandatory = $true)]
        [hashtable] $Certificates,
        [Parameter(Mandatory = $true)]
        [ValidateSet("ca", "intermediateca", IgnoreCase = $false)]
        [string]$Type,
        [Parameter(Mandatory = $true)]
        [string] $Group,
        [Parameter(Mandatory = $true)]
        [hashtable] $HostDetails
    )

    try {
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        $fwCertName = ""

        # Get current certificate Objects from FortiWeb
        $getCertsUrl = "https://$($HostDetails.HostAddress)/api/v2.0/system/certificate.$($Type)"
        $certs = Invoke-RestMethod -Uri $getCertsUrl -Method GET -Headers $HostDetails.Headers
        if (($certs.errcode) -or ($Type -eq "ca" -and $certs.status -ne 1)) {
            throw "Encountered issue while attempting to retrieve certificates from FortiWeb device."
        }

        $certSerials = if ($certs.results.Count -gt 0) {
            @(
                $certs | ForEach-Object { $_.results.serialNumber.Trim() }
            )
        }
        else {
            $null
        }

        # Compare new certificate with current
        $formattedCertSerial = ""

        $certHash = if ($Type -eq "ca") {
            $Certificates.cas
        }
        else {
            $Certificates.intermediates
        }

         $certHash | Write-VenafiDebug -Intro 'certhash:'
        
         foreach ($object in $certHash) {
            $formattedCertSerial = $object.SerialNumber.ToString().ToLower().Trim() -replace '..(?!$)', '$0:'
            if (($certSerials.Count -eq 0) -or !$certSerials.Contains($formattedCertSerial)) {
                # Certificate does not exist, so we add it
                Install-ChainCert -HostDetails $HostDetails -Certificate $object -Type $Type
                Start-Sleep(2)
            }
            else {
                "The certificate [Serial Number: $($object.SerialNumber.ToString().Trim())] already exists within the FortiWeb device. Skipping import." | Write-VenafiDebug 
            }
        }

        # Now we check to see if the certificate group exists
        $groupSuffix = if ($Type -eq "ca") {
            "ca-group"
        }
        else {
            "intermediate-certificate-group"
        }

        $certGroupUrl = "https://$($HostDetails.HostAddress)/api/v2.0/cmdb/system/certificate.$($groupSuffix)"
        "=== Checking for certificate group existence ===" | Write-VenafiDebug
        $groupSuffix | Write-VenafiDebug -Intro "Group suffix:"
        $Group | Write-VenafiDebug -Intro "Group name:"
        $certGroupUrl | Write-VenafiDebug -Intro "API GET Request:"
        $certGroups = Invoke-RestMethod -Uri $certGroupUrl -Method GET -Header $HostDetails.Headers
        $certGroups | Write-VenafiDebug -Intro 'API GET Response:'
        if ($certGroups.errcode) {
            throw "Unable to retreive certificate groups from the FortiWeb device."
        }
        $certGroupNames = if ($certGroups.results.Count -gt 0) {
            @(
                $certGroups | ForEach-Object { $_.results.name.Trim() }
            )
        }
        else {
            $null
        }
        $certGroupNames | Write-VenafiDebug -Intro 'Existing certificate group names:'
        "Does group '$Group' exist? $($certGroupNames -contains $Group)" | Write-VenafiDebug

        # If not, we create the certificate group
        if (($certGroupNames.Count -eq 0) -or !$certGroupNames.Contains($Group)) {
            "=== Creating new certificate group ===" | Write-VenafiDebug
            $Group | Write-VenafiDebug -Intro "Group name to create:"
            $certGroupJson = @{
                data = @{
                    name = $Group
                }
            } | ConvertTo-Json -Compress
            $certGroupUrl | Write-VenafiDebug -Intro "API POST Request:"
            $certGroupJson | Write-VenafiDebug -Intro 'Request Body:'
            $addCertGroupResponse = Invoke-RestMethod -Uri $certGroupUrl -Method POST -Headers $HostDetails.Headers -Body $certGroupJson
            $addCertGroupResponse | Write-VenafiDebug -Intro 'API POST Response:'
            if ($addCertGroupResponse.errcode) { throw "Unable to create [$($Group)] certificate group on the FortiWeb device." }

            # Get updated list of certificates and parse for name
            "=== Finding certificate name by serial ===" | Write-VenafiDebug
            $formattedCertSerial | Write-VenafiDebug -Intro "Looking for serial:"
             $getCertsUrl | Write-VenafiDebug -Intro "API GET Request:"
            $updatedCerts = Invoke-RestMethod -Uri $getCertsUrl -Method GET -Headers $HostDetails.Headers
            if (($updatedCerts.errcode) -or ($Type -eq "ca" -and $updatedCerts.status -ne 1)) { throw "Encountered issue while attempting to retrieve certificates from FortiWeb device." }
            foreach ($remoteCert in $updatedCerts.results) {
                if ( $formattedCertSerial -in $remoteCert.serialNumber.Trim(), ('00:{0}' -f $remoteCert.serialNumber.Trim())) {
                    $fwCertName = $remoteCert.name
                    $fwCertName | Write-VenafiDebug -Intro "Found matching certificate:" 
                    break
                }
            }

            # Add certificate to the new group
            "=== Adding certificate to new group ===" | Write-VenafiDebug
            $fwCertName | Write-VenafiDebug -Intro "Certificate name:"
            $Group | Write-VenafiDebug -Intro "Group name:"
            $addCertAsMemberJson = @{
                data = @{
                    type         = $Type.ToUpper()
                    "publish-dn" = "enable"
                    name         = $fwCertName
                }
            } | ConvertTo-Json -Compress
            
            # Add certificate to group members
            $addCertAsMemberUrl = $certGroupUrl + "/members?mkey=$($Group)"      
            $addCertAsMemberUrl | Write-VenafiDebug -Intro "API POST Request:"
           
            $addCertAsMemberResponse = Invoke-RestMethod -Uri $addCertAsMemberUrl -Method POST -Header $HostDetails.Headers -Body $addCertAsMemberJson
            $addCertAsMemberResponse | Write-VenafiDebug -Intro 'API POST Response:'
            if ($addCertAsMemberResponse.errcode) { throw "Failed to add [$($fwCertName)] certificate to [$($Group)] group on FortiWeb device." }

        }
        else {
            "=== Group already exists, checking membership ===" | Write-VenafiDebug
            # The group does exist, but we need to check if the certificate is a member
            # First we get the certificate details to compare against (fetch fresh in case cert was just uploaded)
            $formattedCertSerial | Write-VenafiDebug -Intro "Looking for certificate with serial:"
            $getCertsUrl | Write-VenafiDebug -Intro "API GET Request:"
            $currentCerts = Invoke-RestMethod -Uri $getCertsUrl -Method GET -Headers $HostDetails.Headers
            if (($currentCerts.errcode) -or ($Type -eq "ca" -and $currentCerts.status -ne 1)) { throw "Encountered issue while attempting to retrieve certificates from FortiWeb device." }

            # Find the certificate name by serial number
            foreach ($remoteCert in $currentCerts.results) {
                if ( $formattedCertSerial -in $remoteCert.serialNumber.Trim(), ('00:{0}' -f $remoteCert.serialNumber.Trim())) {
                    $fwCertName = $remoteCert.name
                    $fwCertName | Write-VenafiDebug -Intro "Found certificate:"
                    break
                }
            }
            
            if ([string]::IsNullOrEmpty($fwCertName)) {
                throw "Failed to find certificate with serial number [$formattedCertSerial] on FortiWeb device after upload."
            }

            # Get group members
            $groupMembersUrl = "$certGroupUrl/members?mkey=$Group"
            
            $groupMembersUrl | Write-VenafiDebug -Intro "API GET Request (group members):"
            $certGroupMembers = Invoke-RestMethod -Uri $groupMembersUrl -Method GET -Headers $HostDetails.Headers
            $certGroupMembers | Write-VenafiDebug -Intro "API Get Response (group members):"
            if ($certGroupMembers.errcode) { throw "Unable to retrieve certificate members from [$($Group)] group on the FortiWeb device." }

            $certGroupMembersQuery = if ($certGroupMembers.results.Length -ne 0) {
                @(
                    $certGroupMembers | ForEach-Object { $_.results.name.Trim() }
                )
            }
            else {
                $null
            }

            $certGroupMembersQuery | Write-VenafiDebug -Intro "Current group members:"
            "Is certificate '$fwCertName' already a member? $($certGroupMembersQuery -contains $fwCertName)" | Write-VenafiDebug
            
            if (($certGroupMembersQuery.Count -eq 0) -or !$certGroupMembersQuery.Contains($fwCertName)) {
                # If certificate is not a member, we add it
                "=== Adding certificate to existing group ===" | Write-VenafiDebug
                $addCertAsMemberJson = @{
                    data = @{
                        type         = $Type.ToUpper()
                        "publish-dn" = "enable"
                        name         = $fwCertName
                    }
                } | ConvertTo-Json -Compress
                $fwCertName | Write-VenafiDebug -Intro "Certificate:"
                $Group | Write-VenafiDebug -Intro "Group:"
                $groupMembersUrl | Write-VenafiDebug -Intro "API POST Request:"
                $addCertAsMemberJson | Write-VenafiDebug -Intro "Request Body:"
                $addCertAsMemberResponseParams = @{
                    Uri         = $groupMembersUrl
                    Method      = 'POST'
                    Headers     = $HostDetails.Headers
                    Body        = $addCertAsMemberJson
                }
                $addCertAsMemberResponse = Invoke-RestMethod @addCertAsMemberResponseParams
                $appCertAsMemberResponse  | Write-VenafiDebug -Intro 'API POST Response:'
                
                if ($addCertAsMemberResponse.errcode) { throw "Failed to add [$($fwCertName)] certificate to [$($Group)] group on FortiWeb device." }
            }
            else {
                "The certificate [Serial Number: $($object.serialNumber.ToString().Trim())] is already a member of the [$($Group)]. Skipping ""add to group"" operation." | Write-VenafiDebug 
            }
        }
    }
    catch {
        $_ | write-venafidebug -throwexception
    }
}

Function Write-FunctionDetail {

    <#
    .SYNOPSIS
        Log function details
    .DESCRIPTION
        Log function details including the function name and any bound parameters
    .PARAMETER InvocationInfo
        Invocation detail from a function, typically sent via $PSCmdlet.MyInvocation
    .PARAMETER NoBoundParams
        By default, function parameters and values will be written.  Don't do this.
    .PARAMETER ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
    .NOTES
        Must be an advanced function otherwise $PSCmdlet.MyInvocation will not be available.
        Set $script:scriptVersion to include the script version in the log.
        Set $script:scriptName to validate signing.  Value should be similar to 'AdaptableCA\MyDriver', after Scripts dir and no .ps1.
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation
        Put this at the start of every function
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -NoBoundParams
        Do not output the bound parameters
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
        Helpful for the first log entry in a script to help with troubleshooting.
    #>

    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Management.Automation.InvocationInfo] $InvocationInfo,

        [Parameter()]
        [switch] $NoBoundParams,

        [Parameter()]
        [Alias('ValidateScript')]
        [switch] $ExtraInfo
    )

    $header = 'Function: {0}' -f $InvocationInfo.InvocationName
    $header += if ($script:scriptVersion) { ', script version: {0}' -f $script:scriptVersion } else { '' }

    if ( $ExtraInfo ) {

        # registry only available on CMSH
        # if reusing this script with CMSaaS, this section will be skipped
        if ( $PSVersionTable.PSEdition -ne 'Core' ) {
            $installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

            if ( $script:scriptName ) {
                try {
                    $sig = Get-AuthenticodeSignature -FilePath ('{0}Scripts\{1}.ps1' -f $installPath, $script:scriptName)
                    $sigStatus = if ( $sig.Status -eq 'Valid' ) { 'Valid' } else { 'Not Valid' }
                }
                catch {
                    $sigStatus = $_.ToString()
                }
            }
            else {
                $sigStatus = 'script name not set'
            }

            $header += ", signature: $sigStatus"

            # add CMSH version if available
            try {
                $f = Join-Path -Path $installPath -ChildPath 'Platform\Venafi.InstallKit.dll'
                $header += ', CMSH version: {0}' -f (Get-Item $f).VersionInfo.FileVersion
            }
            catch {
                # just for logging, don't fail
            }
        }

        # add powershell version
        $header += ', PowerShell version: {0}' -f $PSVersionTable.PSVersion.ToString()

    }

    $header | Write-VenafiDebug

    if ( $null -ne $InvocationInfo.BoundParameters -and -not $NoBoundParams ) {
        [hashtable]$InvocationInfo.BoundParameters | Write-VenafiDebug
    }
}

function Write-VenafiDebug {

    <#
    .SYNOPSIS
    Write info to the adaptable debug log

    .DESCRIPTION
    Assuming the option has been selected, write info to the adaptable debug log.
    Hashtables are supported and secret info will not be logged, eg. $General.

    .PARAMETER Message
    The info to be logged

    .PARAMETER ThrowException
    After logging the message, throw an exception to terminate the script

    .EXAMPLE
    Write-VenafiDebug -Message 'connected to server'

    Write info to the log

    .EXAMPLE
    $General | Write-VenafiDebug

    Write input parameter values to the log

    .EXAMPLE
    Write-VenafiDebug -Message 'this was not good' -ThrowException

    Write to the log and throw an exception
    #>

    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [psobject] $Message,

        [Parameter()]
        [string] $Intro,

        [Parameter()]
        [switch] $ThrowException
    )

    process {

        if ( -not $global:DEBUG_FILE ) {
            return
        }

        $newMessage = switch ($Message.GetType().FullName) {
            'System.Collections.Hashtable' {
                Set-SecretsToHidden $Message | ConvertTo-Json -Depth 5
            }

            'System.String' {
                $Message
            }

            'System.Management.Automation.ErrorRecord' {
                # powershell specific exception
                $err = $Message
                $ex = $err.Exception
                $inv = $err.InvocationInfo
                $logEntry = @{
                    Message          = $ex.Message
                    ErrorId          = $err.FullyQualifiedErrorId
                    Category         = $err.CategoryInfo.Category
                    TargetObject     = $err.TargetObject
                    ScriptName       = $inv.ScriptName
                    LineNumber       = $inv.ScriptLineNumber
                    Line             = $inv.Line
                    Position         = $inv.PositionMessage
                    StackTrace       = $ex.StackTrace
                    ScriptStackTrace = $err.ScriptStackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }
                $logEntry | ConvertTo-Json -Depth 3
            }

            'System.Exception' {
                #.net generic exception
                $ex = $Message
                $inv = $ex.InvocationInfo
                $logEntry = @{
                    Message       = $ex.Message
                    ExceptionType = $ex.GetType().FullName
                    ScriptName    = $inv.ScriptName
                    LineNumber    = $inv.ScriptLineNumber
                    Line          = $inv.Line
                    Position      = $inv.PositionMessage
                    StackTrace    = $ex.StackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }

                $logEntry | ConvertTo-Json -Depth 3
            }

            default {
                $Message | ConvertTo-Json -Depth 3
            }
        }

        if ( $Intro ) {
            $newMessage = "$Intro`r`n$newMessage"
        }

        try {
            # use a mutex to ensure multiple executions of this script don't cause 'file in use' errors
            $mutex = New-Object System.Threading.Mutex($false, [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.ScriptName))
            if ( -not $mutex.WaitOne(0) ) {
                $mutex.WaitOne()
            }
            ('{0} : {1}' -f (Get-Date), ($newMessage | Out-String)) | Out-File -FilePath $global:DEBUG_FILE -Encoding 'UTF8' -Append
        }
        catch {
            throw $_
        }
        finally {
            $null = $mutex.ReleaseMutex()
        }
    }

    end {
        if ( $ThrowException ) {
            # since we're in the end block this is only intended for a string, not array or anything that needs the pipeline
            throw $Message
        }
    }
}

function Set-SecretsToHidden {

    <#
    .SYNOPSIS
        Blank out sensitive information
    .DESCRIPTION
        Blank out sensitive information in a message, typically in a hashtable.
        Meant for adaptable framework scripts.
        Will automatically clone hashtable to ensure original object isn't affected.
    #>


    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        $InputObject
    )

    process {

        $secrets = @('UserPass', 'AuxPass', 'PfxPass', 'Certificate', 'PfxData', 'Password', 'AuxPfxData', 'PrivKeyPem', 'Pkcs12', 'EncryptPass', 'ChainPkcs7', 'PrivKeyPemEncrypted', 'VarPass', 'Pass', 'AuthToken')

        if ($InputObject -is [hashtable]) {
            $clone = @{}
            foreach ($key in $InputObject.keys) {
                if ( [string]::IsNullOrEmpty($InputObject[$key]) ) {
                    $clone[$key] = ''
                }
                else {
                    if ($key -in $secrets ) {
                        $clone[$key] = '***hidden***'
                    }
                    else {
                        $clone[$key] = Set-SecretsToHidden $InputObject[$key]
                    }
                }
            }
            return $clone
        }
        else {
            return $InputObject
        }
    }
}
# SIG # Begin signature block
# MIIh2AYJKoZIhvcNAQcCoIIhyTCCIcUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDb91usMo9Dk24O
# iPe1aj0U0kR+3R74psIVYEXR0WQSFaCCGtEwggeTMIIFe6ADAgECAhABUX9+ZWir
# r6OpYdH+HnHPMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBD
# b2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjUwOTExMDAw
# MDAwWhcNMjYwOTEwMjM1OTU5WjCBmjELMAkGA1UEBhMCVVMxFjAUBgNVBAgTDU1h
# c3NhY2h1c2V0dHMxDzANBgNVBAcTBk5FV1RPTjEgMB4GA1UEChMXQ3liZXJBcmsg
# U29mdHdhcmUsIEluYy4xHjAcBgNVBAsTFVByb2Zlc3Npb25hbCBTZXJ2aWNlczEg
# MB4GA1UEAxMXQ3liZXJBcmsgU29mdHdhcmUsIEluYy4wggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC4Rp6KSQ+kelbVZimPMfQQPYfI1sYfkuOCTvooMhol
# oVm6aKLtEzZB7s0VkLLaW3XPfyzmlereIyRsK7h/3kxiXeeNzMu2tycqoSVFxwsn
# j04ptiSZ0TeD+ciM/EHvhapRqN2e1v5VRrpvsTkp9NAwKtf1z09czOeZXo2McpQm
# 66CLXfWWu6WhxV2wtDdn998cyxbGdXAZEdQmszU3YM6G9YB/2sdONTwSWaZqri9p
# oNnbO0hEByaz13PVPwN4FNJEKyY2RT7SJjrh6jPmkZwhvn08vna96tKsrw5XxxwJ
# FsFe7W2Wxgo4hybaVA0tLlOqmp6BufGjoa7GjpdM+g/SRm7xPFcSEJkqYJzoCVWu
# 5VNydUdZttKzzi1JfGuxQAaITelrIvo0K3cHig7NwN7F2/riIvP6tv+8AGiyGuoU
# uIAdnSEIRZLzdbfELdRyf6yffNYbaIi4iCS2UMwzDKzDzL3YPMu66jkx+zkC3iH0
# jXeWJMQn+Zsry0Sqpll+9EFeFBbo+ko28SsWnWfbEpkHZz+OuwVUyYGs/YiSUWXk
# c+uGyPm8DcIeQGEfOztKydl3qE0tG0QOTqCJtl+TqPwaRZuacXTH/X/az4oSg1g5
# BSrawJ9eagUUD7jL0gOUCHakMz/4P4vkos8dDb8vitr7v9b6WOVIQ1+sEg03GvKy
# FQIDAQABo4ICAzCCAf8wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIw
# HQYDVR0OBBYEFNjJEce0IdNYQxp2y/vTz43mpVH1MD4GA1UdIAQ3MDUwMwYGZ4EM
# AQQBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSBrTCB
# qjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+GTWh0
# dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWdu
# aW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSBhzCBhDAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUFBzAC
# hlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRD
# b2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRMEAjAAMA0G
# CSqGSIb3DQEBCwUAA4ICAQCbf/9bZQmPuGFJZUHfbkHTeA/sgbbBbOMyVO/kKfX2
# 9BY6D4ChS/ZPPQKFvOvfjp9KcTC1l43oFHP7eL9tTopnVL7YQm+btRhu5aAlmjQF
# sREjc0ZSVrP0NTFOhXMP8WEp1TYCkrrtR63MNno557UYKNKwdDx9+I0MmJ4GnDVD
# ua4SyPJAUPj39x4SIBPYxqI/Ur4czUHCUFxMfhsqtNKby+u8ziTu9ec/ztcw3+VL
# V/OAW2Tk1I5GA1PfDV+mdcvVTbrt0WDhoZjrzHpvvcJ16n45e5b8wyMQMnEzcuCH
# cboEh3LPJmAptvp2B7aCkFstBXp0MOBdrgGjckvTOXLv297PEIZwQDyWZEmgBMqt
# 5rdUaKW76LzAUmLNm21ksBMozS5dRo1VUnIUHGw+lqvckqJ21oblI91baMwvnBrG
# WTqQ+ZwbLrC34Admxl2cLgg7OF8OG42ZOgiJukH4/HafX3ieqcYaZWv8Zm5U1pY2
# dWaCR16yf95MQnMmneOP+vG+awSF7Nb0/LhQTril7p/y9Gbyjz0WggmZOsTyKwY0
# IAhNpolZItrnG2+r4znOUkgc9uVXXMnU1J0CnTG1dDLTbcxyjvSngGh51oaS3RQm
# 160iipGj6pCs57DLp7Z7uNS9dHZkFOPoN0qJnTsl45Ja+FERtAE05mxtFsaUrhqO
# ETCCBY0wggR1oAMCAQICEA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcNAQEMBQAw
# ZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQ
# d3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBS
# b290IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2lj
# ZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv+aQc2jeu+RdSjwwIjBpM+zCpyUu
# ySE98orYWcLhKac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR0uRf1gU8
# Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlqczKU0RBEEC7fgvMHhOZ0O21x4i0M
# G+4g1ckgHWMpLc7sXk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53yEioZldX
# n1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17cjo+A2raRmECQecN4x7axxLVq
# GDgDEI3Y1DekLgV9iPWCPhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3VdeGbZOjFE
# mjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfBaYh2mHY9WV1CdoeJl2l6
# SPDgohIbZpp0yt5LHucOY67m1O+SkjqePdwA5EUlibaaRBkrfsCUtNJhbesz2cXf
# SwQAzH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaAsPvoZKYz0YkH4b23
# 5kOkGLimdwHhD5QMIR2yVCkliWzlDlJRR3S+Jqy2QXXeeqxfjT/JvNNBERJb5RBQ
# 6zHFynIWIgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCPorF+CiaZ9eRp
# L5gdLfXZqbId5RsCAwEAAaOCATowggE2MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0O
# BBYEFOzX44LScV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5BggrBgEFBQcBAQRtMGswJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNydDBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1UdIAQKMAgwBgYEVR0gADAN
# BgkqhkiG9w0BAQwFAAOCAQEAcKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqsoYcs7IVe
# qRq7IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy3iS8UgPITtAq3vot
# Vs/59PesMHqai7Je1M/RQ0SbQyHrlnKhSLSZy51PpwYDE3cnRNTnf+hZqPC/Lwum
# 6fI0POz3A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxUjG/voVA9/HYJ
# aISfb8rbII01YBwCA8sgsKxYoA5AY8WYIsGyWfVVa88nq2x2zm8jLfR+cWojayL/
# ErhULSd+2DrZ8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDCCBrQwggScoAMCAQIC
# EA3HrFcF/yGZLkBDIgw6SYYwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTI1MDUwNzAw
# MDAwMFoXDTM4MDExNDIzNTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
# Z2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVT
# dGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBALR4MdMKmEFyvjxGwBysddujRmh0tFEXnU2tjQ2UtZmW
# gyxU7UNqEY81FzJsQqr5G7A6c+Gh/qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzb
# NfiR+2fkHUiljNOqnIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0mR/vtLa4+gKPs
# YfwEu7EEbkC9+0F2w4QJLVSTEG8yAR2CQWIM1iI5PHg62IVwxKSpO0XaF9DPfNBK
# S7Zazch8NF5vp7eaZ2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhxKTVVgtmU
# PAW35xUUFREmDrMxSNlr/NsJyUXzdtFUUt4aS4CEeIY8y9IaaGBpPNXKFifinT7z
# L2gdFpBP9qh8SdLnEut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x5HHK
# S+rqBvKWxdCyQEEGcbLe1b8Aw4wJkhU1JrPsFfxW1gaou30yZ46t4Y9F20HHfIY4
# /6vHespYMQmUiote8ladjS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogx
# G9QEPHrPV6/7umw052AkyiLA6tQbZl1KhBtTasySkuJDpsZGKdlsjg4u70EwgWbV
# RSX1Wd4+zoFpp4Ra+MlKM2baoD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNT
# AgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBTvb1NK
# 6eQGfHrK4pBW9i/USezLTjAfBgNVHSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUH
# AQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYI
# KwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcw
# CAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAF877FoAc
# /gc9EXZxML2+C8i1NKZ/zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAz
# aoQk97frPBtIj+ZLzdp+yXdhOP4hCFATuNT+ReOPK0mCefSG+tXqGpYZ3essBS3q
# 8nL2UwM+NMvEuBd/2vmdYxDCvwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntu
# jB71WPYAgwPyWLKu6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOal95CHfmTnM4I+ZI2
# rVQfjXQA1WSjjf4J2a7jLzWGNqNX+DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z
# 0noDjs6+BFo+z7bKSBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/NmKLJ9M+MtucVG
# yOxiDf06VXxyKkOirv6o02OoXN4bFzK0vlNMsvhlqgF2puE6FndlENSmE+9JGYxO
# GLS/D284NHNboDGcmWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3rGlHqhpB
# /8MluDezooIs8CVnrpHMiD2wL40mm53+/j7tFaxYKIqL0Q4ssd8xHZnIn/7GELH3
# IdvG2XlM9q7WP/UwgOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlarEvf8
# EA+8hcpSM9LHJmyrxaFtoza2zNaQ9k+5t1wwggbtMIIE1aADAgECAhAKgO8YS43x
# BYLRxHanlXRoMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBU
# aW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAw
# MDAwWhcNMzYwOTAzMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGln
# aUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRp
# bWVzdGFtcCBSZXNwb25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEA0EasLRLGntDqrmBWsytXum9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7
# C8Dr0cVMF3BsfAFI54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAqlUPt281m
# HrBbZHqRK71Em3/hCGC5KyyneqiZ7syvFXJ9A72wzHpkBaMUNg7MOLxI6E9RaUue
# HTQKWXymOtRwJXcrcTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd2adw
# 44wDcKgH+JRJE5Qg0NP3yiSyi5MxgU6cehGHr7zou1znOM8odbkqoK+lJ25LCHBS
# ai25CFyD23DZgPfDrJJJK77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvh
# DU6lvJukx7jphx40DQt82yepyekl4i0r8OEps/FNO4ahfvAk12hE5FVs9HVVWcO5
# J4dVmVzix4A77p3awLbr89A90/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIU
# bWuhKuAeNIeWrzHKYueMJtItnj2Q+aTyLLKLM0MheP/9w6CtjuuVHJOVoIJ/DtpJ
# RE7Ce7vMRHoRon4CWIvuiNN1Lk9Y+xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CID
# BbTRofOsNyEhzZtCGmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7eacCAwEAAaOC
# AZUwggGRMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFOQ7/PIx7f391/ORcWMZUEPP
# YYzoMB8GA1UdIwQYMBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1UdDwEB/wQE
# AwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDCBlQYIKwYBBQUHAQEEgYgwgYUw
# JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEFBQcw
# AoZRaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0
# VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYw
# VKBSoFCGTmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRH
# NFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAX
# MAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBAGUqrfEc
# JwS5rmBB7NEIRJ5jQHIh+OT2Ik/bNYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz
# 9iZEN/FPsLSTwVQWo2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV+Kbz/3ImZlJ7
# YXwBD9R0oU62PtgxOao872bOySCILdBghQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8l
# D8QAGB9lctZTTOJM3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fxUFEp7W42
# fNBVN4ueLaceRf9Cq9ec1v5iQMWTFQa0xNqItH3CPFTG7aEQJmmrJTV3Qhtfparz
# +BW60OiMEgV5GWoBy4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu/CIJ
# nzkQTwtSSpGGhLdjnQ4eBpjtP+XB3pQCtv4E5UCSDag6+iX8MmB10nfldPF9SVD7
# weCC3yXZi/uuhqdwkgVxuiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH
# 3EmAp/jsJ3FVF3+d1SVDTmjFjLbNFZUWMXuZyvgLfgyPehwJVxwC+UpX2MSey2ue
# Iu9THFVkT+um1vshETaWyQo8gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6I
# Ls84ZPvmpovq90K8eWyG2N01c4IhSOxqt81nMYIGXTCCBlkCAQEwfTBpMQswCQYD
# VQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lD
# ZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEg
# Q0ExAhABUX9+ZWirr6OpYdH+HnHPMA0GCWCGSAFlAwQCAQUAoIGIMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCSqGSIb3DQEJBTEPFw0yNjAyMTkxOTUzMjRa
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCDW
# iJ4BjPzz3Sa/J4zfibdbmqbfIYODRmedJHU7Yv5ugjANBgkqhkiG9w0BAQEFAASC
# AgBAxBkGDxSEKwndRe31g6dFEvdD2PFNaEwv3WGHbm4FtePZlbdp/maJvBO17Vvs
# tvcKeu3VOr2ocVyV9vF/gGHik4HQ5LjoAaEzWfsCdaxeff+294OamrwEraEpGtFQ
# lmtoqxYIJidYbcL1vRKlWRVLns3wYtYiE2uZ72zy7UroVAhetVR1+LN7YlwQ0sai
# 9X1duO3SWF8qSC/HL1YQZHM4tHXMMXNpWSofC1Qjur99JWkW86b3S8DfGNbD8OE6
# a2EZIqCOamld4hoA0YiaUeiFwEsloX3mFRJKsVJIqb+zYT4jJbNHeTer5So2Yf0j
# cljihdQr8UfS/yOWGoq+ShGuB6dj3smwFzni8+tD0H8O2bvb+Hvv1vMQqMd1SuTD
# aa0QdxY51YlDRk0T+Z6LWVIXZ4Mn2n5Yyo6XC24HWSsiHfP2Q29J8gh9ETwTxMWA
# puE9BTxYwh+ucHKY4trGK3PzLoAr7j8QHYl1PKZsWMolxJro8VxOiQJEGBgJmL/i
# yt2V0DVbfQ5sgN6wGjppcRFEpIG0JJLpprc1yF9rgiIv1Pqhc3hS5LcJEfmtZJ+G
# H3i2aN/rBtVpOSMoWSBNBf/FjCuQq/eZQfJ1RyLe4yDyRdUflRYTtvLHYh83XAC9
# 2ECa+CGAnS0hfH40zhUCiivcsM4XIYYiTF35akB1LqYcZqGCAyYwggMiBgkqhkiG
# 9w0BCQYxggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdp
# Q2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3Rh
# bXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgw
# DQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
# SIb3DQEJBTEPFw0yNjAyMTkxOTUzMjRaMC8GCSqGSIb3DQEJBDEiBCA8wg3aQyzj
# 7gs7BQeg7jgVxu8TDemYSK/OUNtXVyM5sjANBgkqhkiG9w0BAQEFAASCAgBNTnbZ
# akLYwkfE7toAdPUbNqqJ2AG5SOyjClBEsUCluEzeke3PxpAJczAE/6sldZxNOBhv
# fNyVUiQbx3owC6IQV0X+aIy72X3w3xdFMeP+b5QybnwXMIkxf0+vw9I1+b1N/vKF
# 7/gTGOEfbN31iDEgoQUaT0K9Nzzj4PBKUqbHC0KhXjmhNRuvE+wuphiYOpR4HeKx
# bJRq0q/ojGhGbkUl4L6EPAKiHegT5dnpw499/W/07f42nCfAvv8RGw2ywIKaplU0
# AKto8An0tnTdhfyzBNCvoAtqE3KTYs+tSr5dC+PRQF6KuduTEws9hERPiSXbbclM
# LmGgCwYot4Xt3tM+VzIhk1Gi4F7LQ72VZLw4UKYcwUsM7RW08B8LsW7OdtwZJklH
# 7snNH8XlMKoD867HVD1pWvc6hjfmH9ilgnREn+5z6tM4Y98olrPDBQbzgpp4C20V
# Il+OolaAO/FqaUI6JvXAOl1jtilQn/imKqhkaRoutaX+LdQwJ9aH52QHSUX/dIgv
# 8mIk2B14V9dcmTiMful5VPsxwMhRddYyS0XjcUl+pEkrPCTYqhSR19EZZYidNgLF
# inhA5JGia0ogm20dSNFz7KhCmqx+ueFPg5QfcBimLvO/1maxwS8OnhyC/dfuGKdA
# gR0XsCOooFEQWMoBr0m2JbBOyFH5+NCAMJOqYQ==
# SIG # End signature block

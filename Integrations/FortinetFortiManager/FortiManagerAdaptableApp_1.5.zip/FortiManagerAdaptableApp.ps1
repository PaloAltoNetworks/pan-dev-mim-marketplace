<#
//-----------------------------------------------------------------------
// Fortinet FortiManager Adaptable Application
// supporting devices 6.4, 7.0
// v1.5
//
// Copyright (c)2026 Venafi, Inc. All rights reserved. This integration module
// is licensed under the same terms and conditions as your CyberArk product, 
// available here: https://www.cyberark.com/contract-terms/
//-----------------------------------------------------------------------

<field name>|<label text>|<flags>

Bit 1 = Enabled
Bit 2 = Policyable
Bit 3 = Mandatory

-----BEGIN FIELD DEFINITIONS-----
Text1|Certificate Label|100
Text2|Text Field #2|000
Text3|Text Field #3|000
Text4|Text Field #4|000
Text5|Text Field #5|000
Option1|Not Used|000
Option2|Not Used|000
Passwd|Not Used|000
-----END FIELD DEFINITIONS-----
#>

$script:scriptVersion = '1.5'
$script:scriptName = 'AdaptableApp\FortiManagerAdaptableApp'

# DO NOT REMOVE
# Certificate validation must be disabled to allow 
# provisioning and discovery processes to complete 
# successfully.
if ( $PSVersionTable.PSEdition -eq 'Core' ) {
    # ps core, assume vaas
    $PSDefaultParameterValues['Invoke-WebRequest:SkipCertificateCheck'] = $true
    $PSDefaultParameterValues['Invoke-RestMethod:SkipCertificateCheck'] = $true
}
else {
    # need the following to interface with an untrusted certificate
    Add-Type -TypeDefinition @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@

    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# Load System.Net.Http assembly for HttpRequestException handling
try {
    Add-Type -AssemblyName System.Net.Http
} 
catch {
    # If the assembly can't be loaded, we'll handle this in the catch blocks
    'System.Net.Http assembly could not be loaded. Will use generic exception handling.' | Write-VenafiDebug
}

# Unused Functions (These functions must be present for the Adaptable framework to work, but they are unused by this driver)
function Get-TPPUnused {
    [Alias("Prepare-Keystore")]
    [Alias("Generate-KeyPair")]
    [Alias("Generate-CSR")]
    [Alias("Update-Binding")]
    [Alias("Activate-Certificate")]
    [Alias("Install-Chain")]
    [Alias("Install-PrivateKey")]
    [Alias("Extract-PrivateKey")]
    [Alias("Remove-Certificate")]
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $false, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $false, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )
    Write-FunctionDetail $PSCmdlet.MyInvocation
    "Function '$($MyInvocation.InvocationName)' is not needed by this Adaptable Application." | Write-VenafiDebug
    return @{ Result = "NotUsed"; }
}

function Test-Connection {
    Param(
    [Parameter(Mandatory = $true, HelpMessage = "General Parameters")] [System.Collections.Hashtable]$General
    )
    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
    
    $serverName = $General.HostAddress
    $username = $General.UserName
    $password = $General.UserPass

    $server = "https://$($serverName)/jsonrpc"
    $headers = @{
        "Content-Type" = "application/json"
    }
    $method = "POST"
    
    # Setting default parameter values for Invoke-RestMethod cmdlet
    $PSDefaultParameterValues.Add('Invoke-RestMethod:Uri', $server)
    $PSDefaultParameterValues.Add('Invoke-RestMethod:Headers', $headers)
    $PSDefaultParameterValues.Add('Invoke-RestMethod:Method', $method)

    # An Id is used to associate the return from the API call. The server
    # will return the same Id as part of it's payload.
    $id = ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
    "Using current epoch (in seconds) as API Id. ID: [$($id)]." | Write-VenafiDebug
    
    # Perform a "login" to generate the session token which is used for
    # all API calls moving forward.        
    $reqSession = New-FMSession -Id $id -UserName $username -UserPass $password
    
    if ($reqSession.Error) {
        return @{Result = "Failure" }
    }
    else {
        return @{Result = "Success"}
    }
}

<######################################################################################################################
.NAME
    Install-Certificate
.DESCRIPTION
    Installs the certificate on the hosting platform.  May optionally be used to also install the private key and chain.
    Implementing logic for this function is REQUIRED.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        HostAddress : a string containing the hostname or IP address specified by the device object
        TcpPort : an integer value containing the TCP port specified by the application object
        UserName : a string containing the username portion of the credential assigned to the device or application object
        UserPass : a string containing the password portion of the credential assigned to the device or application object
        UserPrivKey : the non-encrypted PEM of the private key credential assigned to the device or application object
        AppObjectDN : a string containing the TPP distiguished name of the calling application object
        AssetName : a string containing a Venafi standard auto-generated name that can be used for provisioning
                    (<Common Name>-<ValidTo as YYMMDD>-<Last 4 of SerialNum>)
        VarText1 : a string value for the text custom field defined by the header at the top of this script
        VarText2 : a string value for the text custom field defined by the header at the top of this script
        VarText3 : a string value for the text custom field defined by the header at the top of this script
        VarText4 : a string value for the text custom field defined by the header at the top of this script
        VarText5 : a string value for the text custom field defined by the header at the top of this script
        VarBool1 : a boolean value for the yes/no custom field defined by the header at the top of this script (true|false)
        VarBool2 : a boolean value for the yes/no custom field defined by the header at the top of this script (true|false)
        VarPass : a string value for the password custom field defined by the header at the top of this script
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        CertPem : the X509 certificate to be provisioned in Base64 PEM format
        PrivKeyPem : the non-encrypted private key in RSA Base64 PEM format
        PrivKeyPemEncrypted : the password encrypted private key in RSA Base64 PEM format
        ChainPem : all chain certificates concatentated together one after the other
        ChainPkcs7 : byte array PKCS#7 collection that includes all chain certificates
        Pkcs12 : byte array PKCS#12 collection that includes certificate, private key, and chain
        EncryptPass : the string password that was used to encrypt the private key and PKCS#12 keystore
.NOTES
    Returns...
        Result : 'Success', 'AlreadyInstalled' or 'NotUsed' to indicate the non-error completion state
                 (may only be 'NotUsed' if Install-PrivateKey did not return 'NotUsed')
        AssetName : (optional) the base name used to reference the certificate as it was installed on the device;
                    if not supplied the auto-generated name is assumed
######################################################################################################################>
function Install-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable]$Specific
    )

    try {
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

        $serverName = $General.HostAddress
        $username = $General.UserName
        $password = $General.UserPass
        $pem = $Specific.CertPem
        $assetName = if (($General.AssetName -eq $General.VarText1) -or ([String]::IsNullOrEmpty($General.VarText1))) {
            "Using the AssetName ""$($General.AssetName)"" to retrieve the certificate from the FortiManager device." | Write-VenafiDebug
            $General.AssetName
        }
        elseif ($General.VarText1) {
            "Using the Certificate Label ""$($General.VarText1)"" to retrieve the certificate from the FortiManager device." | Write-VenafiDebug
            $General.VarText1
        }
        else {
            "Validation of the certificate cannot continue because the ""AssetName"" value is missing." | Write-Warning
        }
        
        $server = "https://$($serverName)/jsonrpc"
        $headers = @{
            "Content-Type" = "application/json"
        }
        $method = "POST"
        
        # Setting default parameter values for Invoke-RestMethod cmdlet
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Uri', $server)
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Headers', $headers)
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Method', $method)

        # The certificate asset name cannot exceed 35 characters.
        $assetName = Set-CertificateLabel -InputObject $assetName
        if ($assetName.Length -gt 35) {
            $msg = "The certificate label contains more than 35 characters which is not supported by FortiManager. Please update the ""Certificate Label"" field on the adaptable application."
            $msg | Write-VenafiDebug
            return @{Result = $msg}
        }
        #The certificate asset name cannot be Fortinet_Local
        if ($assetName -ieq "fortinet_local") {
            $msg = "The certificate label cannot be 'Fortinet_Local' as this is a reserved name in FortiManager. Please update the ""Certificate Label"" field on the adaptable application."
            $msg | Write-VenafiDebug
            return @{Result = $msg}
        }  

        # An Id is used to associate the return from the API call. The server
        # will return the same Id as part of it's payload.
        $id = ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
        "Using current epoch (in seconds) as API Id. ID: [$($id)]." | Write-VenafiDebug
        
        # Perform a "login" to generate the session token which is used for
        # all API calls moving forward.        
        $reqSession = New-FMSession -Id $id -UserName $username -UserPass $password
        
        if ($reqSession.Error) {
            return @{Result = $reqSession.Error }
        }
        else {
            $session = $reqSession.Response.session
            $session | Write-VenafiDebug
        }

        # Setting default parameter values for FortiManager functions (excluding New-FMSession)
        $PSDefaultParameterValues.Add('*-FM*:Id', $id)
        $PSDefaultParameterValues.Add('*-FM*:Session', $session)

        # Retrieve the Admin Server Cert value from the Admin settings
        $reqAdminCert = Get-FMAdminCertificate

        if ($reqAdminCert.Error) {
            return @{Result = $reqAdminCert.Error }
        }
        else {
            $adminCert = $reqAdminCert.Response.result.data.admin_server_cert
            $adminCert | Write-VenafiDebug
        }

        # Get certificates installed on FortiManager. FortiManager doesn't care if
        # certificate already exists, the certificate will be overwritten
        # so we check to make sure the uploaded certificate is unique
        $reqCert = Get-FMCertificate
        
        if ($reqCert.Error) {
            return @{Result = $reqCert.Error }
        }
        else {
            $currentCerts = $reqCert.Response.result.data
            $currentCerts | Write-VenafiDebug
        }
        
        $defaultCert = ""
        foreach ($ecert in $currentCerts) {
            if ($ecert.comment -eq "Default local certificate") {
                $defaultCert = $ecert.name
                break;
            }
        }

        if ([string]::IsNullOrEmpty($defaultCert)) {
            return @{Result = "Unable to locate the default local certificate of the FortiManager device."}
        }

        # If the current admin_server_cert value is the same as the assetname,
        # the configuartion will not reload. This causes the GUI to continue to
        # use the old certificate. We need to update the admin_server_cert value
        # to the default local certificate before applying the new certificate.
        if ($adminCert -ilike "*$($defaultCert)*") {
            "The management certificate is already set to the default local certificate." | Write-VenafiDebug
        } else {
            if ($adminCert -eq $assetName) {
                foreach ($cert in $currentCerts) {
                    if ($cert.name -eq $adminCert) {
                        "Accessing active certificate in TLSPDC." | Write-VenafiDebug
                        [System.Security.Cryptography.X509Certificates.X509Certificate2]$tppx509 = ConvertTo-X509Certificate2 -CertificatePEM $pem
                        "Certificate currently in TLSPDC: $($tppx509 | ConvertTo-Json)" | Write-VenafiDebug
                        "Accessing management interface certificate on FortiManager." | Write-VenafiDebug
                        [System.Security.Cryptography.X509Certificates.X509Certificate2]$fgmx509 = ConvertTo-X509Certificate2 -CertificatePEM $cert.certificate[0]
                        "Certificate currently in FortiManager: $($fgmx509 | ConvertTo-Json)" | Write-VenafiDebug
                        if ($tppx509.SerialNumber -eq $fgmx509.SerialNumber) {
                            $msg = "The certificate to be provisioned already exists in on the FortiManager."
                            $msg | Write-Warning
                            $PSDefaultParameterValues.Clear()
                            return @{Result = "AlreadyInstalled"; AssetName = $cert.name }
                        }
                    }
                }
            }

            $revertCert = Set-FMAdminCertificate -CertName $defaultCert

            if ($revertCert.Error) {
                return @{Result = $revertCert.Error }
            }
            
            # We need to wait for the httpd service to restart on the FortiManager device.
            "The management certificate has been udpated which requires the script to wait until the configurations have been updated." | Write-VenafiDebug 
            
            $testConnect = $true
            $tests = 0
            $limit = 5
            while ($testConnect) {
                $tests++
                Start-Sleep -Seconds 10
                $result = Get-FMStatus -Session $session -Id $id
                if ($result.Response -ne "ConnectFailure") {
                    "System access has been restored. Continuing the installation of the certificate." | Write-VenafiDebug
                    $testConnect = $false
                } else {
                    if ($tests -eq $limit) {
                        "We've reached the maximum number of attempts to test connectivity." | Write-VenafiDebug
                        break;
                    }
                    "Attempt #$($tests) while trying to connect to FortiManager." | Write-VenafiDebug
                }
            }
            
            if ($testConnect) {
                $connMsg = "Failed to connect to the FortiManager device."
                $connMsg | Write-VenafiDebug
                return @{Result = $connMsg}
            }
        }
        
        
        # We upload the certificate and encrypted private key that
        # was passed by TLS Protect.
        $uploadCert = Add-FMCertificate -Specific $Specific -Label $assetName
        
        if ($uploadCert.Error) {
            return @{Result = $uploadCert.Error }
        }

        # Configure the system settings to use the new certificate
        $updateAdminCert = Set-FMAdminCertificate -CertName $assetName

        if ($updateAdminCert.Error) {
            return @{Result = $updateAdminCert.Error }
        }

        return @{Result = "Success"; AssetName = $assetName }
    }
    catch {
        $_ | Write-VenafiDebug
    }
    finally {
        # Cleanup our session token from the FortiManager server.
        # Unless the system is down, status failures will not result
        # in a failure. The response will be logged to the debug file.
        $rmSession = Remove-FMSession

        if ($rmSession.Error) {
            $rmSession.Error | Write-Error
        }

        $PSDefaultParameterValues.Clear()
    }
}

<######################################################################################################################
.NAME
    Extract-Certificate
.DESCRIPTION
    Extracts the active certificate from the hosting platform.  If the platform does not provide a method for exporting the
    raw certificate then it is sufficient to return only the Serial and Thumprint.  This function is REQUIRED.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Prepare-Keystore)
.NOTES
    Returns...
        Result : 'Success' or 'NotUsed' to indicate the non-error completion state
        CertPem : the extracted X509 certificate referenced by AssetName in Base64 PEM format
        Serial : the serial number of the X509 certificate refernced by AssetName
        Thumbprint : the SHA1 thumprint of the X509 certificate referenced by AssetName
######################################################################################################################>
function Extract-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable]$General
    )

    try {
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        $serverName = $General.HostAddress
        $username = $General.UserName
        $password = $General.UserPass
        $assetName = if (($General.AssetName -eq $General.VarText1) -or ([String]::IsNullOrEmpty($General.VarText1))) {
            "Using the AssetName ""$($General.AssetName)"" to retrieve the certificate from the FortiManager device." | Write-VenafiDebug
            $General.AssetName
        }
        elseif ($General.VarText1) {
            "Using the Certificate Label ""$($General.VarText1)"" to retrieve the certificate from the FortiManager device." | Write-VenafiDebug
            $General.VarText1
        }
        else {
            "Validation of the certificate cannot continue because the ""AssetName"" value is missing." | Write-Warning
        }
        
        $server = "https://$($serverName)/jsonrpc"
        $headers = @{
            "Content-Type" = "application/json"
        }
        $method = "POST"
        
        # Setting default parameter values for Invoke-RestMethod cmdlet
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Uri', $server)
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Headers', $headers)
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Method', $method)

        # An Id is used to associate the return from the API call. The server
        # will return the same Id as part of it's payload.
        $id = ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
        "Using current epoch (in seconds) as API Id. ID: [$($id)]." | Write-VenafiDebug
        
        # Perform a "login" to generate the session token which is used for
        # all API calls moving forward.        
        $reqSession = New-FMSession -Id $id -UserName $username -UserPass $password
        
        if ($reqSession.Error) {
            return @{Result = $reqSession.Error }
        }
        else {
            $session = $reqSession.Response.session
            $session | Write-VenafiDebug
        }

        # Setting default parameter values for FortiManager functions (excluding New-FMSession)
        $PSDefaultParameterValues.Add('*-FM*:Id', $id)
        $PSDefaultParameterValues.Add('*-FM*:Session', $session)

        # Get certificates installed on FortiManager. FortiManager doesn't care if
        # certificate already exists, the certificate will be overwritten
        # so we check to make sure the uploaded certificate is unique
        $reqCert = Get-FMCertificate
        
        if ($reqCert.Error) {
            return @{Result = $reqCert.Error }
        }
        else {
            $currentCerts = $reqCert.Response.result.data
            $currentCerts | Write-VenafiDebug
        }

        $retreivedPem = ""
        if ($assetName -iin $currentCerts.name) {
            "A certificate with the same name has been found on the FortiManager device." | Write-VenafiDebug
            foreach ($cert in $currentCerts) {
                if ($cert.name -ieq $assetName) {
                    $retreivedPem = $cert.certificate[0]
                    $retreivedPem | Write-VenafiDebug
                }
            }
        }
        else {
            return @{ Result = "ERROR: Unable to match the certificate in TLS Protect with the installed certificate of the FortiManager." } | Write-VenafiDebug
        }

        return @{ Result = "Success"; CertPem = $retreivedPem }
    }
    catch {
        $_ | Write-VenafiDebug
    }
    finally {
        # Cleanup our session token from the FortiManager server.
        # Unless the system is down, status failures will not result
        # in a failure. The response will be logged to the debug file.
        $rmSession = Remove-FMSession

        if ($rmSession.Error) {
            $rmSession.Error | Write-Error
        }

        $PSDefaultParameterValues.Clear()
    }
}

<######################################################################################################################
.NAME
    Discover-Certificates
.DESCRIPTION
    Discovers certificates and their instance metadata from a target device
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        HostAddress : a string containing the hostname or IP address specified by the device object
        TcpPort : an integer value containing the TCP port specified by the application object
        UserName : a string containing the username portion of the credential assigned to the device or application object
        UserPass : a string containing the password portion of the credential assigned to the device or application object
        UserPrivKey : the non-encrypted PEM of the private key credential assigned to the device or application object
.NOTES
    Returns...
        Result : 'Success' to indicate the non-error completion state
        Applications : an array of hashtables that include the following data for a certificate instance:
            Name - the name of the application object that represents this instance under the device object
            ApplicationClass - the schema class of the application object (defaults to 'Adaptable App')
            DriverName - the value of the Driver Name attribute (defaults to 'appadaptable')
            PEM - the raw X509 certificate in base64 encoded text format
            ValidationAddress - FQDN, hostname, or IP address where the server is presenting the certificate
            ValidationPort - TCP port on which the server is presending the certificate (integer between 1-65535, defaults to 443)
            Attributes - a hashtable that specifies zero or more Config attribute-value pairs to set on the application object
######################################################################################################################>
function Discover-Certificates {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = 'General Parameters')]
        [System.Collections.Hashtable]$General
    )

    try {
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
    
        $serverName = $General.HostAddress
        $username = $General.UserName
        $password = $General.UserPass
        
        $server = "https://$($serverName)/jsonrpc"
        $headers = @{
            "Content-Type" = "application/json"
        }
        $method = "POST"
        
        # Setting default parameter values for Invoke-RestMethod cmdlet
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Uri', $server)
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Headers', $headers)
        $PSDefaultParameterValues.Add('Invoke-RestMethod:Method', $method)

        # An Id is used to associate the return from the API call. The server
        # will return the same Id as part of it's payload.
        $id = ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
        "Using current epoch (in seconds) as API Id. ID: [$($id)]." | Write-VenafiDebug
        
        # Perform a "login" to generate the session token which is used for
        # all API calls moving forward.        
        $reqSession = New-FMSession -Id $id -UserName $username -UserPass $password
        
        if ($reqSession.Error) {
            return @{Result = $reqSession.Error }
        }
        else {
            $session = $reqSession.Response.session
            $session | Write-VenafiDebug
        }

        # Setting default parameter values for FortiManager functions (excluding New-FMSession)
        $PSDefaultParameterValues.Add('*-FM*:Id', $id)
        $PSDefaultParameterValues.Add('*-FM*:Session', $session)

        # Retrieve the Admin Server Cert value from the Admin settings
        $reqAdminCert = Get-FMAdminCertificate

        if ($reqAdminCert.Error) {
            return @{Result = $reqAdminCert.Error }
        }
        else {
            $adminCert = $reqAdminCert.Response.result.data.admin_server_cert
            $adminCert | Write-VenafiDebug
        }

        # Get certificates installed on FortiManager.
        $reqCert = Get-FMCertificate
        
        if ($reqCert.Error) {
            return @{Result = $reqCert.Error }
        }
        else {
            $currentCerts = $reqCert.Response.result.data
            $currentCerts | Write-VenafiDebug
        }

        if ($currentCerts.Count -eq 0) {
            "Discovery did not find any certificates on the FortiManager device." | Write-VenafiDebug
            return @{Result = "Success" }
        }

        $reqStatus = Get-FMStatus

        $apps = @()
        foreach ($cert in $currentCerts) {
            if ($cert.name -eq $adminCert) {
                $app = @{
                    Name              = "MGMT-$($reqStatus.Response.result.data.Hostname)"
                    PEM               = $($cert.certificate[0] -replace '"', "")
                    ValidationAddress = $cert.name
                    Attributes = @{
                        "Text Field 1" = $cert.name
                    }
                }
                $apps += $app
            }
        }

        "Importing the following certificate to TLS Protect." | Write-VenafiDebug
        $japps = $apps | ConvertTo-Json -Depth 10
        $japps | Write-VenafiDebug

        return @{ Result = "Success"; Applications = $apps }

    }
    catch {
        $_ | Write-VenafiDebug
    }
    finally {
        # Cleanup our session token from the FortiManager server.
        # Unless the system is down, status failures will not result
        # in a failure. The response will be logged to the debug file.
        $rmSession = Remove-FMSession

        if ($rmSession.Error) {
            $rmSession.Error | Write-Error
        }

        $PSDefaultParameterValues.Clear()
    }
}

#############################     Functions below are not Adaptable App functions     #################################

function Invoke-FortiRestMethod {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $Payload
    )

    $result = [System.Collections.Hashtable]::new()
    try {
        $jsonObject = $Payload | ConvertFrom-Json
        if ($jsonObject.params.data.passwd) {
            $jsonObject.params.data.passwd = "xxxxxx"
        }
        "Outgoing Payload:" | Write-VenafiDebug
        $jsonObject | Write-VenafiDebug
        $resp = Invoke-RestMethod -Body $Payload
        if ($resp.session) {
            $resp | Write-VenafiDebug
            $result.Add('Response', $resp)
            return ($result | ConvertTo-Json -Depth 20 | ConvertFrom-Json)
        }
        if ($resp.result.status.code -ne 0) {
            $msg = $resp.result.status.message
            $msg | Write-Error
            $result.Add("Error", "ERROR: $($msg).")
            return ($result | ConvertTo-Json -Depth 20 | ConvertFrom-Json)
        }
    
        $resp | Write-VenafiDebug
        $result.Add('Response', $resp)
        return ($result | ConvertTo-Json -Depth 20 | ConvertFrom-Json)
    }
    catch [system.net.webexception],[System.Net.Http.HttpRequestException] {
         $_ | Write-VenafiDebug
        if (($_.Exception.StatusMessage -ilike "ConnectionClosed") -or ($_.Exception.HttpRequestError -like "ResponseEnded")`
                -and $Payload.params.url -eq "/cli/global/system/admin/setting"`
                -and $Payload.method -eq "set") {
            # Do nothing. We expect this exception when the server
            # certificate is replaced for the FortiManager device.
            $disconnectType = if ($_.Exception.StatusMessage) {$_.Exception.StatusMessage} else {$_.Exception.HttpRequestError}
            "Encountered the ""$($disconnectType)"" exception, which is expected when activating the certificate." | Write-VenafiDebug
            $result.Add('Response', "Success")
            return ($result | ConvertTo-Json -Depth 20 | ConvertFrom-Json)
        }
        if (($_.Exception.StatusMessage -ilike "ConnectFailure") -or ($_.Exception.HttpRequestError -like "ConnectionError")`
                -and $Payload.params.url -eq "/cli/global/system/status") {
            $disconnectType = if ($_.Exception.StatusMessage) {$_.Exception.StatusMessage} else {$_.Exception.HttpRequestError}
            $result.Add('Response', $disconnectType)
            return ($result | ConvertTo-Json -Depth 20 | ConvertFrom-Json)
        }
    }
    catch {
        $msg = $_.Exception.Message
        $msg | Write-Error
        $result.Add("Error", "ERROR: $($msg).")
        $_ | Write-VenafiDebug
        return ($result | ConvertTo-Json -Depth 20 | ConvertFrom-Json)
    }
}

function Set-CertificateLabel {
    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline = $true)]
        [string]
        $InputObject
    )
    
    "Evaluating the certificate name to ensure it does not exceed the 35 character limit." | Write-VenafiDebug

    # Is the asset name in Venafi format
    $newCertName = ""
    if ($InputObject -match '^.+_\d{2}\w{3}\d{2}_.{4}$') {
        $certCn, $expDate, $serialNum = $InputObject.Split('_')
        if ($certCn.Length -ge 22) {
            $certCn = $certCn.Substring(0, 22)
        }

        $newCertName = ($certCn -replace "\.", "-") + '_' + $expDate + '_' + $serialNum
        "The Venafi generated asset name exceeds the 35 character limit for FortiGate. Renamed to ""$($newCertName)""." | Write-VenafiDebug
    }
    else {
        $newCertName = ($InputObject -replace "\.", "_")
    }

    return $newCertName
}

function New-FMSession {
    [CmdletBinding()]
    param (
        [Parameter()]
        [int32]
        $Id,
        [Parameter()]
        [string]
        $UserName,
        [Parameter()]
        [string]
        $UserPass
    )

    $login = @{
        "id"     = $($id)
        "method" = "exec"
        "params" = @(
            @{
                "data" = @{
                    "user"   = "$($UserName)"
                    "passwd" = "$($UserPass)"
                }
                "url"  = "/sys/login/user"
            }
        )
    } | ConvertTo-Json -Compress -Depth 4

    "Retrieving API session token." | Write-VenafiDebug
    $result = Invoke-FortiRestMethod -Payload $login
    return $result
}

function Get-FMCertificate {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Session,
        [Parameter()]
        [int32]
        $Id
    )

    $listCerts = @{
        "method"  = "get"
        "params"  = @(
            @{
                "url" = "/cli/global/system/certificate/local"
            }
        )
        "session" = "$($Session)"
        "verbose" = 1
        "id"      = $($Id)
    } | ConvertTo-Json -Compress -Depth 3
    
    "Retrieving existing certificates." | Write-VenafiDebug
    $result = Invoke-FortiRestMethod -Payload $listCerts
    return $result
}

function Add-FMCertificate {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Session,
        [Parameter()]
        [int32]
        $Id,
        [Parameter()]
        [System.Collections.Hashtable]
        $Specific,
        [Parameter()]
        [string]
        $Label
        )

    $setCert = @{
        "method"  = "set"
        "params"  = @(
            @{
                "data" = @(
                    @{
                        "certificate" = @("$($Specific.CertPem -replace "`r`n", "`n")")
                        "comment"     = "Installed by Venafi TLS Protect with session ID $($id)"
                        "name"        = "$($Label)"
                        "password"    = @("$($Specific.EncryptPass)")
                        "private-key" = @("$($Specific.PrivKeyPemEncrypted -replace "`r`n", "`n")")
                    }
                )
                "url"  = "/cli/global/system/certificate/local"
            }
        )
        "session" = "$($Session)"
        "id"      = $($Id)
    } | ConvertTo-Json -Compress -Depth 10

    "Uploading the certificate to FortiManager." | Write-VenafiDebug
    $result = Invoke-FortiRestMethod -Payload $setCert
    return $result
}

function Get-FMAdminCertificate {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Session,
        [Parameter()]
        [int32]
        $Id
    )

    $getAdminCert = @{
        "method"  = "get"
        "params"  = @(
            @{
                "url" = "/cli/global/system/admin/setting"
            }
        )
        "session" = "$($Session)"
        "id"      = $($Id)
    } | ConvertTo-Json -Compress -Depth 3
    
    "Retrieving the FortiManager managment interface certificate." | Write-VenafiDebug
    $result = Invoke-FortiRestMethod -Payload $getAdminCert
    return $result
}

function Set-FMAdminCertificate {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Session,
        [Parameter()]
        [int32]
        $Id,
        [Parameter()]
        [string]
        $CertName
    )

    $setAdminCert = @{
        "method"  = "set"
        "params"  = @(
            @{
                "data" = @{
                    "admin_server_cert" = "$($CertName)"
                }
                "url"  = "/cli/global/system/admin/setting"
            }
        )
        "session" = "$($Session)"
        "id"      = $($Id)
    } | ConvertTo-Json -Compress -Depth 5

    "Activating the managment certificate for the FortiManager." | Write-VenafiDebug
    $result = Invoke-FortiRestMethod -Payload $setAdminCert
    return $result
}

function Remove-FMSession {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Session,
        [Parameter()]
        [int32]
        $Id
    )
    $logout = @{
        "id"      = $($Id)
        "method"  = "exec"
        "params"  = @(
            @{
                "url" = "/sys/logout"
            }
        )
        "session" = "$($Session)"
    } | ConvertTo-Json -Compress -Depth 3

    "Revoking the session token." | Write-VenafiDebug
    $result = Invoke-FortiRestMethod -Payload $logout
    return $result
}

Function ConvertTo-X509Certificate2 {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $CertificatePEM
    )
    
    "Converting PEM to X509 Object." | Write-VenafiDebug
    $certPEM = [regex]::Matches($CertificatePEM, "-+BEGIN CERTIFICATE-+(?<b64>[^-]*)-+END CERTIFICATE-+")
    $b64 = $certPEM[0].Groups['b64'].Value

    $bytes = [Convert]::FromBase64String($b64)
    $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($bytes)
    return $cert
}

Function Get-FMStatus {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $Session,
        [Parameter()]
        [int32]
        $Id
    )

    $status = @{
        method =  "get"
        params = @(
            @{
                url = "/cli/global/system/status"
            }
        )
        session = $Session
        id = $Id
    } | ConvertTo-Json -Compress -Depth 3

    $result = Invoke-FortiRestMethod -Payload $status
    return $result
}

Function Write-FunctionDetail {

    <#
    .SYNOPSIS
        Log function details
    .DESCRIPTION
        Log function details including the function name and any bound parameters
    .PARAMETER InvocationInfo
        Invocation detail from a function, typically sent via $PSCmdlet.MyInvocation
    .PARAMETER NoBoundParams
        By default, function parameters and values will be written.  Don't do this.
    .PARAMETER ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
    .NOTES
        Must be an advanced function otherwise $PSCmdlet.MyInvocation will not be available.
        Set $script:scriptVersion to include the script version in the log.
        Set $script:scriptName to validate signing.  Value should be similar to 'AdaptableCA\MyDriver', after Scripts dir and no .ps1.
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation
        Put this at the start of every function
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -NoBoundParams
        Do not output the bound parameters
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
        Helpful for the first log entry in a script to help with troubleshooting.
    #>

    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Management.Automation.InvocationInfo] $InvocationInfo,

        [Parameter()]
        [switch] $NoBoundParams,

        [Parameter()]
        [Alias('ValidateScript')]
        [switch] $ExtraInfo
    )

    $cs = Get-PSCallStack
    # get list of function names from stack, remove this function and the one which called it
    $functionBreadcrumb = ($cs.FunctionName | Select-Object -Skip 2) -join ' <- '

    $header = 'Function: {0} (<- {1})' -f $InvocationInfo.InvocationName, $functionBreadcrumb
    $header += if ($script:scriptVersion) { ', script version: {0}' -f $script:scriptVersion } else { '' }

    if ( $ExtraInfo ) {

        # registry only available on CMSH
        # if reusing this script with CMSaaS, this section will be skipped
        if ( $PSVersionTable.PSEdition -ne 'Core' ) {
            $installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

            if ( $script:scriptName ) {
                try {
                    $sig = Get-AuthenticodeSignature -FilePath ('{0}Scripts\{1}.ps1' -f $installPath, $script:scriptName)
                    $sigStatus = if ( $sig.Status -eq 'Valid' ) { 'Valid' } else { 'Not Valid' }
                }
                catch {
                    $sigStatus = $_.ToString()
                }
            }
            else {
                $sigStatus = 'script name not set'
            }

            $header += ", signature: $sigStatus"

            # add CMSH version if available
            try {
                $f = Join-Path -Path $installPath -ChildPath 'Platform\Venafi.InstallKit.dll'
                $header += ', CMSH version: {0}' -f (Get-Item $f).VersionInfo.FileVersion
            }
            catch {
                # just for logging, don't fail
            }
        }

        # add powershell version
        $header += ', PowerShell version: {0}' -f $PSVersionTable.PSVersion.ToString()

    }

    $header | Write-VenafiDebug

    if ( $null -ne $InvocationInfo.BoundParameters -and -not $NoBoundParams ) {
        [hashtable]$InvocationInfo.BoundParameters | Write-VenafiDebug
    }
}

function Write-VenafiDebug {

    <#
    .SYNOPSIS
    Write info to the adaptable debug log

    .DESCRIPTION
    Assuming the option has been selected, write info to the adaptable debug log.
    Hashtables are supported and secret info will not be logged, eg. $General.

    .PARAMETER Message
    The info to be logged

    .PARAMETER ThrowException
    After logging the message, throw an exception to terminate the script

    .EXAMPLE
    Write-VenafiDebug -Message 'connected to server'

    Write info to the log

    .EXAMPLE
    $General | Write-VenafiDebug

    Write input parameter values to the log

    .EXAMPLE
    Write-VenafiDebug -Message 'this was not good' -ThrowException

    Write to the log and throw an exception
    #>

    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [psobject] $Message,

        [Parameter()]
        [string] $Intro,

        [Parameter()]
        [switch] $ThrowException
    )

    process {

        if ( -not $global:DEBUG_FILE ) {
            return
        }

        $newMessage = switch ($Message.GetType().FullName) {
            'System.Collections.Hashtable' {
                Set-SecretsToHidden $Message | ConvertTo-Json -Depth 5
            }

            'System.String' {
                $Message
            }

            'System.Management.Automation.ErrorRecord' {
                # powershell specific exception
                $err = $Message
                $ex = $err.Exception
                $inv = $err.InvocationInfo
                $logEntry = @{
                    Message          = $ex.Message
                    ErrorId          = $err.FullyQualifiedErrorId
                    Category         = $err.CategoryInfo.Category
                    TargetObject     = $err.TargetObject
                    ScriptName       = $inv.ScriptName
                    LineNumber       = $inv.ScriptLineNumber
                    Line             = $inv.Line
                    Position         = $inv.PositionMessage
                    StackTrace       = $ex.StackTrace
                    ScriptStackTrace = $err.ScriptStackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }
                $logEntry | ConvertTo-Json -Depth 3
            }

            'System.Exception' {
                #.net generic exception
                $ex = $Message
                $inv = $ex.InvocationInfo
                $logEntry = @{
                    Message       = $ex.Message
                    ExceptionType = $ex.GetType().FullName
                    ScriptName    = $inv.ScriptName
                    LineNumber    = $inv.ScriptLineNumber
                    Line          = $inv.Line
                    Position      = $inv.PositionMessage
                    StackTrace    = $ex.StackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }

                $logEntry | ConvertTo-Json -Depth 3
            }

            default {
                $Message | ConvertTo-Json -Depth 3
            }
        }

        if ( $Intro ) {
            $newMessage = "$Intro`r`n$newMessage"
        }

        try {
            # use a mutex to ensure multiple executions of this script don't cause 'file in use' errors
            $mutex = New-Object System.Threading.Mutex($false, [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.ScriptName))
            if ( -not $mutex.WaitOne(0) ) {
                $mutex.WaitOne()
            }
            ('{0} : {1}' -f (Get-Date), ($newMessage | Out-String)) | Out-File -FilePath $global:DEBUG_FILE -Encoding 'UTF8' -Append
        }
        catch {
            throw $_
        }
        finally {
            $null = $mutex.ReleaseMutex()
        }
    }

    end {
        if ( $ThrowException ) {
            # since we're in the end block this is only intended for a string, not array or anything that needs the pipeline
            throw $Message
        }
    }
}

function Set-SecretsToHidden {

    <#
    .SYNOPSIS
        Blank out sensitive information
    .DESCRIPTION
        Blank out sensitive information in a message, typically in a hashtable.
        Meant for adaptable framework scripts.
        Will automatically clone hashtable to ensure original object isn't affected.
    #>


    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        $InputObject
    )

    process {

        $secrets = @('UserPass', 'AuxPass', 'PfxPass', 'Certificate', 'PfxData', 'Password', 'AuxPfxData', 'PrivKeyPem', 'Pkcs12', 'EncryptPass', 'ChainPkcs7', 'PrivKeyPemEncrypted', 'VarPass')

        # if needed, add additional secrets specific to this integration to be hidden
        # $secrets += '', ''

        if ($InputObject -is [hashtable]) {
            $clone = @{}
            foreach ($key in $InputObject.keys) {
                if ( [string]::IsNullOrEmpty($InputObject[$key]) ) {
                    $clone[$key] = ''
                }
                else {
                    if ($key -in $secrets ) {
                        $clone[$key] = '***hidden***'
                    }
                    else {
                        $clone[$key] = Set-SecretsToHidden $InputObject[$key]
                    }
                }
            }
            return $clone
        }
        else {
            return $InputObject
        }
    }
}
# SIG # Begin signature block
# MIIh2AYJKoZIhvcNAQcCoIIhyTCCIcUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC7iGbv7B6/N2tM
# xdzwSt3gZNU7oA+eTELyIA6/9uYZ1KCCGtEwggeTMIIFe6ADAgECAhABUX9+ZWir
# r6OpYdH+HnHPMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBD
# b2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjUwOTExMDAw
# MDAwWhcNMjYwOTEwMjM1OTU5WjCBmjELMAkGA1UEBhMCVVMxFjAUBgNVBAgTDU1h
# c3NhY2h1c2V0dHMxDzANBgNVBAcTBk5FV1RPTjEgMB4GA1UEChMXQ3liZXJBcmsg
# U29mdHdhcmUsIEluYy4xHjAcBgNVBAsTFVByb2Zlc3Npb25hbCBTZXJ2aWNlczEg
# MB4GA1UEAxMXQ3liZXJBcmsgU29mdHdhcmUsIEluYy4wggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC4Rp6KSQ+kelbVZimPMfQQPYfI1sYfkuOCTvooMhol
# oVm6aKLtEzZB7s0VkLLaW3XPfyzmlereIyRsK7h/3kxiXeeNzMu2tycqoSVFxwsn
# j04ptiSZ0TeD+ciM/EHvhapRqN2e1v5VRrpvsTkp9NAwKtf1z09czOeZXo2McpQm
# 66CLXfWWu6WhxV2wtDdn998cyxbGdXAZEdQmszU3YM6G9YB/2sdONTwSWaZqri9p
# oNnbO0hEByaz13PVPwN4FNJEKyY2RT7SJjrh6jPmkZwhvn08vna96tKsrw5XxxwJ
# FsFe7W2Wxgo4hybaVA0tLlOqmp6BufGjoa7GjpdM+g/SRm7xPFcSEJkqYJzoCVWu
# 5VNydUdZttKzzi1JfGuxQAaITelrIvo0K3cHig7NwN7F2/riIvP6tv+8AGiyGuoU
# uIAdnSEIRZLzdbfELdRyf6yffNYbaIi4iCS2UMwzDKzDzL3YPMu66jkx+zkC3iH0
# jXeWJMQn+Zsry0Sqpll+9EFeFBbo+ko28SsWnWfbEpkHZz+OuwVUyYGs/YiSUWXk
# c+uGyPm8DcIeQGEfOztKydl3qE0tG0QOTqCJtl+TqPwaRZuacXTH/X/az4oSg1g5
# BSrawJ9eagUUD7jL0gOUCHakMz/4P4vkos8dDb8vitr7v9b6WOVIQ1+sEg03GvKy
# FQIDAQABo4ICAzCCAf8wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIw
# HQYDVR0OBBYEFNjJEce0IdNYQxp2y/vTz43mpVH1MD4GA1UdIAQ3MDUwMwYGZ4EM
# AQQBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSBrTCB
# qjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+GTWh0
# dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWdu
# aW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSBhzCBhDAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUFBzAC
# hlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRD
# b2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRMEAjAAMA0G
# CSqGSIb3DQEBCwUAA4ICAQCbf/9bZQmPuGFJZUHfbkHTeA/sgbbBbOMyVO/kKfX2
# 9BY6D4ChS/ZPPQKFvOvfjp9KcTC1l43oFHP7eL9tTopnVL7YQm+btRhu5aAlmjQF
# sREjc0ZSVrP0NTFOhXMP8WEp1TYCkrrtR63MNno557UYKNKwdDx9+I0MmJ4GnDVD
# ua4SyPJAUPj39x4SIBPYxqI/Ur4czUHCUFxMfhsqtNKby+u8ziTu9ec/ztcw3+VL
# V/OAW2Tk1I5GA1PfDV+mdcvVTbrt0WDhoZjrzHpvvcJ16n45e5b8wyMQMnEzcuCH
# cboEh3LPJmAptvp2B7aCkFstBXp0MOBdrgGjckvTOXLv297PEIZwQDyWZEmgBMqt
# 5rdUaKW76LzAUmLNm21ksBMozS5dRo1VUnIUHGw+lqvckqJ21oblI91baMwvnBrG
# WTqQ+ZwbLrC34Admxl2cLgg7OF8OG42ZOgiJukH4/HafX3ieqcYaZWv8Zm5U1pY2
# dWaCR16yf95MQnMmneOP+vG+awSF7Nb0/LhQTril7p/y9Gbyjz0WggmZOsTyKwY0
# IAhNpolZItrnG2+r4znOUkgc9uVXXMnU1J0CnTG1dDLTbcxyjvSngGh51oaS3RQm
# 160iipGj6pCs57DLp7Z7uNS9dHZkFOPoN0qJnTsl45Ja+FERtAE05mxtFsaUrhqO
# ETCCBY0wggR1oAMCAQICEA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcNAQEMBQAw
# ZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQ
# d3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBS
# b290IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2lj
# ZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv+aQc2jeu+RdSjwwIjBpM+zCpyUu
# ySE98orYWcLhKac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR0uRf1gU8
# Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlqczKU0RBEEC7fgvMHhOZ0O21x4i0M
# G+4g1ckgHWMpLc7sXk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53yEioZldX
# n1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17cjo+A2raRmECQecN4x7axxLVq
# GDgDEI3Y1DekLgV9iPWCPhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3VdeGbZOjFE
# mjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfBaYh2mHY9WV1CdoeJl2l6
# SPDgohIbZpp0yt5LHucOY67m1O+SkjqePdwA5EUlibaaRBkrfsCUtNJhbesz2cXf
# SwQAzH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaAsPvoZKYz0YkH4b23
# 5kOkGLimdwHhD5QMIR2yVCkliWzlDlJRR3S+Jqy2QXXeeqxfjT/JvNNBERJb5RBQ
# 6zHFynIWIgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCPorF+CiaZ9eRp
# L5gdLfXZqbId5RsCAwEAAaOCATowggE2MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0O
# BBYEFOzX44LScV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5BggrBgEFBQcBAQRtMGswJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNydDBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1UdIAQKMAgwBgYEVR0gADAN
# BgkqhkiG9w0BAQwFAAOCAQEAcKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqsoYcs7IVe
# qRq7IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy3iS8UgPITtAq3vot
# Vs/59PesMHqai7Je1M/RQ0SbQyHrlnKhSLSZy51PpwYDE3cnRNTnf+hZqPC/Lwum
# 6fI0POz3A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxUjG/voVA9/HYJ
# aISfb8rbII01YBwCA8sgsKxYoA5AY8WYIsGyWfVVa88nq2x2zm8jLfR+cWojayL/
# ErhULSd+2DrZ8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDCCBrQwggScoAMCAQIC
# EA3HrFcF/yGZLkBDIgw6SYYwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTI1MDUwNzAw
# MDAwMFoXDTM4MDExNDIzNTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
# Z2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVT
# dGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBALR4MdMKmEFyvjxGwBysddujRmh0tFEXnU2tjQ2UtZmW
# gyxU7UNqEY81FzJsQqr5G7A6c+Gh/qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzb
# NfiR+2fkHUiljNOqnIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0mR/vtLa4+gKPs
# YfwEu7EEbkC9+0F2w4QJLVSTEG8yAR2CQWIM1iI5PHg62IVwxKSpO0XaF9DPfNBK
# S7Zazch8NF5vp7eaZ2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhxKTVVgtmU
# PAW35xUUFREmDrMxSNlr/NsJyUXzdtFUUt4aS4CEeIY8y9IaaGBpPNXKFifinT7z
# L2gdFpBP9qh8SdLnEut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x5HHK
# S+rqBvKWxdCyQEEGcbLe1b8Aw4wJkhU1JrPsFfxW1gaou30yZ46t4Y9F20HHfIY4
# /6vHespYMQmUiote8ladjS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogx
# G9QEPHrPV6/7umw052AkyiLA6tQbZl1KhBtTasySkuJDpsZGKdlsjg4u70EwgWbV
# RSX1Wd4+zoFpp4Ra+MlKM2baoD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNT
# AgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBTvb1NK
# 6eQGfHrK4pBW9i/USezLTjAfBgNVHSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUH
# AQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYI
# KwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcw
# CAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAF877FoAc
# /gc9EXZxML2+C8i1NKZ/zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAz
# aoQk97frPBtIj+ZLzdp+yXdhOP4hCFATuNT+ReOPK0mCefSG+tXqGpYZ3essBS3q
# 8nL2UwM+NMvEuBd/2vmdYxDCvwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntu
# jB71WPYAgwPyWLKu6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOal95CHfmTnM4I+ZI2
# rVQfjXQA1WSjjf4J2a7jLzWGNqNX+DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z
# 0noDjs6+BFo+z7bKSBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/NmKLJ9M+MtucVG
# yOxiDf06VXxyKkOirv6o02OoXN4bFzK0vlNMsvhlqgF2puE6FndlENSmE+9JGYxO
# GLS/D284NHNboDGcmWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3rGlHqhpB
# /8MluDezooIs8CVnrpHMiD2wL40mm53+/j7tFaxYKIqL0Q4ssd8xHZnIn/7GELH3
# IdvG2XlM9q7WP/UwgOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlarEvf8
# EA+8hcpSM9LHJmyrxaFtoza2zNaQ9k+5t1wwggbtMIIE1aADAgECAhAKgO8YS43x
# BYLRxHanlXRoMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBU
# aW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAw
# MDAwWhcNMzYwOTAzMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGln
# aUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRp
# bWVzdGFtcCBSZXNwb25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEA0EasLRLGntDqrmBWsytXum9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7
# C8Dr0cVMF3BsfAFI54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAqlUPt281m
# HrBbZHqRK71Em3/hCGC5KyyneqiZ7syvFXJ9A72wzHpkBaMUNg7MOLxI6E9RaUue
# HTQKWXymOtRwJXcrcTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd2adw
# 44wDcKgH+JRJE5Qg0NP3yiSyi5MxgU6cehGHr7zou1znOM8odbkqoK+lJ25LCHBS
# ai25CFyD23DZgPfDrJJJK77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvh
# DU6lvJukx7jphx40DQt82yepyekl4i0r8OEps/FNO4ahfvAk12hE5FVs9HVVWcO5
# J4dVmVzix4A77p3awLbr89A90/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIU
# bWuhKuAeNIeWrzHKYueMJtItnj2Q+aTyLLKLM0MheP/9w6CtjuuVHJOVoIJ/DtpJ
# RE7Ce7vMRHoRon4CWIvuiNN1Lk9Y+xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CID
# BbTRofOsNyEhzZtCGmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7eacCAwEAAaOC
# AZUwggGRMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFOQ7/PIx7f391/ORcWMZUEPP
# YYzoMB8GA1UdIwQYMBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1UdDwEB/wQE
# AwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDCBlQYIKwYBBQUHAQEEgYgwgYUw
# JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEFBQcw
# AoZRaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0
# VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYw
# VKBSoFCGTmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRH
# NFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAX
# MAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBAGUqrfEc
# JwS5rmBB7NEIRJ5jQHIh+OT2Ik/bNYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz
# 9iZEN/FPsLSTwVQWo2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV+Kbz/3ImZlJ7
# YXwBD9R0oU62PtgxOao872bOySCILdBghQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8l
# D8QAGB9lctZTTOJM3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fxUFEp7W42
# fNBVN4ueLaceRf9Cq9ec1v5iQMWTFQa0xNqItH3CPFTG7aEQJmmrJTV3Qhtfparz
# +BW60OiMEgV5GWoBy4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu/CIJ
# nzkQTwtSSpGGhLdjnQ4eBpjtP+XB3pQCtv4E5UCSDag6+iX8MmB10nfldPF9SVD7
# weCC3yXZi/uuhqdwkgVxuiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH
# 3EmAp/jsJ3FVF3+d1SVDTmjFjLbNFZUWMXuZyvgLfgyPehwJVxwC+UpX2MSey2ue
# Iu9THFVkT+um1vshETaWyQo8gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6I
# Ls84ZPvmpovq90K8eWyG2N01c4IhSOxqt81nMYIGXTCCBlkCAQEwfTBpMQswCQYD
# VQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lD
# ZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEg
# Q0ExAhABUX9+ZWirr6OpYdH+HnHPMA0GCWCGSAFlAwQCAQUAoIGIMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCSqGSIb3DQEJBTEPFw0yNjAyMjMxNjQ0NTha
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCCm
# qWikjjMKyeC/YaQO3yMO+ArEoQhn3kfqekamywjUqzANBgkqhkiG9w0BAQEFAASC
# AgCWrq13dovqcwdgEA3/4KUkIu+Ar27scSQ2A6JyMEUO/7XIxf5g79nzz65T5TmW
# qv2+DCEucgWJ9ZPkmub0bLm3tzWy+riPbqoBO0xl30u0PVjNMuOnP6FSgB9AYzvH
# 9N2LiyFT0Hn5cinFTWP2ozblaFpz302Sj0l/YIpEIQuZz1sg0iP1OuRxpr3DnGfb
# GqMdTZj+nysoAQYmH6x2zi2yFCybxFY9jn8jJdZY5uqQC2UfzRnYIYqWkYDHYu2g
# WQ+1lanTwcroJiE1eI3EmTdIeIrKWB6T/skbKl9kSEM1f0T9cQa+AACB7ZDt7Xah
# U3JXOFQikjHEqFR0Y4dd57pFC1wSF7aJGgk3elFUMKFRxXArGg0WJ51kUfuhy7n6
# AMGIyDKQLkvE1qydcf5xqtwD93fpfPP7mur6TnZQDTHopbAG/OH4W6UYaz/CBW0h
# 5d6FXAT0IU3zWQhsSJ/ErIqMvlS5CPm0QIsoeXsomL5/Z9+UDp4SGG9KdDU7Gu2j
# z64I5d8pmOGRVoQAQ0A9QEZJhkNWLAsn/fhkVZZ2l0mUQCKZZd1PMhe7ROIdPRGM
# QZj6KyPo+45NMlKDwkiO0MX0DWs44j3nrOytJBYID2HQRIFvpXptctOkDJiM/Mok
# ooPrcUF2qOXx8PlTAhu6KDFMpCrSuI2/+GVisbg/DC99MqGCAyYwggMiBgkqhkiG
# 9w0BCQYxggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdp
# Q2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3Rh
# bXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgw
# DQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
# SIb3DQEJBTEPFw0yNjAyMjMxNjQ0NTlaMC8GCSqGSIb3DQEJBDEiBCBNiaMOJsyM
# v81GKNCga69kYmn/9PgNeaKAUDE2kVoe2zANBgkqhkiG9w0BAQEFAASCAgDIJIkp
# FlUmIOtWBt/60TlMellSzzDhUKBUX7BOaHPI3ENghEb0wrpp8PwUaYaHy+u51/sS
# qv2B1z4oCgjbafTylT8QSd30eZ4Dx+sTUaE8vrYw/4vS6Ub1FTXlpj7Gohiqv67b
# UyiR8iU+JnfkuSn124VZnn9g1KbprfT6s7DOBBvurvVConhIFEjt4wM+Tx+qMiDi
# JJi2MqJLBDXTCa1+K2enNB1d2ifsTnVfYSg5SAfukSJc1MX2dnIABoa+NMxbdIb5
# 9AY7U5noamvXywEgMJp5c6QX6hXNhXFsJferqpHluMkehVTy8itVCWhcsFzpN5L0
# cDVHhkLdkJRhK8boP0p9YIu3Fb4B8iHk1u9zXMpTmMsI7eUNztYqhwaHCt3Lh+s9
# XLb+eGXdOg7o0fY7WmNHBKgqT3O09kr1kkS0uMkYIqntbMQxwh7T2/t+z2Qmfupt
# +TwCHoMB3/bbtM67Bg2f2zPkBLTOlcHt4easiR39ibpg2dBB2t5YdXVzm7x6n+vS
# uDXH4KVGYgZUUO8l8e2aeHNMwYWclDwMTlZHrNsbvfsZsnSXjIrwmqZjrF+fyOoe
# TCow5DEqGjzXeMwXULpQe26cjgLMFa1dtWv0wAUPvEbfgskw8cYiuUD+qY/lSmQl
# dbVBEHg7ACAK+RSBgvIahSnXqJLy35bMJDNLTQ==
# SIG # End signature block

﻿
<#
Copyright (c)2026 Venafi, Inc. All rights reserved. This integration module is licensed under the same terms and conditions as your CyberArk product, available here: https://www.cyberark.com/contract-terms/
#>

$script:scriptVersion = '2.2'
$script:scriptName = 'AdaptableCA\AcmeAdaptableCA'

# Force TLS 1.2 if currently set lower
if ([Net.ServicePointManager]::SecurityProtocol.value__ -lt 3072) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}

<##################################################################################################
.NAME
    Test-Settings
.DESCRIPTION
    Verifies that Trust Protection Platform can authenticate with the CA using the supplied credentials.
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions
        UserName: the username required to authenticate with the CA
        UserPass: the password required to authenticate with the CA
        PfxData: a PKCS#12 containing a client certificate and private key required to authenticate with the CA
        PfxPass: the password required to access the private key in the PKCS#12
        AuxUser: a username paired with AuxPass for secondary authentication purposes
        AuxPass: the password for the AuxUser (username credential), AuxPfxData (certificate credential), or independent (password credential)
        AuxPfxData: a PKCS#12 containing client certificate and private key for secondary authentication purposes
        CertObjDN: the Venafi distinguished name of the certificate object in the policy tree
        CustomFields: the hash table of Custom Fields. Keys are field labels and values are either strings (single valued) or string arrays (multi-valued)
        ServiceAddress: URI, IP address or FQDN of the service you want to connect to
        ProfileString: String, can be delimited, which identifies product or profile associated with the service
.NOTES
    Returns a hashtable that includes the following variables
        Result: 'Success' or 'NotUsed' to indicate the non-error completion state
##################################################################################################>
function Test-Settings {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

    # a CA object cannot be saved until Validation completes
    # until saved, debug logging is not available so Validation issues cannot be logged
    # use this as a workaround to allow the user to save, have logging be enabled and then try with original values to capture logs
    if ( $General.ServiceAddress -eq 'AllowMeToSave' ) {
        return @{'Result' = 'Success' }
    }

    try {
        $outConfig = Get-Configuration $General
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException -Intro "Could not verify configuration"
    }

    try {
        Load-PAAccount -Config $outConfig
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException -Intro "Could not verify Posh-ACME Account"
    }

    return @{ Result = "Success" }
}

<##################################################################################################
.NAME
    Get-ChainCertificates
.DESCRIPTION
    Retrieves the chain of CA certificates that are applicable to certificates issued by the CA
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.NOTES
    Returns a hashtable that includes the following variables:
        Result: 'Success' or 'NotUsed' to indicate the non-error completion state
        Pkcs7: a collection that includes all of the CA certificates in the issuing chain
##################################################################################################>
function Get-ChainCertificates {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General
    )

    return @{ Result = "NotUsed" }
}

<##################################################################################################
.NAME
    Prepare-ForRequest
.DESCRIPTION
    Performs any tasks that are necessary to prior to submitting a certificate signing request to the CA
.PARAMETER General
    A hashtable containing the general set of variables needed by all or most functions (see Test-Settings)
.PARAMETER Specific
    A hashtable containing the specific set of variables needed by this function
        SubjectDN: the requested subject distiguished name as a hashtable; OU is a string array; all others are strings
        SubjAltNames: hashtable keyed by SAN type; values are string arrays
.NOTES
    Returns a hashtable that includes the following variables
        Result: 'Success' or 'NotUsed' to indicate the non-error completion state
##################################################################################################>
function Prepare-ForRequest {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable] $Specific
    )

    return @{
        Result = "Success"
    }
}

<##################################################################################################
.NAME
    Submit-CsrAsNew
.DESCRIPTION
    Submits a CSR to a CA for enrollment as a new, first time certificate
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.PARAMETER Specific
    A hash table containing the specific set of variables needed by this function
        Pkcs10: the Base64-encoded PKCS#10-formatted certificate signing request (CSR) to be enrolled
        SubjectDN: the requested subject distiguished name as a hash table. OU is a string array and all others are strings
        SubjAltNames: hash table keyed by SAN type. Values are string arrays.
        KeySize: the integer key size to be used if the CA creates the key pair
.NOTES
    Returns a hash table that includes the following variables:
        Result: 'Success' to indicate the non-error completion state. NOTE: this function is required.
        TransId: the identifier used to subsequently approve and/or retrieve the certificate from the CA
        Pkcs7: a collection that includes the issued certificate and (optionally) includes all of the CA certificates in the chain
        Pkcs12: a collection that includes the issued certificate, its private key, and optionally all of the CA certificates in the chain
        PrivKeyPem: an OpenSSL or PKCS#8 private key in PEM format
        EncryptPass: the password used to encrypt the private key or PKCS#12
##################################################################################################>
function Submit-CsrAsNew {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable] $Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo

    try {
        $config = Get-Configuration $General
    }
    catch {
        $_ | Write-VenafiDebug -Intro 'Could not verify configuration' -ThrowException
    }

    # Retrieve the CN
    $SubjectCN = $Specific.SubjectDN.CN
    $AllCNs = @( $SubjectCN )
    Write-VenafiDebug -Message "Processing a CSR for CN $SubjectCN"

    # Make sure that we don't have any unsupported SAN types, such as IP addresses
    $SANs = $Specific.SubjAltNames
    $BadSANTypes = @()
    foreach ($SANType in $SANs.keys) {
        if ($SANType -ne "DNS") {
            $BadSANTypes += $SANType
            Write-VenafiDebug -Message "CSR contains SANs of unsupported type $SANType" Error
        }
    }
    if ($BadSANTypes.count -gt 0) {
        Write-VenafiDebug -ThrowException -Message ("CSR contains unsupported SAN types: " + ($BadSANTypes -join ', '))
    }

    # Collect all unique DNS names (CN + SANs)
    $DNSSANs = $SANs.DNS
    foreach ($DNSSAN in $DNSSANs) {
        if ($DNSSAN -notin $AllCNs) {
            $AllCNs += $DNSSAN
        }
        Write-VenafiDebug -Message "CSR has a DNS SAN for $DNSSAN"
    }

    # Build DnsAlias array using CNameTemplate (preferred) or CNamePrefix/CNameSuffix (legacy)
    $DNSCNames = @()
    if ($config.CNameTemplate) {
        foreach ($name in $AllCNs) {
            $parts = $name.Split('.', 2)
            $cname = $config.CNameTemplate `
                -replace '\{fqdn\}', $name `
                -replace '\{host\}', $parts[0] `
                -replace '\{domain\}', $parts[1]
            $DNSCNames += $cname
            Write-VenafiDebug -Message "Setting DNS alias $cname for $name"
        }
    }
    elseif ($config.CNamePrefix -or $config.CNameSuffix) {
        foreach ($name in $AllCNs) {
            $DNSCNames += $config.CNamePrefix + $name + $config.CNameSuffix
            Write-VenafiDebug -Message ("Setting DNS alias " + $config.CNamePrefix + $name + $config.CNameSuffix)
        }
    }

    # Get the Posh-ACME account object, and create it if it doesn't exist
    try {
        Load-PAAccount $config
    }
    catch {
        $_ | Write-VenafiDebug -Intro "Could not retrieve Posh-ACME Account" -ThrowException
    }

    $CSRFile = New-TemporaryFile
    Write-VenafiDebug -Message "Writing CSR to temporary file $($CSRFile.FullName)"
    $Specific.Pkcs10 | Out-File $CSRFile.FullName

    try {
        if ($DNSCNames -eq @()) {
            $PACertificate = New-PACertificate -CSRPath $CSRFile.FullName -Plugin $config.Plugin -PluginArgs $config.PluginParams -Force -DnsSleep $config.WaitTime
        }
        else {
            $PACertificate = New-PACertificate -CSRPath $CSRFile.FullName -Plugin $config.Plugin -PluginArgs $config.PluginParams -Force -DnsSleep $config.WaitTime -DnsAlias $DNSCNames
        }
        if ($PACertificate.Thumbprint) {
            Write-VenafiDebug -Message "Retrieved issued certificate for CN $SubjectCN"

            $P7File = New-TemporaryFile
            Write-VenafiDebug -Message "Writing PKCS#7 to temporary file $($P7File.FullName)"
            openssl crl2pkcs7 -nocrl -certfile $PACertificate.CertFile -certfile $PACertificate.ChainFile -out $P7File.FullName

            # Convert the PEM format PKCS#7 file to an array of ASCII bytes
            $pkcs7 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($P7File.FullName))
            $bytes = [Convert]::FromBase64String($pkcs7)

            return @{ Result = "Success"; Status = "Issued"; PKCS7 = $bytes }
        }
    }
    catch {
        if (($config.Plugin -eq "Manual") -and ($PSItem.Exception.Message.indexOf("The host was attempting to request confirmation") -gt 0)) {
            # Looks like we have been asked to respond to challenges ... and we can't since we don't have a plugin
            $_ | Write-VenafiDebug -Intro "CA has issued challenges but no automatic DNS plugin is configured"
        }
        $_ | Write-VenafiDebug -Intro "Could not create order" -ThrowException
    }

    return @{
        Result  = "Success"
        TransID = $SubjectCN
    }
}

<##################################################################################################
.NAME
    Submit-CsrAsRenewal
.DESCRIPTION
    Submits a CSR to a CA for enrollment as a renewal of an existing certificate
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.PARAMETER Specific
    A hash table containing the specific set of variables needed by this function. See Submit-CsrAsNew, as well as the following:
        CertId: a string that uniquely identifies the certificate issued by the CA to be renewed
        CertPem: the raw, Base64-encoded X509 certificate to be renewed
.NOTES
    Returns a hash table that includes the same variables detailed in Submit-CsrAsNew
##################################################################################################>
function Submit-CsrAsRenewal {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable] $Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    # We don't need to treat renewals specially, so we just handle them as new requests
    return Submit-CsrAsNew $General $Specific
}

<##################################################################################################
.NAME
    Submit-CsrAsReplacement
.DESCRIPTION
    Submits a CSR to a CA for enrollment as a replacement for an existing certificate
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.PARAMETER Specific
    A hash table containing the specific set of variables needed by this function. See Submit-CsrAsNew, as well as the following:
        CertId: a string that uniquely identifies the certificate issued by the CA to be replaced
        CertPem: the raw, Base64-encoded X509 certificate to be replaced
.NOTES
    Returns a hash table that includes the same variables detailed in Submit-CsrAsNew
##################################################################################################>
function Submit-CsrAsReplacement {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable] $Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    # We don't need to treat replacements specially, so we just handle them as new requests
    return Submit-CsrAsNew $General $Specific
}

<##################################################################################################
.NAME
    Approve-Request
.DESCRIPTION
    Approves a previously submitted CSR
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.PARAMETER Specific
    A hash table containing the specific set of variables needed by this function
        TransId: a string that uniquely identifies the certificate request submitted to the CA
        SubjectDN: the requested subject distiguished name as a hashtable; OU is a string array; all others are strings
        SubjAltNames: hashtable keyed by SAN type; values are string arrays
.NOTES
    Returns a hashtable that includes the following variables
        Result: 'Success' or 'NotUsed' to indicate the non-error completion state
##################################################################################################>
function Approve-Request {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable] $Specific
    )

    return @{ Result = "NotUsed" }
}

<##################################################################################################
.NAME
    Retrieve-Certificate
.DESCRIPTION
    Retrieves a signed certificate from the CA
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.PARAMETER Specific
    A hash table containing the specific set of variables needed by this function
        CertId: a string that uniquely identifies the certificate issued by the CA
.NOTES
    Returns a hash table that includes the following variables:
        Result: 'Success' or 'NotUsed' to indicate the non-error completion state
        Status: 'Pending' or 'Issued' to indicate whether the certificate has been issued by the CA
        Pkcs7: a collection that includes the issued certificate and (optionally) all of the CA certificates in the chain
        Pkcs12: a collection that includes the issued certificate, its private key, and optionally all of the CA certificates in the chain
        PrivKeyPem: an OpenSSL or PKCS#8 private key in PEM format
        EncryptPass: the password used to encrypt the private key or PKCS#12
        DiscardPrivateKeyAndCsr: boolean that when $true tells the driver to discard stored assets that will not match the certificate being returned
##################################################################################################>
function Retrieve-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable] $Specific
    )

    return @{
        Result = "NotUsed"
    }
}

<##################################################################################################
.NAME
    Revoke-Certificate
.DESCRIPTION
    Revokes a certificate issued by the CA
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.PARAMETER Specific
    A hash table containing the specific set of variables needed by this function
        CertId: a string that uniquely identifies the certificate issued by the CA
        CertPem: the raw, Base64-encoded X509 certificate to be revoked
        ReasonCode: 1 (User Key Compromised), 2 (CA Key Compromised), 3 (User Changed Affiliation), 4 (Certificate Superseded), 5 (Original Use No Longer Valid)
        Comment: a comment provided by the revocation requester
.NOTES
    Returns a hashtable that includes the following variables:
        Result: 'Success' or 'NotUsed' to indicate the non-error completion state
##################################################################################################>
function Revoke-Certificate {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General,
        [Parameter(Mandatory = $true, HelpMessage = "Function Specific Parameters")]
        [System.Collections.Hashtable] $Specific
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $ReasonCodes = @{
        0  = "unspecified";
        1  = "keyCompromise";
        2  = "cACompromise";
        3  = "affiliationChanged";
        4  = "superseded";
        5  = "cessationOfOperation";
        6  = "certificateHold";
        8  = "removeFromCRL";
        9  = "privilegeWithdrawn";
        10 = "aACompromise"
    }

    try {
        $config = Get-Configuration $General
    }
    catch {
        $_ | Write-VenafiDebug -ThrowException -Intro 'Could not verify configuration'
    }

    # Get the Posh-ACME account object
    try {
        Load-PAAccount $config
    }
    catch {
        $_ | Write-VenafiDebug -Intro "Could not retrieve Posh-ACME Account" -ThrowException
    }

    try {
        Revoke-PACertificate -CertPem $Specific.CertPem -Reason $ReasonCodes.$ReasonCode
    }
    catch {
        $_ | Write-VenafiDebug -Intro "Could not revoke certificate" -ThrowException
    }

    Write-VenafiDebug -Message "Certificate revocation submitted to CA"
    return @{ Result = "Success" }
}

<##################################################################################################
.NAME
    Get-Configuration
.DESCRIPTION
    Loads and verifies the CA driver configuration
.PARAMETER General
    A hash table containing the general set of variables needed by most (or all) functions (see Test-Settings)
.NOTES
    Returns a hashtable containing the CA driver configuration
##################################################################################################>
function Get-Configuration {

    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingConvertToSecureStringWithPlainText', '', Justification = 'Plaintext provided, converting to secure string as needed for plugin parameters')]

    Param(
        [Parameter(Mandatory = $true, HelpMessage = "General Parameters")]
        [System.Collections.Hashtable] $General
    )

    Write-FunctionDetail $PSCmdlet.MyInvocation

    $CAURL = $General.ServiceAddress
    $inConfigPath = Join-Path -Path $General.ProfileString -ChildPath 'ca.cfg'

    if (![System.IO.File]::Exists($inConfigPath)) {
        Write-VenafiDebug -ThrowException -Message [System.IO.FileNotFoundException]::new("Config file not found", $inConfigPath)
    }

    $outConfig = @{}

    $inConfig = Get-Content -Raw -Path $inConfigPath | ConvertFrom-Json

    if ( $inConfig.Proxy ) {
        if ( -not $inConfig.Proxy.StartsWith("http://") -and -not $inConfig.Proxy.StartsWith("https://") ) {
            $ProxyAddress = "http://$($inConfig.Proxy)"
        }
        else {
            $ProxyAddress = $inConfig.Proxy
        }
        $proxyUri = [System.Uri]$ProxyAddress
        $ProxyServer = New-Object System.Net.WebProxy($proxyUri)
        [System.Net.WebRequest]::DefaultWebProxy = $ProxyServer
        [System.Net.WebRequest]::DefaultWebProxy.BypassProxyOnLocal = $true

        "A proxy server ($ProxyAddress) will be used" | Write-VenafiDebug

        # Add bypass list from config (array of regex patterns)
        if ($inConfig.ProxyBypass) {
            $ProxyServer.BypassList = [string[]]$inConfig.ProxyBypass
            "Proxy bypass list: $($inConfig.ProxyBypass -join ', ')" | Write-VenafiDebug
        }

        # Allow user entered credential for proxy authentication
        if ($General.AuxUser -and $General.AuxPass) {
            $ProxyServer.Credentials = New-Object System.Net.NetworkCredential($General.AuxUser, ($General.AuxPass | ConvertTo-SecureString -AsPlainText -Force))
            "Credentials to authenticate with proxy server are supplied. Setting authenticated proxy access." | Write-VenafiDebug
        }
        else {
            "No credentials to authenticate with proxy server are supplied. Setting unauthenticated proxy access." | Write-VenafiDebug
        }
    }

    $outConfig.add("Directory", $General.ProfileString)
    $outConfig.add("CAURL", $CAURL)

    Write-VenafiDebug -Message ($inConfig | ConvertTo-Json)

    # Directory where we want Posh-ACME to store its state
    $poshAcmeDir = Join-Path -Path $General.ProfileString -ChildPath 'Posh-ACME'
    $env:POSHACME_HOME = $poshAcmeDir
    if (!(Test-Path $poshAcmeDir)) {
        New-Item -ItemType Directory -Path $poshAcmeDir
    }

    # Import the Posh-ACME module
    Import-Module Posh-ACME -Force -ErrorAction Stop

    if ($inConfig.AutoCreateAccount) {
        $outConfig.add("AutoCreateAccount", $inConfig.AutoCreateAccount)
    }

    if ($inConfig.Contact) {
        $outConfig.add("Contact", $inConfig.Contact)
    }

    if ($inConfig.SkipCertificateCheck) {
        $outConfig.add("SkipCertificateCheck", $inConfig.SkipCertificateCheck)
    }

    $outConfig.add("Plugin", $inConfig.Plugin)

    if ($inConfig.Plugin -ne "Manual") {
        $plugin = Get-PAPlugin -Plugin $inConfig.Plugin -ErrorAction SilentlyContinue

        if (!$plugin) {
            Write-VenafiDebug -ThrowException -Message ("Plugin '" + $inConfig.Plugin + "' not found. Make sure it is available with the version of Posh-ACME you are using.")
        }

        Write-VenafiDebug -Message ("Using DNS plugin " + $plugin.Name)

        if ( !$inConfig.PluginParams ) {
            Write-VenafiDebug -ThrowException -Message 'No plugin parameters defined in the config file. Plugin parameters are required when using a DNS plugin.'
        }

        # use any plugin params provided in the config file, and convert any that need to be converted (e.g. credentials, secure strings)
        $pluginParams = @{}

        foreach ($param in $inConfig.PluginParams.PSObject.Properties) {
            $paramName = $param.Name
            $paramValue = $param.Value

            # check for using builtin credentials
            if ( $paramValue -eq "pscredential" ) {
                $paramValue = New-Object System.Management.Automation.PSCredential($General.UserName, ($General.UserPass | ConvertTo-SecureString -AsPlainText -Force))
            }

            if ( $paramValue -eq "username" ) {
                $paramValue = $General.UserName
            }

            if ( $paramValue -eq "password" ) {
                $paramValue = $General.UserPass
                # ensure we add this to be hidden during logging
                $script:loggingHidden = $paramName
            }

            if ( $paramValue -eq 'securestringpassword' ) {
                $paramValue = ConvertTo-SecureString $General.UserPass -AsPlainText -Force
            }

            $pluginParams.add($paramName, $paramValue)
        }

        $outConfig.PluginParams = $pluginParams

        if ($inConfig.WaitTime) {
            $outConfig.add("WaitTime", $inConfig.WaitTime)
        }

        $CNamePrefix = ""
        if ($inConfig.CNamePrefix) {
            $CNamePrefix = $inConfig.CNamePrefix + "."
        }
        $outConfig.add("CNamePrefix", $CNamePrefix)

        $CNameSuffix = ""
        if ($inConfig.CNameSuffix) {
            $CNameSuffix = "." + $inConfig.CNameSuffix
        }
        $outConfig.add("CNameSuffix", $CNameSuffix)

        if ($inConfig.CNameTemplate) {
            $outConfig.add("CNameTemplate", $inConfig.CNameTemplate)
        }

    }
    else {
        Write-VenafiDebug -Message "No DNS plugin configured, will not attempt to automatically respond to ACME challenges"

        $outConfig.PluginParams = @{}

        if ( $inConfig.WaitTime ) {
            Write-VenafiDebug -Message "WaitTime is defined in the config file but will be ignored since no DNS plugin is configured"
        }
    }

    $outConfig | Write-VenafiDebug -Intro "Final configuration object"
    return $outConfig
}

<##################################################################################################
.NAME
    Load-PAAccount
.DESCRIPTION
    Loads the Posh-ACME account, creating it if it doesn't already exist
.PARAMETER outConfig
    A hash table containing the CA driver configuration
##################################################################################################>
function Load-PAAccount {
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "Config Object")]
        [System.Collections.Hashtable] $Config
    )

    # Get the Posh-ACME account object
    if ($Config.SkipCertificateCheck) {
        Write-VenafiDebug -Message "Setting CA to $($Config.CAURL), skipping certificate check"
        Set-PAServer $Config.CAURL -SkipCertificateCheck
    }
    else {
        Write-VenafiDebug -Message "Setting CA to $($Config.CAURL), not skipping certificate check"
        Set-PAServer $Config.CAURL
    }
    $PAAccount = Get-PAAccount

    # If we don't have an ACME account, and we have been allowed to autocreate it, do so
    if (!$PAAccount) {
        if ($Config.AutoCreateAccount) {
            Write-VenafiDebug -Message "Posh-ACME account does not exist -- creating"
            if ($Config.Contact) {
                $PAAccount = New-PAAccount -AcceptTOS -Contact $Config.Contact
                Write-VenafiDebug -Message "Posh-ACME account created with contact $($Config.Contact), id = $($PAAccount.id)"
            }
            else {
                $PAAccount = New-PAAccount -AcceptTOS
                Write-VenafiDebug -Message "Posh-ACME account created, id = $($PAAccount.id)"
            }
        }
        else {
            Write-VenafiDebug -ThrowException -Message { "Posh-ACME account does not exist, and autocreate flag has not been set" }
        }
    }
    else {
        Write-VenafiDebug -Message "Posh-ACME account exists, id = $($PAAccount.id)"
    }

    return $PAAccount
}

Function Write-FunctionDetail {

    <#
    .SYNOPSIS
        Log function details
    .DESCRIPTION
        Log function details including the function name and any bound parameters
    .PARAMETER InvocationInfo
        Invocation detail from a function, typically sent via $PSCmdlet.MyInvocation
    .PARAMETER NoBoundParams
        By default, function parameters and values will be written.  Don't do this.
    .PARAMETER ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
    .NOTES
        Must be an advanced function otherwise $PSCmdlet.MyInvocation will not be available.
        Set $script:scriptVersion to include the script version in the log.
        Set $script:scriptName to validate signing.  Value should be similar to 'AdaptableCA\MyDriver', after Scripts dir and no .ps1.
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation
        Put this at the start of every function
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -NoBoundParams
        Do not output the bound parameters
    .EXAMPLE
        Write-FunctionDetail $PSCmdlet.MyInvocation -ExtraInfo
        Include additional detail such as script signing validation, CMSH version, and PowerShell version.
        Helpful for the first log entry in a script to help with troubleshooting.
    #>

    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0)]
        [System.Management.Automation.InvocationInfo] $InvocationInfo,

        [Parameter()]
        [switch] $NoBoundParams,

        [Parameter()]
        [Alias('ValidateScript')]
        [switch] $ExtraInfo
    )

    $cs = Get-PSCallStack
    # get list of function names from stack, remove this function and the one which called it
    $functionBreadcrumb = ($cs.FunctionName | Select-Object -Skip 2) -join ' <- '

    $header = 'Function: {0}' -f $InvocationInfo.InvocationName
    if ( $functionBreadcrumb ) { $header += " (<- $functionBreadcrumb)" }
    if ($script:scriptVersion) { $header += ', script version: {0}' -f $script:scriptVersion }
    $header | Write-VenafiDebug

    if ( $ExtraInfo ) {

        $extraMessage = ''

        # registry only available on CMSH
        # if reusing this script with CMSaaS, this section will be skipped
        if ( $PSVersionTable.PSEdition -ne 'Core' ) {
            $installPath = Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Venafi\Platform\ -Name 'Base Path'

            if ( $script:scriptName ) {
                try {
                    $sig = Get-AuthenticodeSignature -FilePath ('{0}Scripts\{1}.ps1' -f $installPath, $script:scriptName)
                    $sigStatus = if ( $sig.Status -eq 'Valid' ) { 'Valid' } else { 'Not Valid' }
                }
                catch {
                    $sigStatus = $_.ToString()
                }
            }
            else {
                $sigStatus = 'script name not set'
            }

            $extraMessage += "Signature: $sigStatus"

            # add CMSH version if available
            try {
                $f = Join-Path -Path $installPath -ChildPath 'Platform\Venafi.InstallKit.dll'
                $extraMessage += ', CMSH version: {0}' -f (Get-Item $f).VersionInfo.FileVersion
            }
            catch {
                # just for logging, don't fail
            }
        }

        # add powershell version
        $extraMessage += ', PowerShell version: {0}' -f $PSVersionTable.PSVersion.ToString()

        $extraMessage | Write-VenafiDebug
    }

    if ( $null -ne $InvocationInfo.BoundParameters -and -not $NoBoundParams ) {
        [hashtable]$InvocationInfo.BoundParameters | Write-VenafiDebug
    }
}

function Write-VenafiDebug {

    <#
    .SYNOPSIS
    Write info to the adaptable debug log

    .DESCRIPTION
    Assuming the option has been selected, write info to the adaptable debug log.
    Hashtables are supported and secret info will not be logged, eg. $General.

    .PARAMETER Message
    The info to be logged

    .PARAMETER ThrowException
    After logging the message, throw an exception to terminate the script

    .EXAMPLE
    Write-VenafiDebug -Message 'connected to server'

    Write info to the log

    .EXAMPLE
    $General | Write-VenafiDebug

    Write input parameter values to the log

    .EXAMPLE
    Write-VenafiDebug -Message 'this was not good' -ThrowException

    Write to the log and throw an exception
    #>

    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [psobject] $Message,

        [Parameter()]
        [string] $Intro,

        [Parameter()]
        [switch] $ThrowException
    )

    process {

        if ( -not $global:DEBUG_FILE ) {
            return
        }

        $newMessage = switch ($Message.GetType().FullName) {
            'System.Collections.Hashtable' {
                Set-SecretsToHidden $Message | ConvertTo-Json -Depth 5
            }

            'System.String' {
                $Message
            }

            'System.Management.Automation.ErrorRecord' {
                # powershell specific exception
                $err = $Message
                $ex = $err.Exception
                $inv = $err.InvocationInfo
                $logEntry = @{
                    Message          = $ex.Message
                    ErrorId          = $err.FullyQualifiedErrorId
                    Category         = $err.CategoryInfo.Category
                    TargetObject     = $err.TargetObject
                    ScriptName       = $inv.ScriptName
                    LineNumber       = $inv.ScriptLineNumber
                    Line             = $inv.Line
                    Position         = $inv.PositionMessage
                    StackTrace       = $ex.StackTrace
                    ScriptStackTrace = $err.ScriptStackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }
                $logEntry | ConvertTo-Json -Depth 3
            }

            'System.Exception' {
                #.net generic exception
                $ex = $Message
                $inv = $ex.InvocationInfo
                $logEntry = @{
                    Message       = $ex.Message
                    ExceptionType = $ex.GetType().FullName
                    ScriptName    = $inv.ScriptName
                    LineNumber    = $inv.ScriptLineNumber
                    Line          = $inv.Line
                    Position      = $inv.PositionMessage
                    StackTrace    = $ex.StackTrace
                }
                if ($ex.InnerException) {
                    $logEntry.InnerExceptionMessage = $ex.InnerException.Message
                    $logEntry.InnerExceptionType = $ex.InnerException.GetType().FullName
                }

                $logEntry | ConvertTo-Json -Depth 3
            }

            default {
                $Message | ConvertTo-Json -Depth 3
            }
        }

        if ( $Intro ) {
            $newMessage = "$Intro`r`n$newMessage"
        }

        # use a mutex to ensure multiple executions of this script don't cause 'file in use' errors
        $mutex = New-Object System.Threading.Mutex($false, [System.IO.Path]::GetFileNameWithoutExtension($global:DEBUG_FILE))
        $lockAcquired = $false
        try {
            $lockAcquired = $mutex.WaitOne()
            ('{0} : {1}' -f (Get-Date), ($newMessage | Out-String)) | Out-File -FilePath $global:DEBUG_FILE -Encoding UTF8 -Append
        }
        finally {
            if ($lockAcquired) {
                $mutex.ReleaseMutex()
            }
        }
    }

    end {
        if ( $ThrowException ) {
            # since we're in the end block this is only intended for a string, not array or anything that needs the pipeline
            throw $Message
        }
    }
}

function Set-SecretsToHidden {

    <#
    .SYNOPSIS
        Blank out sensitive information
    .DESCRIPTION
        Blank out sensitive information in a message, typically in a hashtable.
        Meant for adaptable framework scripts.
        Will automatically clone hashtable to ensure original object isn't affected.
    #>


    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        $InputObject
    )

    process {

        $secrets = @('UserPass', 'AuxPass', 'PfxPass', 'Certificate', 'PfxData', 'Password', 'AuxPfxData', 'PrivKeyPem', 'Pkcs12', 'EncryptPass', 'ChainPkcs7', 'PrivKeyPemEncrypted', 'VarPass')

        # if needed, add additional secrets specific to this integration to be hidden
        if ( $script:loggingHidden ) {
            # from Get-Configuration, if any plugin parameters are passwords, they will be added to $script:loggingHidden to be masked in the logs
            $secrets += $script:loggingHidden
        }

        if ($InputObject -is [hashtable]) {
            $clone = @{}
            foreach ($key in $InputObject.keys) {
                if ( [string]::IsNullOrEmpty($InputObject[$key]) ) {
                    $clone[$key] = ''
                }
                else {
                    if ($key -in $secrets ) {
                        $clone[$key] = '***hidden***'
                    }
                    else {
                        $clone[$key] = Set-SecretsToHidden $InputObject[$key]
                    }
                }
            }
            return $clone
        }
        else {
            return $InputObject
        }
    }
}

# SIG # Begin signature block
# MIIh2AYJKoZIhvcNAQcCoIIhyTCCIcUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCxtHsbW+Pl521+
# 3duG/1drq3y0RIOD9Wt8yT0I0PnAIqCCGtEwggeTMIIFe6ADAgECAhABUX9+ZWir
# r6OpYdH+HnHPMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBD
# b2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjUwOTExMDAw
# MDAwWhcNMjYwOTEwMjM1OTU5WjCBmjELMAkGA1UEBhMCVVMxFjAUBgNVBAgTDU1h
# c3NhY2h1c2V0dHMxDzANBgNVBAcTBk5FV1RPTjEgMB4GA1UEChMXQ3liZXJBcmsg
# U29mdHdhcmUsIEluYy4xHjAcBgNVBAsTFVByb2Zlc3Npb25hbCBTZXJ2aWNlczEg
# MB4GA1UEAxMXQ3liZXJBcmsgU29mdHdhcmUsIEluYy4wggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC4Rp6KSQ+kelbVZimPMfQQPYfI1sYfkuOCTvooMhol
# oVm6aKLtEzZB7s0VkLLaW3XPfyzmlereIyRsK7h/3kxiXeeNzMu2tycqoSVFxwsn
# j04ptiSZ0TeD+ciM/EHvhapRqN2e1v5VRrpvsTkp9NAwKtf1z09czOeZXo2McpQm
# 66CLXfWWu6WhxV2wtDdn998cyxbGdXAZEdQmszU3YM6G9YB/2sdONTwSWaZqri9p
# oNnbO0hEByaz13PVPwN4FNJEKyY2RT7SJjrh6jPmkZwhvn08vna96tKsrw5XxxwJ
# FsFe7W2Wxgo4hybaVA0tLlOqmp6BufGjoa7GjpdM+g/SRm7xPFcSEJkqYJzoCVWu
# 5VNydUdZttKzzi1JfGuxQAaITelrIvo0K3cHig7NwN7F2/riIvP6tv+8AGiyGuoU
# uIAdnSEIRZLzdbfELdRyf6yffNYbaIi4iCS2UMwzDKzDzL3YPMu66jkx+zkC3iH0
# jXeWJMQn+Zsry0Sqpll+9EFeFBbo+ko28SsWnWfbEpkHZz+OuwVUyYGs/YiSUWXk
# c+uGyPm8DcIeQGEfOztKydl3qE0tG0QOTqCJtl+TqPwaRZuacXTH/X/az4oSg1g5
# BSrawJ9eagUUD7jL0gOUCHakMz/4P4vkos8dDb8vitr7v9b6WOVIQ1+sEg03GvKy
# FQIDAQABo4ICAzCCAf8wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIw
# HQYDVR0OBBYEFNjJEce0IdNYQxp2y/vTz43mpVH1MD4GA1UdIAQ3MDUwMwYGZ4EM
# AQQBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSBrTCB
# qjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+GTWh0
# dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWdu
# aW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSBhzCBhDAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUFBzAC
# hlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRD
# b2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRMEAjAAMA0G
# CSqGSIb3DQEBCwUAA4ICAQCbf/9bZQmPuGFJZUHfbkHTeA/sgbbBbOMyVO/kKfX2
# 9BY6D4ChS/ZPPQKFvOvfjp9KcTC1l43oFHP7eL9tTopnVL7YQm+btRhu5aAlmjQF
# sREjc0ZSVrP0NTFOhXMP8WEp1TYCkrrtR63MNno557UYKNKwdDx9+I0MmJ4GnDVD
# ua4SyPJAUPj39x4SIBPYxqI/Ur4czUHCUFxMfhsqtNKby+u8ziTu9ec/ztcw3+VL
# V/OAW2Tk1I5GA1PfDV+mdcvVTbrt0WDhoZjrzHpvvcJ16n45e5b8wyMQMnEzcuCH
# cboEh3LPJmAptvp2B7aCkFstBXp0MOBdrgGjckvTOXLv297PEIZwQDyWZEmgBMqt
# 5rdUaKW76LzAUmLNm21ksBMozS5dRo1VUnIUHGw+lqvckqJ21oblI91baMwvnBrG
# WTqQ+ZwbLrC34Admxl2cLgg7OF8OG42ZOgiJukH4/HafX3ieqcYaZWv8Zm5U1pY2
# dWaCR16yf95MQnMmneOP+vG+awSF7Nb0/LhQTril7p/y9Gbyjz0WggmZOsTyKwY0
# IAhNpolZItrnG2+r4znOUkgc9uVXXMnU1J0CnTG1dDLTbcxyjvSngGh51oaS3RQm
# 160iipGj6pCs57DLp7Z7uNS9dHZkFOPoN0qJnTsl45Ja+FERtAE05mxtFsaUrhqO
# ETCCBY0wggR1oAMCAQICEA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcNAQEMBQAw
# ZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQ
# d3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBS
# b290IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2lj
# ZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv+aQc2jeu+RdSjwwIjBpM+zCpyUu
# ySE98orYWcLhKac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR0uRf1gU8
# Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlqczKU0RBEEC7fgvMHhOZ0O21x4i0M
# G+4g1ckgHWMpLc7sXk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53yEioZldX
# n1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17cjo+A2raRmECQecN4x7axxLVq
# GDgDEI3Y1DekLgV9iPWCPhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3VdeGbZOjFE
# mjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfBaYh2mHY9WV1CdoeJl2l6
# SPDgohIbZpp0yt5LHucOY67m1O+SkjqePdwA5EUlibaaRBkrfsCUtNJhbesz2cXf
# SwQAzH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaAsPvoZKYz0YkH4b23
# 5kOkGLimdwHhD5QMIR2yVCkliWzlDlJRR3S+Jqy2QXXeeqxfjT/JvNNBERJb5RBQ
# 6zHFynIWIgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCPorF+CiaZ9eRp
# L5gdLfXZqbId5RsCAwEAAaOCATowggE2MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0O
# BBYEFOzX44LScV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1R
# i6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5BggrBgEFBQcBAQRtMGswJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNydDBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1UdIAQKMAgwBgYEVR0gADAN
# BgkqhkiG9w0BAQwFAAOCAQEAcKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqsoYcs7IVe
# qRq7IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy3iS8UgPITtAq3vot
# Vs/59PesMHqai7Je1M/RQ0SbQyHrlnKhSLSZy51PpwYDE3cnRNTnf+hZqPC/Lwum
# 6fI0POz3A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxUjG/voVA9/HYJ
# aISfb8rbII01YBwCA8sgsKxYoA5AY8WYIsGyWfVVa88nq2x2zm8jLfR+cWojayL/
# ErhULSd+2DrZ8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDCCBrQwggScoAMCAQIC
# EA3HrFcF/yGZLkBDIgw6SYYwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTI1MDUwNzAw
# MDAwMFoXDTM4MDExNDIzNTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
# Z2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVT
# dGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBALR4MdMKmEFyvjxGwBysddujRmh0tFEXnU2tjQ2UtZmW
# gyxU7UNqEY81FzJsQqr5G7A6c+Gh/qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzb
# NfiR+2fkHUiljNOqnIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0mR/vtLa4+gKPs
# YfwEu7EEbkC9+0F2w4QJLVSTEG8yAR2CQWIM1iI5PHg62IVwxKSpO0XaF9DPfNBK
# S7Zazch8NF5vp7eaZ2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhxKTVVgtmU
# PAW35xUUFREmDrMxSNlr/NsJyUXzdtFUUt4aS4CEeIY8y9IaaGBpPNXKFifinT7z
# L2gdFpBP9qh8SdLnEut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x5HHK
# S+rqBvKWxdCyQEEGcbLe1b8Aw4wJkhU1JrPsFfxW1gaou30yZ46t4Y9F20HHfIY4
# /6vHespYMQmUiote8ladjS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogx
# G9QEPHrPV6/7umw052AkyiLA6tQbZl1KhBtTasySkuJDpsZGKdlsjg4u70EwgWbV
# RSX1Wd4+zoFpp4Ra+MlKM2baoD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNT
# AgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBTvb1NK
# 6eQGfHrK4pBW9i/USezLTjAfBgNVHSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUH
# AQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYI
# KwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcw
# CAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAF877FoAc
# /gc9EXZxML2+C8i1NKZ/zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAz
# aoQk97frPBtIj+ZLzdp+yXdhOP4hCFATuNT+ReOPK0mCefSG+tXqGpYZ3essBS3q
# 8nL2UwM+NMvEuBd/2vmdYxDCvwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntu
# jB71WPYAgwPyWLKu6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOal95CHfmTnM4I+ZI2
# rVQfjXQA1WSjjf4J2a7jLzWGNqNX+DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z
# 0noDjs6+BFo+z7bKSBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/NmKLJ9M+MtucVG
# yOxiDf06VXxyKkOirv6o02OoXN4bFzK0vlNMsvhlqgF2puE6FndlENSmE+9JGYxO
# GLS/D284NHNboDGcmWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3rGlHqhpB
# /8MluDezooIs8CVnrpHMiD2wL40mm53+/j7tFaxYKIqL0Q4ssd8xHZnIn/7GELH3
# IdvG2XlM9q7WP/UwgOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlarEvf8
# EA+8hcpSM9LHJmyrxaFtoza2zNaQ9k+5t1wwggbtMIIE1aADAgECAhAKgO8YS43x
# BYLRxHanlXRoMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBU
# aW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAw
# MDAwWhcNMzYwOTAzMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGln
# aUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRp
# bWVzdGFtcCBSZXNwb25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEA0EasLRLGntDqrmBWsytXum9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7
# C8Dr0cVMF3BsfAFI54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAqlUPt281m
# HrBbZHqRK71Em3/hCGC5KyyneqiZ7syvFXJ9A72wzHpkBaMUNg7MOLxI6E9RaUue
# HTQKWXymOtRwJXcrcTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd2adw
# 44wDcKgH+JRJE5Qg0NP3yiSyi5MxgU6cehGHr7zou1znOM8odbkqoK+lJ25LCHBS
# ai25CFyD23DZgPfDrJJJK77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvh
# DU6lvJukx7jphx40DQt82yepyekl4i0r8OEps/FNO4ahfvAk12hE5FVs9HVVWcO5
# J4dVmVzix4A77p3awLbr89A90/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIU
# bWuhKuAeNIeWrzHKYueMJtItnj2Q+aTyLLKLM0MheP/9w6CtjuuVHJOVoIJ/DtpJ
# RE7Ce7vMRHoRon4CWIvuiNN1Lk9Y+xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CID
# BbTRofOsNyEhzZtCGmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7eacCAwEAAaOC
# AZUwggGRMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFOQ7/PIx7f391/ORcWMZUEPP
# YYzoMB8GA1UdIwQYMBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1UdDwEB/wQE
# AwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDCBlQYIKwYBBQUHAQEEgYgwgYUw
# JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEFBQcw
# AoZRaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0
# VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYw
# VKBSoFCGTmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRH
# NFRpbWVTdGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAX
# MAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBAGUqrfEc
# JwS5rmBB7NEIRJ5jQHIh+OT2Ik/bNYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz
# 9iZEN/FPsLSTwVQWo2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV+Kbz/3ImZlJ7
# YXwBD9R0oU62PtgxOao872bOySCILdBghQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8l
# D8QAGB9lctZTTOJM3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fxUFEp7W42
# fNBVN4ueLaceRf9Cq9ec1v5iQMWTFQa0xNqItH3CPFTG7aEQJmmrJTV3Qhtfparz
# +BW60OiMEgV5GWoBy4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu/CIJ
# nzkQTwtSSpGGhLdjnQ4eBpjtP+XB3pQCtv4E5UCSDag6+iX8MmB10nfldPF9SVD7
# weCC3yXZi/uuhqdwkgVxuiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH
# 3EmAp/jsJ3FVF3+d1SVDTmjFjLbNFZUWMXuZyvgLfgyPehwJVxwC+UpX2MSey2ue
# Iu9THFVkT+um1vshETaWyQo8gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6I
# Ls84ZPvmpovq90K8eWyG2N01c4IhSOxqt81nMYIGXTCCBlkCAQEwfTBpMQswCQYD
# VQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lD
# ZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEg
# Q0ExAhABUX9+ZWirr6OpYdH+HnHPMA0GCWCGSAFlAwQCAQUAoIGIMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCSqGSIb3DQEJBTEPFw0yNjA1MjcxMzQ2NTda
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCAN
# z63LjxGju88gie0GQVTgxkL4V2cDoNu9B+/nbDmI3jANBgkqhkiG9w0BAQEFAASC
# AgChqlVsSUpg0ipFR9UaEk9gIoRhuAHBBtVWk1PLS73LMOWTmLUwwy/2wSBRivwf
# K5sPUuXvWQD4rL58nPA9hECBAmmOneEckoz6w9pFe7gkfvBENLABnd3lAPhAuZ0V
# +mgB9b0pxb2sS76iMElCCwtN2sz/xqziklNYJr+BY8mJVGcCvnoSVEFTz2RZgdcz
# hxgrcdgWGq9C0PRf5yDvKKnRHleBAtOW57y3YkheLMKeaHdOZ/xY1SUKsghFni5T
# tQAXJ+W4JYfUFxGcYsLnJfl+44rhi3F0xLGInW6p46zrVs6KrlhyimbbTWrHlZsw
# GU9PgfFf2fSFtByFDPdwXpYN4XViGg7/mIkWlqdrN7UzsW8+O7m83FgO+visN3Vs
# VaoBUPN6+oXh8C9FHnriGaEpLNebU0yQRpYhR13+6HAXpAtOJS6Mjn3TXY73g90E
# 72wVtVT5m4/hOC53miLixwuBYjf2oqOwMnoTiamGfyX49Tw1ndg8ux/iM1R68qpD
# 8lMLf6Z4wIi+pFmr4uCEZJxgFwVKcopWX0pJLHH+OCnGue8DfpEnqfmCBURKnVU+
# Qwa2P5NG2ODLTgHCFzDGvaUTxxL2BW6nXtVox1oIZhdFbOrwmVP3XPaxIO6MS02k
# HNT3S2ANA4mHrl1v3CDzPvr98NAy4gPKhOZdI86G9PI59KGCAyYwggMiBgkqhkiG
# 9w0BCQYxggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdp
# Q2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3Rh
# bXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgw
# DQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqG
# SIb3DQEJBTEPFw0yNjA1MjcxMzQ2NTdaMC8GCSqGSIb3DQEJBDEiBCBqXzQ7gTkP
# 43VSjrYIvPbjfWckohy6Yw17mAaJBF4uEzANBgkqhkiG9w0BAQEFAASCAgDEGT8v
# RXMlh6FO4s9CmWoRvE2snid0qmFEa0lyqqwVB02Npv885yqZbLyAJ1fON7D0iLy2
# I72LKz0zOeCfoPhA7Oto968mND/QhnPiodWKi6+c2ZrSPxkvV9PSO6IE1TIOtyR7
# uD1IbsoPD2n8VZPYEBlW0TjtCsug0vy3tQnzWQLYoPwyAUqGEamoq8tkWt3CUX5L
# +bYQi33lfJYiwxocjS0vKbw2ZmFat7ZrwbaHdeihM+8ESj3dvgR6wga+42/gXfQc
# bxkT4cXAusOL59sb97xSAuZ9sjHV38UOTXfi03Giq9fD2cWbbtKjkv07EC5bAGuz
# oQZ56TA20OwT7JnLugbFb4YM1NPf69ELsn1pZxMwydYqCTyJpqkeg01pgbk2zK6p
# XDeEj8c2LJxT6wI4KIzGjK0ukrkmSVQTcKAXXxXr3ACa4iL6pirRfKupB5+0hAjk
# D+gVjRMJ7uBXYxevCvucxVg9NxJ7QGGQEshuKqnO64N7u4gRfl7DOUwCkHPbEvFe
# KEUnHFA4mpENX2U7bP1s7H6uQMge5b4xvNvzvbHsHfQeGR+eXAP7iEzcWmndgIhp
# w7yljszhu19GXPYvbMwjSbalLpPfBvN9V89Tq+AtzXfG7XNCd7ovf61Y9r2GxRdX
# 78dhrBSgSzlgiV3X+Rc01vezUxAGMxLSRBsXeA==
# SIG # End signature block
